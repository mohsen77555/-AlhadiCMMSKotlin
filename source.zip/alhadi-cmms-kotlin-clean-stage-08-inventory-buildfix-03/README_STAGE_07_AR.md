# Alhadi CMMS Kotlin Clean — Stage 07

## اسم المرحلة
Offline Queue + WorkManager + Retry Policy

## تاريخ الإنشاء
2026-06-16 01:12:49

## ما أضيف في هذه المرحلة
- إضافة WorkManager كمسؤول عن رفع العمليات المؤجلة.
- إضافة `SyncQueueWorker` لمعالجة `sync_queue`.
- إضافة `SyncQueueProcessor` لمعالجة العمليات المستحقة.
- إضافة `SyncQueueScheduler` لتشغيل المزامنة عند فتح التطبيق، وبعد العمليات، وبشكل دوري.
- إضافة سياسة Retry باستخدام `nextRetryAt` و `retryCount`.
- إضافة حالات واضحة: `PENDING`, `SYNCING`, `SYNCED`, `FAILED`, `CONFLICT`.
- تعديل أوامر العمل بحيث لا تعتمد على الرفع المباشر فقط، بل تدخل العملية في `sync_queue` بعد الحفظ المحلي.
- رفع Work Order و Status History و Execution Logs و Audit Logs من الطابور إلى Firestore.
- إضافة كشف تعارض أولي لأوامر العمل إذا تغيرت نسخة أو حالة السيرفر قبل رفع التعديل المحلي.
- عرض ملخص الطابور في واجهة أوامر العمل.
- إضافة زر تشغيل مزامنة يدوي اختياري، وليس أساس التحديث.

## ما لم يتم تنفيذه في هذه المرحلة
- المخزون التفصيلي؛ مكانه Stage 08.
- الأصول التفصيلية؛ مكانها Stage 09.
- المرفقات والكاميرا؛ مكانها Stage 12.
- Security Rules؛ مكانها Stage 13.

## مبدأ المرحلة
أي عملية يقوم بها المستخدم تحفظ أولًا في Room، ثم تدخل `sync_queue`. بعد توفر الإنترنت يرفع WorkManager العملية إلى Firestore، ثم يتم تحديث الحالة إلى `SYNCED` أو `FAILED` أو `CONFLICT`.


## إصلاح بناء إضافي

تمت إضافة نسخة build-fix لإزالة تعارض AGP 9 مع Kotlin Android plugin القديم. راجع `docs/BUILD_FIX_STAGE_07_AGP9_KOTLIN_AR.md`.

## Build Fix v2
تمت إضافة إصلاح توافق Gradle/Kotlin في ملف `gradle.properties` وملفات Gradle لمنع فشل `AgpWithBuiltInKotlinAppliedCheck` في GitHub Actions.
