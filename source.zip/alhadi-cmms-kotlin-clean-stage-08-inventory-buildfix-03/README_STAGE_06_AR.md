# Alhadi CMMS Kotlin Clean — Stage 06

## المرحلة

Stage 06 — المزامنة اللحظية لأوامر العمل باستخدام Firestore Snapshot Listener.

## ما أضيف

- `WorkOrderRemoteDataSource` داخل طبقة Firebase/Repository وليس داخل الشاشة.
- `startRealtimeSyncForRole(profile)` داخل `WorkOrderRepository`.
- مستمع Firestore حسب الدور:
  - المدير ومدير الصيانة والمشاهدة: أوامر الشركة.
  - المشرف: أوامر نطاقه.
  - الفني: أوامره المسندة فقط.
  - المخزن وطالب الخدمة: لا يتم تشغيل مستمع أوامر عمل في هذه المرحلة.
- حفظ نتائج Firestore داخل Room عبر `upsertAll`.
- تحديث الواجهة تلقائيًا من Room Flow.
- مؤشر حالة المزامنة: محفوظ محليًا، جارٍ المزامنة، تمت المزامنة، فشل الإرسال.
- محاولة رفع مباشرة إلى Firestore عند إنشاء/تغيير/بدء/إكمال/إغلاق أمر العمل.

## ما لم ينفذ بعد

- WorkManager Queue مؤجل إلى Stage 07.
- Conflict Handling المتقدم مؤجل إلى مراحل التعارض.
- المزامنة الكاملة لسجلات التنفيذ والتدقيق إلى Firestore ستتوسع لاحقًا.

## القاعدة المعمارية

الشاشة لا تقرأ Firestore مباشرة.

UI → ViewModel → Repository → Room + Firestore Listener → Room Flow → UI
