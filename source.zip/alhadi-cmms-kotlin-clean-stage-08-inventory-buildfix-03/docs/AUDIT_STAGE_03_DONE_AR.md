# AUDIT_STAGE_03_DONE_AR

تاريخ التدقيق: 2026-06-15 23:56:33 UTC

## اسم المرحلة

Stage 03 — Firebase Auth + User Profile + منع فتح دور قبل تحميل الصلاحيات

## الهدف

إضافة تسجيل الدخول الحقيقي بوساطة Firebase Auth، ثم قراءة ملف المستخدم الحقيقي من Firestore، ثم تخزينه في Room، مع منع ظهور أي دور مؤقت أو افتراضي قبل تحميل الصلاحيات.

## الملفات الجديدة

```text
app/google-services.json.example
app/src/main/java/com/alhadi/cmms/core/auth/AuthExceptions.kt
app/src/main/java/com/alhadi/cmms/firebase/FirebaseAuthGateway.kt
app/src/main/java/com/alhadi/cmms/firebase/UserProfileRemoteDataSource.kt
app/src/main/java/com/alhadi/cmms/domain/repository/AuthRepository.kt
app/src/main/java/com/alhadi/cmms/data/repository/AuthRepositoryImpl.kt
app/src/main/java/com/alhadi/cmms/domain/usecase/SignInAndLoadProfileUseCase.kt
app/src/main/java/com/alhadi/cmms/domain/usecase/LoadCurrentUserProfileUseCase.kt
app/src/main/java/com/alhadi/cmms/domain/usecase/SignOutUseCase.kt
app/src/main/java/com/alhadi/cmms/ui/auth/AuthScreen.kt
app/src/main/java/com/alhadi/cmms/ui/auth/AuthUiState.kt
app/src/main/java/com/alhadi/cmms/ui/auth/AuthGateViewModel.kt
app/src/main/java/com/alhadi/cmms/ui/screens/PermissionErrorScreen.kt
app/src/main/java/com/alhadi/cmms/ui/screens/RoleReadyScreen.kt
README_STAGE_03_AR.md
```

## الملفات المعدلة

```text
build.gradle.kts
app/build.gradle.kts
app/src/main/AndroidManifest.xml
.github/workflows/build-debug-apk.yml
.gitignore
app/src/main/java/com/alhadi/cmms/ui/navigation/AppRoute.kt
app/src/main/java/com/alhadi/cmms/ui/navigation/AppNavHost.kt
app/src/main/java/com/alhadi/cmms/ui/screens/LoginScreen.kt
app/src/main/java/com/alhadi/cmms/ui/screens/LoadingPermissionsScreen.kt
```

## ما تم تنفيذه

- إضافة Firebase Auth عبر Repository وليس من الشاشة مباشرة.
- إضافة Firestore لقراءة `users/{uid}`.
- إضافة AuthGateViewModel لإدارة تسلسل الدخول.
- تسلسل الدخول أصبح:
  1. Splash.
  2. Firebase Auth.
  3. Loading Permissions.
  4. قراءة ملف المستخدم الحقيقي.
  5. تخزين الملف في Room.
  6. فتح شاشة إثبات الدور فقط بعد نجاح القراءة.
- إذا لم يوجد ملف صلاحيات، تظهر شاشة خطأ ولا يتم تحويل المستخدم إلى REQUESTER تلقائيًا.
- إذا كان الدور غير صحيح، تظهر رسالة خطأ.
- إذا كان الحساب غير مفعل، تظهر رسالة خطأ.
- إضافة placeholder `google-services.json.example` للبناء فقط.

## الاختبار السريع المطلوب

- بناء APK من GitHub Actions.
- رفع `app/google-services.json` الحقيقي من Firebase عند الرغبة بتجربة تسجيل الدخول الحقيقي.
- إنشاء مستخدم في Firebase Auth.
- إنشاء مستند `users/{uid}` في Firestore بدور مثل `TECHNICIAN`.
- تسجيل الدخول.
- التأكد أن الشاشة تعرض: جارٍ تحميل الصلاحيات.
- التأكد أنه لا تظهر شاشة طالب خدمة قبل تحميل الدور.
- التأكد أن شاشة الدور تعرض `TECHNICIAN / فني` بعد تحميل الملف.

## المخاطر

- إذا لم يتم استبدال `google-services.json` placeholder بالملف الحقيقي، سيبني التطبيق لكن Firebase Login لن يعمل فعليًا.
- إذا كان مستند Firestore ناقصًا أو الدور مكتوبًا بالعربي، سيظهر خطأ صلاحيات.
- Security Rules لم تُنفذ بعد لأنها في Stage 13.
