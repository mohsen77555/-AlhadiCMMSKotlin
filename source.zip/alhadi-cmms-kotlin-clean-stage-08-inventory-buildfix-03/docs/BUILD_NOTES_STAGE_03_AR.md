# BUILD_NOTES_STAGE_03_AR

تاريخ الملف: 2026-06-15 23:56:33 UTC

## Firebase config

هذه المرحلة تحتاج إلى ملف Firebase الحقيقي:

```text
app/google-services.json
```

تم وضع ملف مثال وملف placeholder للبناء فقط:

```text
app/google-services.json.example
app/google-services.json
```

GitHub Actions يستخدم المثال مؤقتًا فقط إذا لم يجد الملف الحقيقي، حتى يستمر بناء APK للاختبار البنيوي.

## Firestore user profile

المسار المستخدم في Stage 03:

```text
users/{uid}
```

يجب أن يكون `role` قيمة إنجليزية من enum:

```text
ADMIN
MAINTENANCE_MANAGER
SUPERVISOR
TECHNICIAN
WAREHOUSE
REQUESTER
VIEWER
```

## ملاحظة عن KTX

تم استخدام Firebase main modules وليس `firebase-auth-ktx` أو `firebase-firestore-ktx` لأن KTX modules لم تعد مدعومة في Firebase BoM 34+.

## مسار APK

```text
app/build/outputs/apk/debug/app-debug.apk
```
