# AUDIT_STAGE_07_BUILD_FIX_V4_DONE_AR

## اسم المرحلة
Stage 07 Build Fix v4 — إصلاح وتشخيص خطأ Firestore client is offline.

## الملفات المعدلة
- `app/src/main/java/com/alhadi/cmms/firebase/UserProfileRemoteDataSource.kt`

## الملفات الجديدة
- `docs/BUILD_FIX_STAGE_07_V4_FIRESTORE_OFFLINE_AR.md`
- `docs/AUDIT_STAGE_07_BUILD_FIX_V4_DONE_AR.md`
- `docs/AUDIT_STAGE_07_BUILD_FIX_V4_NO_REGRESSION_AR.md`

## ما تم تنفيذه
- إضافة `firestore.enableNetwork().await()` قبل قراءة ملف المستخدم.
- استخدام `Source.SERVER` عند قراءة `users/{uid}`.
- إضافة REST fallback تشخيصي عند خطأ Firestore SDK Offline.
- إضافة قراءة REST محمية بـ Firebase Auth ID token عند توفره.
- إبقاء قراءة المستخدم من `users/{uid}` بدون تغيير.

## اختبار سريع
- تم فحص عدم وجود WebView أو Capacitor أو localStorage أو SharedPreferences في كود التطبيق.
- لم يتم تشغيل Gradle محليًا لأن البيئة لا تحتوي Gradle executable فعلي؛ البناء النهائي يتم من GitHub Actions.

## المخاطر
- REST fallback حل تشخيصي/احتياطي وليس بديلًا نهائيًا عن Firestore SDK.
- يجب إرجاع Firestore Rules إلى قواعد آمنة بعد انتهاء الاختبار.
