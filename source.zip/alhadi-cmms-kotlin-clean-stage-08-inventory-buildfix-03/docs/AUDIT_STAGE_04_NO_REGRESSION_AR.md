# AUDIT_STAGE_04_NO_REGRESSION_AR

## المرحلة السابقة
Stage 03 — Firebase Auth + User Profile

## ما كان موجودًا في المرحلة السابقة
- مشروع Kotlin Native Android.
- Jetpack Compose وMaterial 3.
- Navigation Compose.
- Splash / Login / Loading Permissions / Permission Error.
- Firebase Auth.
- قراءة `users/{uid}`.
- تخزين ملف المستخدم في Room.
- Room Database والجداول الأساسية.
- Repositories مبدئية.
- GitHub Action لبناء APK.
- ملفات التدقيق للمراحل 01 و02 و03.

## ما تم التأكد أنه لم يحذف
- لم يتم حذف `UserRole`.
- لم يتم حذف `AppRoute` بل تم توسيعه فقط.
- لم يتم حذف `AuthGateViewModel` بل تم تحويل الوجهة بعد تحميل الصلاحيات إلى `ROLE_HOME`.
- لم يتم حذف شاشة `RoleReadyScreen` وبقيت كملف سابق للرجوع والتدقيق.
- لم يتم حذف أي Entity أو DAO أو Repository من Stage 02.
- لم يتم حذف Firebase Auth أو Firestore Profile DataSource من Stage 03.

## الشاشات التي بقيت
- SplashScreen
- LoginScreen
- LoadingPermissionsScreen
- PermissionErrorScreen
- RoleReadyScreen

## الشاشات الجديدة
- RoleHomeScreen
- AdminHomeScreen
- MaintenanceManagerHomeScreen
- SupervisorHomeScreen
- TechnicianHomeScreen
- WarehouseHomeScreen
- RequesterHomeScreen
- ViewerHomeScreen

## القواعد التي بقيت
- لا WebView.
- لا Capacitor.
- لا HTML داخل APK.
- لا فتح دور قبل تحميل ملف المستخدم الحقيقي.
- لا تحويل تلقائي إلى طالب خدمة.
- Room يبقى المصدر المحلي.
- Firebase لا يقرأ مباشرة من الشاشات.

## أي تغيير حصل ولماذا
- تمت إضافة `ROLE_HOME` حتى يتم فتح واجهة الدور المناسبة بدل شاشة إثبات الدور المؤقتة.
- تم تحديث GitHub Action لرفع Audit Stage 04 ضمن Artifacts.
- تم رفع versionName إلى `0.4.0-stage04` لتمييز المرحلة.
