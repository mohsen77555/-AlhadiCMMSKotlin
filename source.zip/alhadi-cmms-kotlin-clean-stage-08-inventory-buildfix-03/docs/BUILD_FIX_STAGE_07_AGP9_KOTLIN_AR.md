# إصلاح بناء Stage 07 — توافق AGP 9 مع Kotlin

## سبب الإصلاح

ظهر فشل بناء في GitHub Actions أثناء تنفيذ المهمة `:app:assembleDebug`، وكان ظاهرًا في السجل:

```text
org.jetbrains.kotlin.gradle.internal.diagnostics.AgpWithBuiltInKotlinAppliedCheck
BUILD FAILED
```

هذا يعني أن المشروع كان يستخدم Android Gradle Plugin 9.x مع تطبيق Kotlin Android plugin القديم `org.jetbrains.kotlin.android`، بينما AGP 9 يحتوي على دعم Kotlin مدمج.

## ما تم تعديله

### ملف الجذر `build.gradle.kts`

تم حذف:

```kotlin
id("org.jetbrains.kotlin.android") version "2.4.0" apply false
id("org.jetbrains.kotlin.kapt") version "2.4.0" apply false
```

وتم إضافة:

```kotlin
id("com.android.legacy-kapt") version "9.2.1" apply false
```

مع الإبقاء على:

```kotlin
id("org.jetbrains.kotlin.plugin.compose") version "2.4.0" apply false
```

لأن Compose compiler plugin ما زال مطلوبًا لموديولات Compose.

### ملف `app/build.gradle.kts`

تم حذف:

```kotlin
id("org.jetbrains.kotlin.android")
id("org.jetbrains.kotlin.kapt")
```

وتم إضافة:

```kotlin
id("com.android.legacy-kapt")
```

مع إبقاء:

```kotlin
id("org.jetbrains.kotlin.plugin.compose")
```

### ملف GitHub Action داخل المشروع

تم تعديل أمر البناء من:

```bash
./gradlew :app:assembleDebug
```

إلى:

```bash
gradle :app:assembleDebug
```

لأن المشروع يعتمد على `gradle/actions/setup-gradle` في GitHub Actions، وحتى لا يفشل إذا لم تكن ملفات Gradle Wrapper كاملة داخل ZIP.

## ما لم يتغير

لم يتم حذف أي مرحلة أو شاشة أو قاعدة من Stage 07.

لم يتم تعديل منطق:

- Room
- Firebase Auth
- Firestore Snapshot Listener
- Work Orders
- Sync Queue
- WorkManager
- Audit Logs
- Role Menus

## ملاحظة

هذا إصلاح بناء فقط وليس مرحلة وظيفية جديدة. بعد نجاح البناء يمكن المتابعة إلى Stage 08.
