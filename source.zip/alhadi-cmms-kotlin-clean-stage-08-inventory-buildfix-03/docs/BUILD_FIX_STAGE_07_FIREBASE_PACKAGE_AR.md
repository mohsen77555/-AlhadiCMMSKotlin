# إصلاح Stage 07 Build Fix v3 — مطابقة Firebase Package Name

## المشكلة التي ظهرت في GitHub Actions

ظهر الخطأ التالي:

```text
Execution failed for task ':app:processDebugGoogleServices'.
No matching client found for package name 'com.alhadi.cmms.debug' in app/google-services.json
```

## السبب

كان إعداد debug في `app/build.gradle.kts` يضيف suffix:

```kotlin
applicationIdSuffix = ".debug"
```

وبذلك يصبح اسم حزمة APK أثناء بناء debug هو:

```text
com.alhadi.cmms.debug
```

بينما ملف Firebase الحقيقي `google-services.json` غالبًا يحتوي على عميل Android للحزمة:

```text
com.alhadi.cmms
```

لذلك فشل Google Services Plugin لأنه لم يجد client مطابقًا.

## ما تم إصلاحه

تم حذف `applicationIdSuffix = ".debug"` من buildType debug، وبذلك أصبح Debug APK يستخدم نفس package name:

```text
com.alhadi.cmms
```

وهذا يطابق تطبيق Android المسجل في Firebase.

## النتيجة المتوقعة

بعد رفع هذه النسخة باسم `source.zip` مع وجود `google-services.json` الحقيقي في جذر GitHub، يجب أن يتجاوز البناء خطوة:

```text
:app:processDebugGoogleServices
```

## بديل غير مستخدم الآن

كان يمكن أيضًا تسجيل Android App إضافي في Firebase باسم package:

```text
com.alhadi.cmms.debug
```

لكن الأفضل في هذه المرحلة إبقاء Debug و Release على نفس package name لتقليل التعقيد أثناء البناء من الهاتف.
