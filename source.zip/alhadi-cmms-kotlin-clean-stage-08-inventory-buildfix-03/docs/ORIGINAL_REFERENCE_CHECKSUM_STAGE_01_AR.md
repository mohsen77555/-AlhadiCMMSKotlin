# ORIGINAL_REFERENCE_CHECKSUM_STAGE_01_AR

تم استخدام الملف الأصلي كمرجع متطلبات فقط، ولم يتم إدخال ملفات WebView أو Capacitor أو HTML داخل مشروع Kotlin الجديد.

## اسم الملف المرجعي

```text
alhadi-cmms-apk-github(31).zip
```

## SHA256

```text
7a68b8a3738a76985f86c55a0e75f57b239c6286e27565ac77d4d0e141856c34
```

## السبب

الحفاظ على مرجعية المميزات السابقة بدون تلويث مشروع Kotlin Native بملفات React/HTML/Capacitor.
