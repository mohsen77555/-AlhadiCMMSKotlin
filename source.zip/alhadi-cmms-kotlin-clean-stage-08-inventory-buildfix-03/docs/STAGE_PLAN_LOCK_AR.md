# STAGE_PLAN_LOCK_AR

## المرحلة 01

أساس المشروع فقط: Kotlin Native, Compose, Material 3, Navigation, Splash, Login, Loading Permissions, UserRole, AppRoute, GitHub Actions, Audit.

## المرحلة 02

Room Database: Entities, DAOs, Database, Migrations placeholder, Repositories مبدئية.

## المرحلة 03

Firebase Auth + قراءة users/{uid} + منع ظهور أي دور قبل تحميل البروفايل + تخزين البروفايل في Room.

## المرحلة 04

واجهات حسب الدور: AdminHome, TechnicianHome, WarehouseHome, RequesterHome. لا يظهر تبويب المزيد للفني.

## المرحلة 05

أوامر العمل: Entity, DAO, Repository, ViewModel, القوائم, التفاصيل, بدء العمل, إكمال العمل, Status History, Audit Log.

## المرحلة 06

المزامنة اللحظية: Snapshot Listener داخل Repository حسب الدور، تحديث Room، UI عبر Flow.

## المرحلة 07

Offline Queue: SyncQueue + WorkManager + Retry + مؤشرات الحالة.

## المرحلة 08

المخزون: Items, Warehouses, StockBalances, StockTransactions, Inventory Requests, Issue/Return عبر Transaction.

## المرحلة 09

الأصول: Groups, Locations, Hierarchy, Technical Specs, Meters, Documents, Work History.

## المرحلة 10

الصيانة الوقائية PM: Templates, Steps, Materials, Resources, Schedule, Meter-based PM, Forecast, Generate Work Orders.

## المرحلة 11

التقارير.

## المرحلة 12

المرفقات والكاميرا.

## المرحلة 13

Security Rules وStorage Rules.

## المرحلة 14

تحسين الأداء.

## المرحلة 15

اختبار نهائي شامل.


## Stage 03 status

تم تنفيذ Firebase Auth + Profile في Stage 03، مع منع فتح أي دور قبل تحميل ملف users/{uid}.
