# AUDIT_STAGE_08_BUILD_FIX_02_DONE_AR

## اسم المرحلة
Stage 08 Build Fix 02

## سبب الإصلاح
نسخة Stage 08 Build Fix 01 ما زالت تفشل في GitHub Actions عند:

```text
:app:compileDebugKotlin
```

## ما تم تنفيذه
- اعتماد نسخة أكثر تحفظًا من شاشة Inventory Compose.
- توحيد دوال `InventoryViewModel` مع `InventoryRepository`.
- تثبيت دعم `WorkOrderMaterialEntity` وDAO الخاص بها.
- إبقاء قواعد المخزون:
  - لا تعديل مباشر للرصيد.
  - الصرف بحركة مخزون فقط.
  - الطلبات مرتبطة بأمر عمل.
  - الفني لا يعدل الرصيد.
  - العمليات تدخل SyncQueue وAudit Log.

## الملفات المؤثرة
- `ui/inventory/InventoryModernScreen.kt`
- `ui/inventory/InventoryViewModel.kt`
- `ui/inventory/InventoryUiState.kt`
- `domain/repository/InventoryRepository.kt`
- `data/repository/InventoryRepositoryImpl.kt`
- `database/entity/WorkOrderMaterialEntity.kt`
- `database/dao/WorkOrderMaterialDao.kt`
- `database/AlhadiCmmsDatabase.kt`
- `database/DatabaseMigrations.kt`

## اختبار سريع مطلوب في GitHub
- `:app:assembleDebug`
- تحميل Artifact `Alhadi-CMMS-debug-apk`
- تثبيت APK
- الدخول بحساب ADMIN
- فتح شاشة المخزون
