# AUDIT_STAGE_08_DONE_AR

## اسم المرحلة
Stage 08 — المخزون وقطع الغيار

## الملفات الجديدة

- `core/model/InventoryRequestStatus.kt`
- `core/model/InventoryRequestType.kt`
- `database/entity/WarehouseEntity.kt`
- `database/entity/StockBalanceEntity.kt`
- `database/entity/InventoryRequestEntity.kt`
- `database/entity/InventoryRequestLineEntity.kt`
- `database/entity/WorkOrderMaterialEntity.kt`
- `database/dao/WarehouseDao.kt`
- `database/dao/StockBalanceDao.kt`
- `database/dao/InventoryRequestDao.kt`
- `database/dao/InventoryRequestLineDao.kt`
- `database/dao/WorkOrderMaterialDao.kt`
- `ui/inventory/InventoryUiState.kt`
- `ui/inventory/InventoryViewModel.kt`
- `ui/inventory/InventoryModernScreen.kt`
- `README_STAGE_08_AR.md`

## الملفات المعدلة

- `database/AlhadiCmmsDatabase.kt`
- `database/DatabaseMigrations.kt`
- `database/converter/RoomConverters.kt`
- `domain/repository/InventoryRepository.kt`
- `data/repository/InventoryRepositoryImpl.kt`
- `firebase/SyncRemoteDataSource.kt`
- `sync/SyncEntityType.kt`
- `sync/SyncQueueProcessor.kt`
- `ui/screens/home/RoleHomeScaffold.kt`

## ما تم تنفيذه

1. إضافة جداول المخزون الأساسية: `warehouses`, `stock_balances`, `inventory_requests`, `inventory_request_lines`, `work_order_materials`.
2. رفع Room version من 3 إلى 4.
3. إضافة Migration من 3 إلى 4 بدون حذف بيانات سابقة.
4. تطبيق قاعدة أن الرصيد ينتج من حركات المخزون وليس من تعديل مباشر.
5. إضافة عمليات: إنشاء صنف، إنشاء مخزن، رصيد افتتاحي، استلام، طلب مادة، اعتماد وصرف، صرف لأمر عمل، إرجاع من أمر عمل.
6. منع الفني من تعديل الرصيد أو الصرف المباشر.
7. منع الصرف بدون أمر عمل أو بدون Item Master.
8. منع الصرف إذا الرصيد غير كاف.
9. إضافة SyncQueue و Audit Log لعمليات المخزون المهمة.
11. رفع حركة المخزون إلى Firestore عبر runTransaction حتى لا يعتمد المخزون على last-write-wins.
10. إضافة شاشة مخزون حديثة مرتبطة بـ Room و ViewModel.

## اختبار سريع مقترح

- إنشاء مخزن رئيسي.
- إنشاء صنف.
- إدخال Opening للرصيد.
- إنشاء طلب مادة مرتبط بأمر عمل.
- اعتماد الطلب من حساب Warehouse أو ADMIN.
- التأكد من انخفاض الرصيد بعد الصرف.
- محاولة صرف كمية أكبر من المتاح والتأكد من ظهور رسالة رفض.
- محاولة الصرف من حساب Technician والتأكد من المنع.

## المخاطر

- بعض شاشات المخزون تعتمد على إدخال Work Order ID يدويًا إلى أن تكتمل شاشة الربط المتقدمة.
- قواعد Firestore النهائية لم تكتمل بعد، وستكون في Stage 13.
- لم يتم تشغيل Gradle محليًا داخل بيئة العمل الحالية؛ التحقق النهائي يكون عبر GitHub Actions.
