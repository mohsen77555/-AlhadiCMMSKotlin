# Stage 07 Build Fix v5 — Firestore REST First

## سبب الإصلاح
بعد فتح Firestore Rules مؤقتًا وتصحيح مسار users/{uid}، استمر ظهور الخطأ:

`Failed to get document because the client is offline`

هذا يعني أن المشكلة لم تعد في قواعد Firestore أو اسم المستند غالبًا، بل في طريقة قراءة Firestore SDK أو في تثبيت APK قديم.

## ما تم تعديله
- تغيير نص شاشة الدخول ليظهر بوضوح: Stage 07 v5.
- جعل قراءة ملف المستخدم users/{uid} تستخدم REST API أولًا قبل Firestore SDK.
- إذا فشل REST و SDK معًا، تظهر رسالة تشخيص تجمع الخطأين مع UID.
- إبقاء Firebase Auth وRoom وWorkManager وSyncQueue كما هي.

## معيار الاختبار
عند تثبيت هذه النسخة يجب أن يظهر في شاشة الدخول نص Stage 07 v5. إذا لم يظهر، فهذا يعني أن الهاتف ما زال يستخدم APK قديمًا.
