# AUDIT_STAGE_07_BUILD_FIX_V5_DONE_AR

## اسم المرحلة
Stage 07 Build Fix v5 — Firestore REST-first diagnostics.

## الملفات المعدلة
- app/src/main/java/com/alhadi/cmms/firebase/UserProfileRemoteDataSource.kt
- app/src/main/java/com/alhadi/cmms/ui/screens/LoginScreen.kt
- app/build.gradle.kts

## ما تم تنفيذه
- تغيير قراءة ملف صلاحيات المستخدم لتبدأ عبر Firestore REST API.
- إبقاء Firestore SDK كمسار ثانٍ.
- تحسين رسالة الخطأ لتوضح REST error و SDK error و UID.
- إضافة علامة مرئية في Login Screen: Stage 07 v5.

## اختبار سريع مطلوب
- بناء APK من GitHub Actions.
- حذف التطبيق القديم بالكامل.
- تثبيت APK الجديد.
- التأكد من ظهور Stage 07 v5 على شاشة الدخول.
- تسجيل الدخول بـ tech@test.com.

## المخاطر
- لا تزال Firestore Rules المفتوحة للاختبار غير آمنة ويجب إغلاقها بعد انتهاء التشخيص.
