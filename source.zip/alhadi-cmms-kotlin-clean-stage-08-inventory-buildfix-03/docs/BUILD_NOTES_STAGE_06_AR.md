# BUILD_NOTES_STAGE_06_AR

## البناء

المسار المتوقع للـ APK بعد GitHub Actions:

`app/build/outputs/apk/debug/app-debug.apk`

Artifact:

`Alhadi-CMMS-debug.apk`

## متطلبات Firebase

يجب استبدال:

`app/google-services.json`

بملف Firebase الحقيقي قبل استخدام تسجيل الدخول والمزامنة الحقيقية.

## Firestore Path المستخدم في Stage 06

`companies/{companyId}/workOrders/{workOrderId}`

## ملاحظات مهمة

- مستمع Firestore موجود داخل `WorkOrderRemoteDataSource`.
- الشاشة لا تستخدم Firebase مباشرة.
- عند فشل الرفع، يتم وضع `syncStatus = FAILED` وتظهر رسالة في الواجهة.
- إعادة المحاولة التلقائية عبر WorkManager ستتم في Stage 07.

## تحقق محلي

لم يتم تشغيل Gradle محليًا داخل هذه البيئة لأن بناء Android الكامل يعتمد على GitHub Actions، لكن تم إجراء فحص ثابت للملفات والممنوعات.
