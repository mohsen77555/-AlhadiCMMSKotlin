# BUILD_NOTES_STAGE_05_AR

## البناء

يبقى البناء من خلال GitHub Actions كما في المراحل السابقة.

## الناتج المتوقع

- Artifact باسم: `Alhadi-CMMS-debug.apk`
- المسار داخل المشروع:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## ملاحظات مهمة

- إذا رفعت المشروع كملف ZIP باسم `source.zip` داخل Repository يستخدم Workflow فك الضغط السابق، شغل نفس Workflow السابق.
- إذا فككت المشروع داخل Repository، استخدم Workflow الموجود داخل `.github/workflows/build-debug-apk.yml`.
- Firebase login الحقيقي يحتاج استبدال `app/google-services.json` بملف مشروعك الحقيقي.
- Stage 05 تعمل محليًا عبر Room. مزامنة Firestore ليست ضمن هذه المرحلة.
