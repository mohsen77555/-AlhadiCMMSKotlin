# AUDIT_STAGE_04_DONE_AR

## اسم المرحلة
Stage 04 — واجهات حسب الدور

## الملفات الجديدة
- `app/src/main/java/com/alhadi/cmms/ui/navigation/RoleMenuCatalog.kt`
- `app/src/main/java/com/alhadi/cmms/ui/screens/home/RoleHomeScreen.kt`
- `app/src/main/java/com/alhadi/cmms/ui/screens/home/RoleHomeScaffold.kt`
- `app/src/main/java/com/alhadi/cmms/ui/screens/home/AdminHomeScreen.kt`
- `app/src/main/java/com/alhadi/cmms/ui/screens/home/MaintenanceManagerHomeScreen.kt`
- `app/src/main/java/com/alhadi/cmms/ui/screens/home/SupervisorHomeScreen.kt`
- `app/src/main/java/com/alhadi/cmms/ui/screens/home/TechnicianHomeScreen.kt`
- `app/src/main/java/com/alhadi/cmms/ui/screens/home/WarehouseHomeScreen.kt`
- `app/src/main/java/com/alhadi/cmms/ui/screens/home/RequesterHomeScreen.kt`
- `app/src/main/java/com/alhadi/cmms/ui/screens/home/ViewerHomeScreen.kt`
- `README_STAGE_04_AR.md`
- `docs/STAGE_03_REVIEW_BEFORE_STAGE_04_AR.md`
- `docs/STAGE_04_FILE_MANIFEST.json`
- `docs/STAGE_04_STATIC_SCAN.json`

## الملفات المعدلة
- `app/build.gradle.kts`
- `.github/workflows/build-debug-apk.yml`
- `app/src/main/java/com/alhadi/cmms/ui/auth/AuthScreen.kt`
- `app/src/main/java/com/alhadi/cmms/ui/auth/AuthGateViewModel.kt`
- `app/src/main/java/com/alhadi/cmms/ui/navigation/AppRoute.kt`
- `app/src/main/java/com/alhadi/cmms/ui/navigation/AppNavHost.kt`

## ما تم تنفيذه
- فتح واجهة الدور فقط بعد تحميل ملف المستخدم الحقيقي.
- إنشاء قوائم شاشة مختلفة حسب الدور.
- عدم إظهار خيار "المزيد" للفني.
- عدم إظهار شاشات المخزن للفني.
- عدم إظهار إدارة المستخدمين لطالب الخدمة أو الفني أو المخزن.
- إضافة واجهات منظمة جزئيًا بدون تنفيذ بيانات أو عمليات قبل مراحلها.

## اختبار سريع
- عند `ADMIN`: تظهر شاشة المدير وبها خيار "المزيد".
- عند `TECHNICIAN`: تظهر شاشة الفني ولا يوجد خيار "المزيد".
- عند `WAREHOUSE`: تظهر قوائم المخزون وطلبات الصرف والحركات فقط.
- عند `REQUESTER`: تظهر طلب جديد وطلباتي والإشعارات وحسابي فقط.
- عند غياب `profile`: تبقى شاشة تحميل الصلاحيات ولا تفتح واجهة دور.

## المخاطر
- الواجهات الحالية هي هيكل تنظيمي؛ التنفيذ الحقيقي لأوامر العمل يبدأ في Stage 05.
- لا يزال ملف `google-services.json` placeholder حتى يستبدل بملف Firebase الحقيقي.
