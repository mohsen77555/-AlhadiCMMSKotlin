# FIRESTORE_INDEXES_STAGE_06_AR

## فهارس Firestore المطلوبة مبدئيًا لأوامر العمل

لأن Stage 06 يستخدم Snapshot Listener حسب الدور، غالبًا سيطلب Firestore إنشاء فهارس مركبة لهذه الاستعلامات:

1. `companies/{companyId}/workOrders`
   - `isDeleted ASC`
   - `updatedAt DESC`

2. `companies/{companyId}/workOrders`
   - `isDeleted ASC`
   - `assignedSupervisorId ASC`
   - `updatedAt DESC`

3. `companies/{companyId}/workOrders`
   - `isDeleted ASC`
   - `assignedTechnicianId ASC`
   - `updatedAt DESC`

## ملاحظة

إذا ظهر خطأ في GitHub أو التطبيق يقول إن Firestore يحتاج Index، افتح الرابط الذي يظهر في الخطأ من Firebase Console وأنشئ الفهرس المقترح.
