# BUILD_NOTES_STAGE_08_BUILD_FIX_03_AR

## سبب الإصلاح
GitHub Actions فشل في `:app:compileDebugKotlin` وأظهر:

```text
SyncRemoteDataSource.kt:86:33
operator modifier is required on fun Comparable.compareTo
```

وكان السطر يعتمد على دالة غير موجودة `remoteDelta()`.

## الإصلاح
تمت إضافة دوال محلية داخل `SyncRemoteDataSource`:

```kotlin
private fun StockTransactionEntity.onHandRemoteDelta(): Double
private fun StockTransactionEntity.availableRemoteDelta(): Double
```

## تعليمات البناء
ارفع هذا الملف إلى GitHub باسم:

```text
source.zip
```

واترك:

```text
google-services.json
```

كما هو، ثم شغّل GitHub Actions.
