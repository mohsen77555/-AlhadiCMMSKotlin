# BUILD_NOTES_STAGE_02_AR

## طريقة البناء
البناء يتم من GitHub Actions:

1. ارفع ZIP الحالي إلى GitHub باسم `source.zip` أو ارفع محتوى المشروع.
2. افتح Actions.
3. شغل Workflow: Build Alhadi CMMS Debug APK.
4. حمل Artifact باسم: Alhadi-CMMS-debug.apk.

## ملاحظات Room
- تم استخدام Room Runtime وRoom KTX وRoom Compiler.
- تم تفعيل `room.schemaLocation` حتى يتم تصدير مخطط قاعدة البيانات.
- قاعدة البيانات حالياً version = 1.
- `DatabaseMigrations.all()` موجود كـ placeholder للمراحل القادمة.

## ملاحظة مهمة
لا تستخدم destructive migration لاحقًا إلا إذا وافق المدير صراحة؛ كل تعديل حقيقي في الجداول يجب أن يكون معه Migration واضح.
