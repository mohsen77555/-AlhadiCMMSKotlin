# BUILD_NOTES_STAGE_01_AR

## البناء من GitHub Actions

Workflow:

```text
.github/workflows/build-debug-apk.yml
```

ينتج:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Artifact:

```text
Alhadi-CMMS-debug.apk
```

## ملاحظة Gradle

تم استخدام `gradle/actions/setup-gradle` لتوفير Gradle داخل GitHub Actions، وملف `gradlew` في هذه المرحلة يمرر الأوامر إلى Gradle المثبت في بيئة GitHub.

عند الحاجة لاحقًا يمكن إضافة Gradle Wrapper قياسي كامل مع `gradle-wrapper.jar` من Android Studio أو Gradle محلي.
