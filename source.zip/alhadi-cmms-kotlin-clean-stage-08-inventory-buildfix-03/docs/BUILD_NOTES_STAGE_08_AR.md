# BUILD_NOTES_STAGE_08_AR

## البناء

يتم البناء من GitHub Actions كما في المراحل السابقة:

1. ارفع هذا الملف باسم `source.zip`.
2. اترك `google-services.json` الصحيح في جذر GitHub.
3. شغل Action.
4. حمل `Alhadi-CMMS-debug-apk`.

## ملاحظات تقنية

- Room version أصبح 4.
- أضيفت Migration 3→4.
- أضيفت كيانات المخزون والمخازن وطلبات الصرف.
- لا تستخدم الشاشة Firebase مباشرة.
- جميع عمليات الصرف والإرجاع تستخدم Repository + Room Transaction.

## التحقق المحلي

لم يتم تشغيل Gradle محليًا داخل هذه البيئة بسبب عدم توفر Gradle executable محليًا. التحقق النهائي من البناء يتم عبر GitHub Actions.
