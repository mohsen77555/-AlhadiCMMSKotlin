# إصلاح Stage 07 Build Fix v4 — Firestore client is offline

## سبب الإصلاح
بعد نجاح GitHub Actions وظهور السطر:

`Real Firebase google-services.json injected into app/.`

استمر التطبيق بعرض الخطأ:

`Failed to get document because the client is offline`

كما أن فتح قواعد Firestore مؤقتًا `allow read, write: if true` لم يغيّر النتيجة، لذلك لم تعد المشكلة من Security Rules.

## ما تم تعديله
تم تعديل الملف:

`app/src/main/java/com/alhadi/cmms/firebase/UserProfileRemoteDataSource.kt`

### التغييرات
1. إجبار Firestore على تفعيل الشبكة قبل قراءة ملف المستخدم:
   - `firestore.enableNetwork().await()`

2. قراءة ملف المستخدم من السيرفر صراحة بدل القراءة الافتراضية:
   - `get(Source.SERVER)`

3. إضافة REST fallback تشخيصي عند خطأ Firestore SDK offline:
   - يستخدم `FirebaseApp.getInstance().options.projectId`
   - يستخدم `FirebaseApp.getInstance().options.apiKey`
   - يستخدم ID token من Firebase Auth عند توفره
   - يقرأ المستند من:
     `https://firestore.googleapis.com/v1/projects/{projectId}/databases/(default)/documents/users/{uid}`

4. إبقاء Room كمصدر محلي بعد تحميل ملف المستخدم، وعدم تغيير معمارية التطبيق.

## ما لم يتغير
- لم يتم حذف Firebase Auth.
- لم يتم حذف Room.
- لم يتم حذف WorkManager.
- لم يتم حذف SyncQueue.
- لم يتم إضافة WebView.
- لم يتم إضافة Capacitor.
- لم يتم تغيير الأدوار المعتمدة.
- لم يتم تغيير مسار ملف المستخدم: `users/{uid}`.

## هدف الإصلاح
السماح للتطبيق بتحميل ملف الصلاحيات حتى إذا أعطى Firestore Android SDK خطأ Offline على جهاز أو شبكة معينة، مع إبقاء Firestore SDK هو المسار الأساسي.

## ملاحظة أمنية
إذا كنت قد فتحت Firestore Rules مؤقتًا إلى:

`allow read, write: if true;`

فيجب إرجاعها بعد نجاح الاختبار إلى قواعد آمنة.
