# BUILD_NOTES_STAGE_07_AR

## البناء
تم تحديث `versionCode` إلى 7 و `versionName` إلى `0.7.0-stage07`.

## الاعتمادية الجديدة
تمت إضافة:

```kotlin
implementation("androidx.work:work-runtime-ktx:2.11.2")
```

## التطبيق
تمت إضافة `AlhadiCmmsApplication` إلى AndroidManifest لتشغيل جدولة المزامنة عند فتح التطبيق.

## GitHub Actions
تم تحديث Artifact التدقيق ليشمل ملفات Stage 07.

## ملاحظة مهمة
لا تحفظ الصور أو الملفات داخل Room أو Firestore كـ Base64. هذه المرحلة لم تضف المرفقات؛ سيتم ذلك في Stage 12 حسب الخطة.

## اختبار البناء
لم يتم تشغيل Gradle Android محليًا في هذه البيئة. الاختبار النهائي يتم من GitHub Actions بعد رفع `source.zip`.


## Build Fix v3

تم حذف `applicationIdSuffix = ".debug"` من debug buildType حتى يطابق اسم الحزمة `com.alhadi.cmms` ملف Firebase `google-services.json`.
