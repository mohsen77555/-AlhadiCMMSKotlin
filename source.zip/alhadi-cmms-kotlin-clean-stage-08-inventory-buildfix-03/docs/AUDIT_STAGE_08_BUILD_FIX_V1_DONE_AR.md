# AUDIT_STAGE_08_BUILD_FIX_V1_DONE_AR

## اسم المرحلة
Stage 08 Build Fix v1 — إصلاح فشل البناء

## ما تم
- إصلاح توقيع `FormCard` في شاشة المخزون.
- إضافة `ColumnScope` الصحيح في Compose.
- عدم تعديل قواعد المخزون أو Room أو SyncQueue.

## اختبار سريع
- فحص ثابت للتأكد من زوال `Column.() -> Unit`.
- فحص بقاء ملفات Stage 08 الأساسية.

## المخاطر
لم يتم تشغيل Gradle محليًا داخل البيئة، والتحقق النهائي من GitHub Actions.
