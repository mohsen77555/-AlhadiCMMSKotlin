# BUILD_NOTES_STAGE_04_AR

## طريقة البناء
نفس طريقة المراحل السابقة:

```bash
./gradlew :app:assembleDebug --no-daemon --stacktrace
```

في GitHub Actions يتم تثبيت Gradle 9.4.1 ثم بناء APK ورفعه باسم:

`Alhadi-CMMS-debug.apk`

## ملاحظات
- لم تتم إضافة Dependencies جديدة في Stage 04.
- التغيير UI/Navigation فقط.
- ملف Firebase placeholder لا يزال موجودًا للبناء فقط.
