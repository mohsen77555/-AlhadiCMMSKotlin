# BUILD_NOTES_STAGE_08_BUILD_FIX_02_AR

## طريقة البناء
ارفع ZIP باسم:

```text
source.zip
```

ثم شغّل GitHub Actions.

## عند الفشل مرة أخرى
افتح Log ثم استخدم Search logs وابحث عن:

```text
e:
```

أو:

```text
error:
```

وأرسل أول 10 أسطر خطأ، لأن نهاية السجل تعرض فقط:

```text
Process completed with exit code 1
```

ولا تكفي لمعرفة سبب Kotlin الحقيقي.
