# BUILD_NOTES_STAGE_07_2_AR

## البناء

ارفع هذا المشروع إلى GitHub باسم:

```text
source.zip
```

واترك ملف Firebase الصحيح في جذر المستودع باسم:

```text
google-services.json
```

ثم شغل GitHub Actions.

## ملاحظات

- لا تستخدم ملف google-services.json من Web App.
- يجب أن يكون Android App package هو `com.alhadi.cmms`.
- بعد تثبيت APK الجديد، احذف النسخة القديمة أولًا إذا لم تظهر الواجهة الحديثة.
