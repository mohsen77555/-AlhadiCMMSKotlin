# AUDIT_STAGE_07_DONE_AR

## اسم المرحلة
Stage 07 — Offline Queue + WorkManager + Retry Policy

## الملفات الجديدة
- `app/src/main/java/com/alhadi/cmms/AlhadiCmmsApplication.kt`
- `app/src/main/java/com/alhadi/cmms/sync/SyncEntityType.kt`
- `app/src/main/java/com/alhadi/cmms/sync/SyncBackoffPolicy.kt`
- `app/src/main/java/com/alhadi/cmms/sync/SyncProcessResult.kt`
- `app/src/main/java/com/alhadi/cmms/sync/SyncQueueScheduler.kt`
- `app/src/main/java/com/alhadi/cmms/sync/SyncQueueWorker.kt`
- `app/src/main/java/com/alhadi/cmms/sync/SyncQueueProcessor.kt`
- `app/src/main/java/com/alhadi/cmms/firebase/SyncRemoteDataSource.kt`
- `app/src/main/java/com/alhadi/cmms/firebase/WorkOrderRemoteState.kt`
- `README_STAGE_07_AR.md`
- `docs/STAGE_06_REVIEW_BEFORE_STAGE_07_AR.md`
- `docs/AUDIT_STAGE_07_DONE_AR.md`
- `docs/AUDIT_STAGE_07_NO_REGRESSION_AR.md`
- `docs/BUILD_NOTES_STAGE_07_AR.md`

## الملفات المعدلة
- `app/build.gradle.kts`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/alhadi/cmms/data/repository/WorkOrderRepositoryImpl.kt`
- `app/src/main/java/com/alhadi/cmms/database/dao/SyncQueueDao.kt`
- `app/src/main/java/com/alhadi/cmms/database/dao/WorkOrderDao.kt`
- `app/src/main/java/com/alhadi/cmms/database/dao/WorkOrderStatusHistoryDao.kt`
- `app/src/main/java/com/alhadi/cmms/database/dao/WorkOrderExecutionLogDao.kt`
- `app/src/main/java/com/alhadi/cmms/database/dao/AuditLogDao.kt`
- `app/src/main/java/com/alhadi/cmms/domain/repository/SyncQueueRepository.kt`
- `app/src/main/java/com/alhadi/cmms/data/repository/SyncQueueRepositoryImpl.kt`
- `app/src/main/java/com/alhadi/cmms/ui/workorders/WorkOrderViewModel.kt`
- `app/src/main/java/com/alhadi/cmms/ui/workorders/WorkOrderUiState.kt`
- `app/src/main/java/com/alhadi/cmms/ui/workorders/WorkOrderStage05Screen.kt`
- `.github/workflows/build-debug-apk.yml`

## ما تم تنفيذه
- WorkManager يعمل عند فتح التطبيق عبر `AlhadiCmmsApplication`.
- WorkManager يعمل بعد إنشاء/بدء/إكمال/إغلاق/تغيير حالة أمر العمل.
- WorkManager يعمل دوريًا كل 15 دقيقة كحد أدنى مسموح به لـ PeriodicWork.
- كل عملية أمر عمل تدخل `sync_queue` بدل الاعتماد على الرفع المباشر فقط.
- يتم رفع Work Order و Status History و Execution Logs و Audit Logs إلى Firestore.
- عند النجاح تصبح العملية `SYNCED`.
- عند الفشل تصبح `FAILED` مع `retryCount`, `lastError`, `nextRetryAt`.
- عند التعارض تصبح `CONFLICT` ولا يعاد رفعها تلقائيًا.
- يتم كشف تعارض إذا كان أمر العمل ملغيًا في السيرفر أو تغيرت حالته/نسخته قبل رفع التعديل المحلي.
- واجهة أوامر العمل تعرض ملخص الطابور: Pending / Failed / Conflict.

## اختبار سريع منطقي
- عند فصل الإنترنت وإكمال أمر عمل: يحفظ محليًا وتظهر الحالة Pending/Failed حسب محاولة WorkManager.
- عند رجوع الإنترنت: WorkManager يعيد محاولة الرفع.
- إذا تغيرت حالة السيرفر قبل الرفع: العملية تتحول إلى Conflict.

## المخاطر
- اختبار البناء الفعلي يتم عبر GitHub Actions لأن بيئة العمل الحالية لا تحتوي Gradle Android كامل.
- Firebase الحقيقي يحتاج ملف `google-services.json` الحقيقي بدل placeholder.
- إدارة التعارضات العميقة ستتوسع لاحقًا بعد اكتمال المخزون والمواد.
