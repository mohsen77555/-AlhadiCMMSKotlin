# إصلاح بناء Stage 08

تم إصلاح فشل compileDebugKotlin الذي ظهر في GitHub Actions.

## السبب

كان ملف `InventoryModernScreen.kt` يستخدم نوع مستقبل Compose غير صحيح في `FormCard`:

```kotlin
content: @Composable Column.() -> Unit
```

`Column` في Compose دالة وليست نوع Scope. النوع الصحيح هو `ColumnScope`.

## الإصلاح

- إضافة import:

```kotlin
import androidx.compose.foundation.layout.ColumnScope
```

- تعديل توقيع `FormCard` إلى:

```kotlin
content: @Composable ColumnScope.() -> Unit
```

## عدم التراجع

لم يتم حذف Stage 08 أو جداول المخزون أو واجهة UI الحديثة.
