# MASTER_REQUIREMENTS_LOCK_AR

هذا الملف يقفل المتطلبات الأساسية التي لا يجوز حذفها أثناء البناء المرحلي.

## التقنية الإلزامية

- Kotlin Native Android.
- Jetpack Compose.
- Material 3.
- Navigation Compose.
- ViewModel.
- Kotlin Flow / StateFlow.
- Coroutines.
- Room Database كمصدر محلي أساسي للشاشات.
- DataStore للإعدادات الصغيرة فقط.
- WorkManager لطابور المزامنة.
- Firebase Auth.
- Cloud Firestore.
- Firebase Storage.
- Firebase Crashlytics.
- Firebase Cloud Messaging لاحقًا.

## ممنوعات ثابتة

- WebView.
- Capacitor.
- HTML داخل APK.
- Screen to Firebase مباشرة.
- تحميل كل بيانات النظام عند دخول الفني.
- إظهار طالب خدمة قبل تحميل الدور الحقيقي.
- زر تحديث كحل أساسي للمزامنة.
- تخزين الصور Base64 في Firestore أو Room.
- تعديل المخزون بدون حركة مخزون.
- صرف مخزون بدون Work Order أو Inventory Request.
- حذف Audit Logs.

## الأدوار المعتمدة داخليًا

```kotlin
enum class UserRole {
    ADMIN,
    MAINTENANCE_MANAGER,
    SUPERVISOR,
    TECHNICIAN,
    WAREHOUSE,
    REQUESTER,
    VIEWER
}
```

## حالات أمر العمل المعتمدة لاحقًا

```kotlin
enum class WorkOrderStatus {
    DRAFT,
    REQUESTED,
    APPROVED,
    PLANNED,
    ASSIGNED,
    IN_PROGRESS,
    WAITING_MATERIAL,
    WAITING_APPROVAL,
    COMPLETED_BY_TECHNICIAN,
    CLOSED,
    CANCELLED
}
```

## حالات طلب الصيانة المعتمدة لاحقًا

```kotlin
enum class WorkRequestStatus {
    SUBMITTED,
    UNDER_REVIEW,
    APPROVED,
    REJECTED,
    CONVERTED_TO_WORK_ORDER,
    CANCELLED
}
```

## حالات المزامنة المعتمدة لاحقًا

```kotlin
enum class SyncStatus {
    LOCAL_ONLY,
    PENDING,
    SYNCING,
    SYNCED,
    FAILED,
    CONFLICT
}
```

## مجموعات الأصول المطلوب دعمها لاحقًا

- Bucket Elevators
- Chain Conveyors
- Screw Conveyors
- Silo Fans
- Silo Gates
- Sensors
- Rollermills
- Plansifters
- Purifiers
- Compressors
- Packing Machines
- Scales

## معيار القبول العام

- APK حقيقي وليس 6KB أو 7KB.
- لا توجد شاشة فارغة غير مقصودة.
- لا يظهر دور خطأ عند الدخول.
- الفني يرى أوامره فقط.
- المزامنة تعمل بدون زر تحديث كشرط أساسي.
- المخزون لا يتغير إلا بحركة.
- Offline-first يعمل عبر Room ثم SyncQueue ثم WorkManager.
- كل مرحلة لها Audit.
