# إصلاح بناء Stage 07 - Build Fix v2

## سبب الإصلاح

ظهر فشل في GitHub Actions داخل خطوة Build debug APK، وكانت النسخة السابقة مرتبطة بمشكلة توافق Gradle/Kotlin حول:

`AgpWithBuiltInKotlinAppliedCheck`

هذه المشكلة تظهر مع Android Gradle Plugin 9 عندما يكون دعم Kotlin المدمج مفعّلًا مع إعدادات Kotlin/Compose/Kapt غير متوافقة بالكامل.

## ما تم تغييره

1. إضافة `gradle.properties`.
2. تفعيل وضع توافق مؤقت:
   - `android.builtInKotlin=false`
   - `android.newDsl=false`
3. استخدام Kotlin Android plugin القياسي:
   - `org.jetbrains.kotlin.android` version `2.3.21`
4. استخدام Kotlin Kapt القياسي:
   - `org.jetbrains.kotlin.kapt` version `2.3.21`
5. استخدام Compose Compiler plugin الرسمي version `2.3.21`.
6. إبقاء Android Gradle Plugin version `9.2.1`.
7. إبقاء Gradle version `9.4.1` في GitHub Actions.
8. إضافة Java 17 compile options.
9. تحديث workflow الداخلي لإظهار stacktrace بشكل أوضح.

## ما لم يتغير

لم يتم تغيير منطق التطبيق:

- Room بقي كما هو.
- Firebase Auth/Profile بقي كما هو.
- واجهات الأدوار بقيت كما هي.
- أوامر العمل بقيت كما هي.
- Firestore listener بقي كما هو.
- WorkManager و SyncQueue بقيا كما هما.
- لا يوجد WebView.
- لا يوجد Capacitor.
- لا يوجد localStorage.
- لا يوجد SharedPreferences.

## ملاحظة

هذا إصلاح توافق للبناء فقط، وليس مرحلة جديدة. بعد نجاح البناء يمكن إكمال Stage 08.
