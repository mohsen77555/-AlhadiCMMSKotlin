# AUDIT_STAGE_06_DONE_AR

## اسم المرحلة

Stage 06 — المزامنة اللحظية Firestore Snapshot Listener لأوامر العمل.

## الملفات الجديدة

- `firebase/WorkOrderRemoteDataSource.kt`
- `firebase/WorkOrderRemoteBatch.kt`
- `sync/WorkOrderRealtimeSyncState.kt`
- `README_STAGE_06_AR.md`
- `docs/STAGE_05_REVIEW_BEFORE_STAGE_06_AR.md`
- `docs/AUDIT_STAGE_06_DONE_AR.md`
- `docs/AUDIT_STAGE_06_NO_REGRESSION_AR.md`
- `docs/BUILD_NOTES_STAGE_06_AR.md`
- `docs/FIRESTORE_INDEXES_STAGE_06_AR.md`
- `docs/STAGE_06_STATIC_SCAN.json`
- `docs/STAGE_06_FILE_MANIFEST.json`

## الملفات المعدلة

- `app/build.gradle.kts`
- `.github/workflows/build-debug-apk.yml`
- `core/model/SyncStatus.kt`
- `database/entity/WorkOrderEntity.kt`
- `database/AlhadiCmmsDatabase.kt`
- `database/DatabaseMigrations.kt`
- `domain/repository/WorkOrderRepository.kt`
- `data/repository/WorkOrderRepositoryImpl.kt`
- `ui/workorders/WorkOrderUiState.kt`
- `ui/workorders/WorkOrderViewModel.kt`
- `ui/workorders/WorkOrderStage05Screen.kt`

## ما تم تنفيذه

- إضافة Firestore Snapshot Listener لأوامر العمل داخل Repository/RemoteDataSource وليس داخل UI.
- بناء الاستعلام حسب الدور:
  - Admin / Maintenance Manager / Viewer: أوامر الشركة.
  - Supervisor: أوامر نطاق المشرف.
  - Technician: أوامر الفني المسندة له.
  - Warehouse / Requester: لا يتم تشغيل مستمع أوامر عمل في هذه المرحلة.
- كل دفعة Firestore يتم تحويلها إلى `WorkOrderEntity` ثم حفظها في Room.
- UI تستمر في القراءة من Room Flow فقط.
- إضافة `syncStatus`, `lastSyncError`, `lastRemoteUpdatedAt` إلى `work_orders`.
- رفع Room database version من 2 إلى 3 مع Migration واضح.
- محاولة رفع مباشرة إلى Firestore عند:
  - إنشاء أمر عمل.
  - بدء أمر عمل.
  - إكمال أمر عمل.
  - تغيير حالة أمر عمل.
  - إغلاق أمر عمل.
- عرض مؤشر حالة المزامنة في الواجهة.

## اختبار سريع ثابت

- تم فحص عدم وجود WebView أو Capacitor أو localStorage أو SharedPreferences.
- تم فحص أن `addSnapshotListener` موجود في `WorkOrderRemoteDataSource` فقط وليس في شاشة Compose.
- تم فحص أن شاشة أوامر العمل ما زالت تعتمد على ViewModel وRoom Flow.
- تم تحديث GitHub Actions ليشمل ملفات تدقيق Stage 06.

## المخاطر

- البناء النهائي يجب تشغيله في GitHub Actions.
- إذا لم تكن Firestore Indexes موجودة، سيطلب Firebase إنشاء Index من Console.
- WorkManager Queue لم يبدأ بعد؛ لذلك عند فشل الرفع يتم وضع الحالة `FAILED` فقط، وسيعالج Stage 07 إعادة المحاولة التلقائية.
- Conflict Handling المتقدم غير منفذ بعد وسيأتي لاحقًا.
