# Stage 01: no custom ProGuard/R8 rules yet.
# Future stages will add rules when Firebase/Room/serialization are introduced.
