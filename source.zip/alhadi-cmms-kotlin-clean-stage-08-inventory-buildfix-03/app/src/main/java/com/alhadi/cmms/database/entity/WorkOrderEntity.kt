package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.core.model.WorkOrderStatus

@Entity(
    tableName = "work_orders",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["companyId", "workOrderNo"], unique = true),
        Index(value = ["requestId"]),
        Index(value = ["assetId"]),
        Index(value = ["assignedTechnicianId"]),
        Index(value = ["assignedSupervisorId"]),
        Index(value = ["status"]),
        Index(value = ["syncStatus"]),
        Index(value = ["dueAt"]),
        Index(value = ["companyId", "status", "dueAt"])
    ]
)
data class WorkOrderEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val workOrderNo: String,
    val requestId: String? = null,
    val assetId: String? = null,
    val title: String,
    val description: String? = null,
    val status: WorkOrderStatus = WorkOrderStatus.DRAFT,
    val priority: String = "MEDIUM",
    val assignedSupervisorId: String? = null,
    val assignedTechnicianId: String? = null,
    val plannedStartAt: Long? = null,
    val dueAt: Long? = null,
    val startedAt: Long? = null,
    val startedBy: String? = null,
    val completedAt: Long? = null,
    val completedBy: String? = null,
    val closedAt: Long? = null,
    val closedBy: String? = null,
    val materialAvailable: Boolean = false,
    val requiresMaterialCheck: Boolean = true,
    val actualLaborMinutes: Int? = null,
    val technicianCompletionNotes: String? = null,
    val executionSummary: String? = null,
    val lastStatusReason: String? = null,
    val createdAt: Long,
    val createdBy: String,
    val updatedAt: Long,
    val updatedBy: String,
    val deletedAt: Long? = null,
    val deletedBy: String? = null,
    val isDeleted: Boolean = false,
    val version: Long = 1,
    val syncVersion: Long = 0,
    val syncStatus: SyncStatus = SyncStatus.SYNCED,
    val lastSyncError: String? = null,
    val lastRemoteUpdatedAt: Long? = null
)
