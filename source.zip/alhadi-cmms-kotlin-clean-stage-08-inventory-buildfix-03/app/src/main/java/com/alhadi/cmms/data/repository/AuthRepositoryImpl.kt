package com.alhadi.cmms.data.repository

import com.alhadi.cmms.core.auth.InactiveUserException
import com.alhadi.cmms.core.auth.MissingSignedInUserException
import com.alhadi.cmms.core.auth.MissingUserProfileException
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.domain.repository.AuthRepository
import com.alhadi.cmms.domain.repository.UserRepository
import com.alhadi.cmms.firebase.FirebaseAuthGateway
import com.alhadi.cmms.firebase.FirebaseUserSnapshot
import com.alhadi.cmms.firebase.UserProfileRemoteDataSource

class AuthRepositoryImpl(
    private val authGateway: FirebaseAuthGateway,
    private val userProfileRemoteDataSource: UserProfileRemoteDataSource,
    private val userRepository: UserRepository
) : AuthRepository {
    override fun hasSignedInUser(): Boolean = authGateway.currentUser() != null

    override suspend fun signInAndLoadProfile(
        email: String,
        password: String
    ): UserEntity {
        val user = authGateway.signInWithEmailAndPassword(email, password)
        return loadAndCacheProfile(user)
    }

    override suspend fun loadCurrentUserProfile(): UserEntity {
        val user = authGateway.currentUser() ?: throw MissingSignedInUserException()
        return loadAndCacheProfile(user)
    }

    override fun signOut() {
        authGateway.signOut()
    }

    private suspend fun loadAndCacheProfile(user: FirebaseUserSnapshot): UserEntity {
        val profile = userProfileRemoteDataSource.fetchUserProfile(
            uid = user.uid,
            fallbackEmail = user.email,
            fallbackDisplayName = user.displayName
        ) ?: throw MissingUserProfileException(user.uid)

        if (!profile.isActive || profile.isDeleted) {
            throw InactiveUserException(user.uid)
        }

        userRepository.cacheUserProfile(profile)
        return profile
    }
}
