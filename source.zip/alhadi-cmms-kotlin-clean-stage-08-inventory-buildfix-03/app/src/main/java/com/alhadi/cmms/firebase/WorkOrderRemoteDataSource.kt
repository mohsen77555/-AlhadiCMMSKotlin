package com.alhadi.cmms.firebase

import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.core.model.WorkOrderStatus
import com.alhadi.cmms.database.entity.WorkOrderEntity
import com.alhadi.cmms.database.entity.UserEntity
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class WorkOrderRemoteDataSource(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    fun listenForRole(profile: UserEntity): Flow<WorkOrderRemoteBatch> = callbackFlow {
        val query = buildRoleQuery(profile)
        if (query == null) {
            trySend(
                WorkOrderRemoteBatch(
                    orders = emptyList(),
                    noteAr = "هذا الدور لا يحتاج مستمع أوامر عمل مباشر."
                )
            )
            close()
            return@callbackFlow
        }

        val registration = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }

            val orders = snapshot
                ?.documents
                ?.mapNotNull { document -> document.toWorkOrderEntity(profile.companyId) }
                ?.filterNot { it.isDeleted }
                ?.sortedByDescending { it.updatedAt }
                .orEmpty()

            trySend(
                WorkOrderRemoteBatch(
                    orders = orders,
                    noteAr = "استقبال ${orders.size} أمر عمل من Firestore حسب دور ${profile.role.name}."
                )
            )
        }

        awaitClose { registration.remove() }
    }

    suspend fun upsertWorkOrder(workOrder: WorkOrderEntity) {
        workOrdersCollection(workOrder.companyId)
            .document(workOrder.id)
            .set(workOrder.toFirestoreMap(), SetOptions.merge())
            .await()
    }

    private fun buildRoleQuery(profile: UserEntity): Query? {
        val collection = workOrdersCollection(profile.companyId)

        return when (profile.role) {
            UserRole.ADMIN,
            UserRole.MAINTENANCE_MANAGER,
            UserRole.VIEWER -> collection
                .limit(DEFAULT_ROLE_LIMIT)

            UserRole.SUPERVISOR -> collection
                .whereEqualTo("assignedSupervisorId", profile.id)
                .limit(DEFAULT_ROLE_LIMIT)

            UserRole.TECHNICIAN -> collection
                .whereEqualTo("assignedTechnicianId", profile.id)
                .limit(DEFAULT_ROLE_LIMIT)

            UserRole.WAREHOUSE,
            UserRole.REQUESTER -> null
        }
    }

    private fun workOrdersCollection(companyId: String) = firestore
        .collection("companies")
        .document(companyId)
        .collection("workOrders")

    private fun DocumentSnapshot.toWorkOrderEntity(fallbackCompanyId: String): WorkOrderEntity? {
        val now = System.currentTimeMillis()
        val title = getString("title") ?: return null
        val status = enumOrDefault(getString("status"), WorkOrderStatus.DRAFT)
        return WorkOrderEntity(
            id = getString("id") ?: id,
            companyId = getString("companyId") ?: fallbackCompanyId,
            workOrderNo = getString("workOrderNo") ?: "WO-${id.take(8).uppercase()}",
            requestId = getString("requestId"),
            assetId = getString("assetId"),
            title = title,
            description = getString("description"),
            status = status,
            priority = getString("priority") ?: "MEDIUM",
            assignedSupervisorId = getString("assignedSupervisorId"),
            assignedTechnicianId = getString("assignedTechnicianId"),
            plannedStartAt = getLong("plannedStartAt"),
            dueAt = getLong("dueAt"),
            startedAt = getLong("startedAt"),
            startedBy = getString("startedBy"),
            completedAt = getLong("completedAt"),
            completedBy = getString("completedBy"),
            closedAt = getLong("closedAt"),
            closedBy = getString("closedBy"),
            materialAvailable = getBoolean("materialAvailable") ?: false,
            requiresMaterialCheck = getBoolean("requiresMaterialCheck") ?: true,
            actualLaborMinutes = getLong("actualLaborMinutes")?.toInt(),
            technicianCompletionNotes = getString("technicianCompletionNotes"),
            executionSummary = getString("executionSummary"),
            lastStatusReason = getString("lastStatusReason"),
            createdAt = getLong("createdAt") ?: now,
            createdBy = getString("createdBy") ?: "remote",
            updatedAt = getLong("updatedAt") ?: now,
            updatedBy = getString("updatedBy") ?: "remote",
            deletedAt = getLong("deletedAt"),
            deletedBy = getString("deletedBy"),
            isDeleted = getBoolean("isDeleted") ?: false,
            version = getLong("version") ?: 1L,
            syncVersion = getLong("syncVersion") ?: 0L,
            syncStatus = SyncStatus.SYNCED,
            lastSyncError = null,
            lastRemoteUpdatedAt = getLong("updatedAt") ?: now
        )
    }

    private fun WorkOrderEntity.toFirestoreMap(): Map<String, Any?> {
        val assignedTechIds = assignedTechnicianId
            ?.takeIf { it.isNotBlank() }
            ?.let { listOf(it) }
            .orEmpty()

        return mapOf(
            "id" to id,
            "companyId" to companyId,
            "workOrderNo" to workOrderNo,
            "requestId" to requestId,
            "assetId" to assetId,
            "title" to title,
            "description" to description,
            "status" to status.name,
            "priority" to priority,
            "assignedSupervisorId" to assignedSupervisorId,
            "assignedTechnicianId" to assignedTechnicianId,
            "assignedTechIds" to assignedTechIds,
            "plannedStartAt" to plannedStartAt,
            "dueAt" to dueAt,
            "startedAt" to startedAt,
            "startedBy" to startedBy,
            "completedAt" to completedAt,
            "completedBy" to completedBy,
            "closedAt" to closedAt,
            "closedBy" to closedBy,
            "materialAvailable" to materialAvailable,
            "requiresMaterialCheck" to requiresMaterialCheck,
            "actualLaborMinutes" to actualLaborMinutes,
            "technicianCompletionNotes" to technicianCompletionNotes,
            "executionSummary" to executionSummary,
            "lastStatusReason" to lastStatusReason,
            "createdAt" to createdAt,
            "createdBy" to createdBy,
            "updatedAt" to updatedAt,
            "updatedBy" to updatedBy,
            "deletedAt" to deletedAt,
            "deletedBy" to deletedBy,
            "isDeleted" to isDeleted,
            "version" to version,
            "syncVersion" to syncVersion + 1
        )
    }

    private inline fun <reified T : Enum<T>> enumOrDefault(value: String?, default: T): T =
        value?.let { runCatching { enumValueOf<T>(it) }.getOrNull() } ?: default

    private companion object {
        const val DEFAULT_ROLE_LIMIT = 200L
    }
}
