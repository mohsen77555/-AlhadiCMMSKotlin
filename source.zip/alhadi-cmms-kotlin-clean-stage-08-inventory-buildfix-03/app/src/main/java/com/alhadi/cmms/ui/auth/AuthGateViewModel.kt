package com.alhadi.cmms.ui.auth

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.alhadi.cmms.core.auth.InactiveUserException
import com.alhadi.cmms.core.auth.InvalidUserRoleException
import com.alhadi.cmms.core.auth.MissingSignedInUserException
import com.alhadi.cmms.core.auth.MissingUserProfileException
import com.alhadi.cmms.data.repository.AuthRepositoryImpl
import com.alhadi.cmms.data.repository.UserRepositoryImpl
import com.alhadi.cmms.database.DatabaseProvider
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.domain.repository.AuthRepository
import com.alhadi.cmms.domain.usecase.LoadCurrentUserProfileUseCase
import com.alhadi.cmms.domain.usecase.SignInAndLoadProfileUseCase
import com.alhadi.cmms.domain.usecase.SignOutUseCase
import com.alhadi.cmms.firebase.FirebaseAuthGateway
import com.alhadi.cmms.firebase.UserProfileRemoteDataSource
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AuthGateViewModel(
    application: Application,
    private val authRepository: AuthRepository = buildAuthRepository(application)
) : AndroidViewModel(application) {
    private val signInAndLoadProfile = SignInAndLoadProfileUseCase(authRepository)
    private val loadCurrentUserProfile = LoadCurrentUserProfileUseCase(authRepository)
    private val signOut = SignOutUseCase(authRepository)

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun onSplashFinished() {
        if (!authRepository.hasSignedInUser()) {
            _uiState.update {
                it.copy(
                    screen = AuthScreen.LOGIN,
                    isBusy = false,
                    errorMessageAr = null,
                    profile = null
                )
            }
            return
        }
        loadExistingProfile()
    }

    fun signIn(email: String, password: String) {
        val cleanEmail = email.trim()
        if (cleanEmail.isBlank() || password.isBlank()) {
            _uiState.update {
                it.copy(
                    screen = AuthScreen.LOGIN,
                    isBusy = false,
                    errorMessageAr = "أدخل البريد الإلكتروني وكلمة المرور أولًا."
                )
            }
            return
        }

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    screen = AuthScreen.LOADING_PERMISSIONS,
                    isBusy = true,
                    loadingMessageAr = "جارٍ تسجيل الدخول وتحميل الصلاحيات...",
                    errorMessageAr = null,
                    profile = null
                )
            }

            runCatching {
                signInAndLoadProfile(cleanEmail, password)
            }.onSuccess { profile ->
                openRoleOnlyAfterProfile(profile)
            }.onFailure { error ->
                handleAuthFailure(error)
            }
        }
    }

    fun retryCurrentProfileLoad() {
        loadExistingProfile()
    }

    fun signOutAndReturnToLogin() {
        signOut()
        _uiState.update {
            AuthUiState(
                screen = AuthScreen.LOGIN,
                isBusy = false,
                errorMessageAr = null,
                profile = null
            )
        }
    }

    private fun loadExistingProfile() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    screen = AuthScreen.LOADING_PERMISSIONS,
                    isBusy = true,
                    loadingMessageAr = "جارٍ تحميل الصلاحيات...",
                    errorMessageAr = null,
                    profile = null
                )
            }

            runCatching {
                loadCurrentUserProfile()
            }.onSuccess { profile ->
                openRoleOnlyAfterProfile(profile)
            }.onFailure { error ->
                handleAuthFailure(error)
            }
        }
    }

    private fun openRoleOnlyAfterProfile(profile: UserEntity) {
        _uiState.update {
            it.copy(
                screen = AuthScreen.ROLE_HOME,
                isBusy = false,
                loadingMessageAr = "تم تحميل الصلاحيات.",
                errorMessageAr = null,
                profile = profile
            )
        }
    }

    private fun handleAuthFailure(error: Throwable) {
        val targetScreen = when (error) {
            is MissingUserProfileException,
            is InactiveUserException,
            is InvalidUserRoleException -> AuthScreen.PERMISSION_ERROR
            is MissingSignedInUserException -> AuthScreen.LOGIN
            is FirebaseAuthInvalidUserException,
            is FirebaseAuthInvalidCredentialsException,
            is FirebaseNetworkException -> AuthScreen.LOGIN
            else -> AuthScreen.LOGIN
        }

        _uiState.update {
            it.copy(
                screen = targetScreen,
                isBusy = false,
                errorMessageAr = error.toArabicAuthMessage(),
                profile = null
            )
        }
    }

    private fun Throwable.toArabicAuthMessage(): String {
        return when (this) {
            is MissingUserProfileException -> "لا يوجد ملف صلاحيات لهذا المستخدم. تواصل مع مدير النظام."
            is InactiveUserException -> "حسابك غير مفعل أو محذوف. تواصل مع مدير النظام."
            is InvalidUserRoleException -> "دور المستخدم غير صحيح في Firebase. يجب استخدام القيم الإنجليزية المعتمدة فقط."
            is MissingSignedInUserException -> "لم يتم العثور على جلسة تسجيل دخول نشطة. سجل الدخول مرة أخرى."
            is FirebaseAuthInvalidCredentialsException -> "بيانات الدخول غير صحيحة. تحقق من البريد وكلمة المرور."
            is FirebaseAuthInvalidUserException -> "المستخدم غير موجود أو تم تعطيله في Firebase Auth."
            is FirebaseNetworkException -> "تعذر الاتصال بـ Firebase. تحقق من الإنترنت ثم حاول مرة أخرى."
            else -> message ?: "حدث خطأ غير متوقع أثناء تسجيل الدخول."
        }
    }

    companion object {
        private fun buildAuthRepository(application: Application): AuthRepository {
            val database = DatabaseProvider.getDatabase(application)
            val userRepository = UserRepositoryImpl(database.userDao())
            return AuthRepositoryImpl(
                authGateway = FirebaseAuthGateway(),
                userProfileRemoteDataSource = UserProfileRemoteDataSource(),
                userRepository = userRepository
            )
        }
    }
}

class AuthGateViewModelFactory(
    private val application: Application
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AuthGateViewModel::class.java)) {
            return AuthGateViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
