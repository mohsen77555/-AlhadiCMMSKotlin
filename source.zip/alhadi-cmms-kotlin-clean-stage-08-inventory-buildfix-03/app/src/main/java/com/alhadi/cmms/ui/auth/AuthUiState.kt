package com.alhadi.cmms.ui.auth

import com.alhadi.cmms.database.entity.UserEntity

data class AuthUiState(
    val screen: AuthScreen = AuthScreen.SPLASH,
    val isBusy: Boolean = false,
    val loadingMessageAr: String = "جارٍ تحميل الصلاحيات...",
    val errorMessageAr: String? = null,
    val profile: UserEntity? = null
)
