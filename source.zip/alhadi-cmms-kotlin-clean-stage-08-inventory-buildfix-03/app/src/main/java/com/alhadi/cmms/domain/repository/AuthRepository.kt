package com.alhadi.cmms.domain.repository

import com.alhadi.cmms.database.entity.UserEntity

interface AuthRepository {
    fun hasSignedInUser(): Boolean
    suspend fun signInAndLoadProfile(email: String, password: String): UserEntity
    suspend fun loadCurrentUserProfile(): UserEntity
    fun signOut()
}
