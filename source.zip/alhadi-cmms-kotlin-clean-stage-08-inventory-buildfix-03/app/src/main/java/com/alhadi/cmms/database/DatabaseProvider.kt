package com.alhadi.cmms.database

import android.content.Context
import androidx.room.Room

object DatabaseProvider {
    private const val DATABASE_NAME = "alhadi_cmms.db"

    @Volatile
    private var instance: AlhadiCmmsDatabase? = null

    fun getDatabase(context: Context): AlhadiCmmsDatabase {
        return instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AlhadiCmmsDatabase::class.java,
                DATABASE_NAME
            )
                .addMigrations(*DatabaseMigrations.all())
                .build()
                .also { instance = it }
        }
    }
}
