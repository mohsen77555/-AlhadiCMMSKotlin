package com.alhadi.cmms.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.alhadi.cmms.database.DatabaseProvider
import com.alhadi.cmms.firebase.SyncRemoteDataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SyncQueueWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        runCatching {
            val database = DatabaseProvider.getDatabase(applicationContext)
            val processor = SyncQueueProcessor(
                database = database,
                remoteDataSource = SyncRemoteDataSource()
            )
            processor.processDueItems()
        }.fold(
            onSuccess = { result ->
                if (result.hasRetriableFailures) Result.retry() else Result.success()
            },
            onFailure = {
                Result.retry()
            }
        )
    }
}
