package com.alhadi.cmms.data.repository

import com.alhadi.cmms.database.dao.AssetDao
import com.alhadi.cmms.database.entity.AssetEntity
import com.alhadi.cmms.domain.repository.AssetRepository
import kotlinx.coroutines.flow.Flow

class AssetRepositoryImpl(
    private val assetDao: AssetDao
) : AssetRepository {
    override fun observeAssets(companyId: String): Flow<List<AssetEntity>> = assetDao.observeCompanyAssets(companyId)

    override fun observeAsset(assetId: String): Flow<AssetEntity?> = assetDao.observeById(assetId)

    override suspend fun getAsset(assetId: String): AssetEntity? = assetDao.getById(assetId)

    override suspend fun saveLocal(asset: AssetEntity) = assetDao.upsert(asset)
}
