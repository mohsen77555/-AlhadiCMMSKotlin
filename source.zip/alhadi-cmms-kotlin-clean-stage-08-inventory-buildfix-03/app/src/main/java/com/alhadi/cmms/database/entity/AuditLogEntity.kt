package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.alhadi.cmms.core.model.AuditAction
import com.alhadi.cmms.core.model.UserRole

@Entity(
    tableName = "audit_logs",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["entityType", "entityId"]),
        Index(value = ["action"]),
        Index(value = ["performedBy"]),
        Index(value = ["performedAt"])
    ]
)
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val entityType: String,
    val entityId: String,
    val action: AuditAction,
    val oldValueJson: String? = null,
    val newValueJson: String? = null,
    val performedBy: String,
    val performedByRole: UserRole,
    val performedAt: Long,
    val deviceId: String,
    val source: String = "ANDROID"
)
