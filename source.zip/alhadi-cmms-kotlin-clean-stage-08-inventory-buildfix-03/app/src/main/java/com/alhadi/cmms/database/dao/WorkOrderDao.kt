package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.core.model.WorkOrderStatus
import com.alhadi.cmms.database.entity.WorkOrderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkOrderDao {
    @Upsert
    suspend fun upsert(workOrder: WorkOrderEntity)

    @Upsert
    suspend fun upsertAll(workOrders: List<WorkOrderEntity>)

    @Query("SELECT * FROM work_orders WHERE id = :id AND isDeleted = 0 LIMIT 1")
    suspend fun getById(id: String): WorkOrderEntity?

    @Query("SELECT * FROM work_orders WHERE id = :id AND isDeleted = 0 LIMIT 1")
    fun observeById(id: String): Flow<WorkOrderEntity?>

    @Query("SELECT * FROM work_orders WHERE companyId = :companyId AND isDeleted = 0 ORDER BY updatedAt DESC")
    fun observeForCompany(companyId: String): Flow<List<WorkOrderEntity>>

    @Query("SELECT * FROM work_orders WHERE companyId = :companyId AND assignedTechnicianId = :technicianId AND isDeleted = 0 ORDER BY dueAt ASC, updatedAt DESC")
    fun observeForTechnician(companyId: String, technicianId: String): Flow<List<WorkOrderEntity>>

    @Query("SELECT * FROM work_orders WHERE companyId = :companyId AND assignedTechnicianId = :technicianId AND status = :status AND isDeleted = 0 ORDER BY dueAt ASC, updatedAt DESC")
    fun observeForTechnicianByStatus(companyId: String, technicianId: String, status: WorkOrderStatus): Flow<List<WorkOrderEntity>>

    @Query("SELECT * FROM work_orders WHERE companyId = :companyId AND assignedSupervisorId = :supervisorId AND isDeleted = 0 ORDER BY updatedAt DESC")
    fun observeForSupervisor(companyId: String, supervisorId: String): Flow<List<WorkOrderEntity>>

    @Query("SELECT * FROM work_orders WHERE companyId = :companyId AND status = :status AND isDeleted = 0 ORDER BY dueAt ASC, updatedAt DESC")
    fun observeForCompanyByStatus(companyId: String, status: WorkOrderStatus): Flow<List<WorkOrderEntity>>

    @Query("UPDATE work_orders SET status = :status, updatedAt = :updatedAt, updatedBy = :updatedBy, version = version + 1 WHERE id = :id AND isDeleted = 0")
    suspend fun updateStatus(id: String, status: WorkOrderStatus, updatedAt: Long, updatedBy: String)

    @Query("UPDATE work_orders SET isDeleted = 1, deletedAt = :deletedAt, deletedBy = :deletedBy, updatedAt = :deletedAt, updatedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)

    @Query("UPDATE work_orders SET syncStatus = :syncStatus, lastSyncError = :lastSyncError, lastRemoteUpdatedAt = :lastRemoteUpdatedAt, syncVersion = :syncVersion WHERE id = :id")
    suspend fun updateSyncState(id: String, syncStatus: SyncStatus, lastSyncError: String?, lastRemoteUpdatedAt: Long?, syncVersion: Long)
}
