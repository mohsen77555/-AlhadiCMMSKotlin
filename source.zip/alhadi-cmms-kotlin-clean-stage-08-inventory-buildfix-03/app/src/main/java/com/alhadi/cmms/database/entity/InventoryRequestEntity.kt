package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.alhadi.cmms.core.model.InventoryRequestStatus
import com.alhadi.cmms.core.model.InventoryRequestType
import com.alhadi.cmms.core.model.SyncStatus

@Entity(
    tableName = "inventory_requests",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["companyId", "requestNo"], unique = true),
        Index(value = ["workOrderId"]),
        Index(value = ["requestedBy"]),
        Index(value = ["status"]),
        Index(value = ["type"]),
        Index(value = ["syncStatus"]),
        Index(value = ["createdAt"])
    ]
)
data class InventoryRequestEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val requestNo: String,
    val type: InventoryRequestType = InventoryRequestType.ISSUE_TO_WORK_ORDER,
    val status: InventoryRequestStatus = InventoryRequestStatus.REQUESTED,
    val workOrderId: String? = null,
    val requestedBy: String,
    val requestedByRole: String,
    val requestedAt: Long,
    val approvedBy: String? = null,
    val approvedAt: Long? = null,
    val issuedBy: String? = null,
    val issuedAt: Long? = null,
    val rejectedBy: String? = null,
    val rejectedAt: Long? = null,
    val reason: String? = null,
    val notes: String? = null,
    val lineCount: Int = 0,
    val createdAt: Long,
    val createdBy: String,
    val updatedAt: Long,
    val updatedBy: String,
    val deletedAt: Long? = null,
    val deletedBy: String? = null,
    val isDeleted: Boolean = false,
    val version: Long = 1,
    val syncVersion: Long = 0,
    val syncStatus: SyncStatus = SyncStatus.LOCAL_ONLY,
    val lastSyncError: String? = null
)
