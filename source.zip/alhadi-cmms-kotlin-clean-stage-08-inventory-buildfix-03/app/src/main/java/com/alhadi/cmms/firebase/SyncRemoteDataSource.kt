package com.alhadi.cmms.firebase

import com.alhadi.cmms.core.model.WorkOrderStatus
import com.alhadi.cmms.core.model.StockTransactionType
import com.alhadi.cmms.database.entity.AuditLogEntity
import com.alhadi.cmms.database.entity.InventoryRequestEntity
import com.alhadi.cmms.database.entity.InventoryRequestLineEntity
import com.alhadi.cmms.database.entity.ItemEntity
import com.alhadi.cmms.database.entity.StockBalanceEntity
import com.alhadi.cmms.database.entity.StockTransactionEntity
import com.alhadi.cmms.database.entity.WarehouseEntity
import com.alhadi.cmms.database.entity.WorkOrderEntity
import com.alhadi.cmms.database.entity.WorkOrderExecutionLogEntity
import com.alhadi.cmms.database.entity.WorkOrderMaterialEntity
import com.alhadi.cmms.database.entity.WorkOrderStatusHistoryEntity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

class SyncRemoteDataSource(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    suspend fun fetchWorkOrderState(companyId: String, workOrderId: String): WorkOrderRemoteState {
        val snapshot = companyRoot(companyId)
            .collection("workOrders")
            .document(workOrderId)
            .get()
            .await()

        if (!snapshot.exists()) {
            return WorkOrderRemoteState(
                exists = false,
                version = 0L,
                status = null,
                updatedAt = null
            )
        }

        return WorkOrderRemoteState(
            exists = true,
            version = snapshot.getLong("version") ?: 0L,
            status = enumOrNull<WorkOrderStatus>(snapshot.getString("status")),
            updatedAt = snapshot.getLong("updatedAt")
        )
    }

    suspend fun upsertWorkOrder(workOrder: WorkOrderEntity) {
        upsert(companyId = workOrder.companyId, collection = "workOrders", documentId = workOrder.id, data = workOrder.toFirestoreMap())
    }

    suspend fun upsertStatusHistory(history: WorkOrderStatusHistoryEntity) {
        upsert(companyId = history.companyId, collection = "workOrderStatusHistory", documentId = history.id, data = history.toFirestoreMap())
    }

    suspend fun upsertExecutionLog(log: WorkOrderExecutionLogEntity) {
        upsert(companyId = log.companyId, collection = "workOrderExecutionLogs", documentId = log.id, data = log.toFirestoreMap())
    }

    suspend fun upsertAuditLog(log: AuditLogEntity) {
        upsert(companyId = log.companyId, collection = "auditLogs", documentId = log.id, data = log.toFirestoreMap())
    }

    suspend fun upsertItem(item: ItemEntity) {
        upsert(companyId = item.companyId, collection = "items", documentId = item.id, data = item.toFirestoreMap())
    }

    suspend fun upsertWarehouse(warehouse: WarehouseEntity) {
        upsert(companyId = warehouse.companyId, collection = "warehouses", documentId = warehouse.id, data = warehouse.toFirestoreMap())
    }

    suspend fun upsertStockBalance(balance: StockBalanceEntity) {
        upsert(companyId = balance.companyId, collection = "stockBalances", documentId = balance.id, data = balance.toFirestoreMap())
    }

    suspend fun upsertStockTransaction(transaction: StockTransactionEntity) {
        val company = companyRoot(transaction.companyId)
        val transactionRef = company.collection("stockTransactions").document(transaction.id)
        val balanceId = "${transaction.companyId}-${transaction.itemId}-${transaction.warehouseId}"
        val balanceRef = company.collection("stockBalances").document(balanceId)
        firestore.runTransaction { tx ->
            val transactionSnapshot = tx.get(transactionRef)
            if (!transactionSnapshot.exists()) {
                val currentSnapshot = tx.get(balanceRef)
                val currentQuantity = currentSnapshot.getDouble("quantityOnHand") ?: 0.0
                val currentAvailable = currentSnapshot.getDouble("availableQuantity") ?: currentQuantity
                val newQuantity = currentQuantity + transaction.onHandRemoteDelta()
                val newAvailable = currentAvailable + transaction.availableRemoteDelta()
                if (newQuantity < -0.000001 || newAvailable < -0.000001) {
                    throw FirebaseFirestoreException(
                        "لا يمكن رفع حركة المخزون لأن الرصيد في السيرفر غير كاف.",
                        FirebaseFirestoreException.Code.ABORTED
                    )
                }
                tx.set(
                    balanceRef,
                    mapOf(
                        "id" to balanceId,
                        "companyId" to transaction.companyId,
                        "itemId" to transaction.itemId,
                        "warehouseId" to transaction.warehouseId,
                        "quantityOnHand" to newQuantity,
                        "availableQuantity" to newAvailable,
                        "lastCalculatedAt" to System.currentTimeMillis(),
                        "updatedAt" to System.currentTimeMillis(),
                        "updatedBy" to transaction.updatedBy,
                        "syncVersion" to transaction.syncVersion + 1
                    ),
                    SetOptions.merge()
                )
            }
            tx.set(transactionRef, transaction.toFirestoreMap(), SetOptions.merge())
            null
        }.await()
    }

    suspend fun upsertInventoryRequest(request: InventoryRequestEntity) {
        upsert(companyId = request.companyId, collection = "inventoryRequests", documentId = request.id, data = request.toFirestoreMap())
    }

    suspend fun upsertInventoryRequestLine(line: InventoryRequestLineEntity) {
        upsert(companyId = line.companyId, collection = "inventoryRequestLines", documentId = line.id, data = line.toFirestoreMap())
    }

    suspend fun upsertWorkOrderMaterial(material: WorkOrderMaterialEntity) {
        upsert(companyId = material.companyId, collection = "workOrderMaterials", documentId = material.id, data = material.toFirestoreMap())
    }

    private suspend fun upsert(companyId: String, collection: String, documentId: String, data: Map<String, Any?>) {
        companyRoot(companyId)
            .collection(collection)
            .document(documentId)
            .set(data, SetOptions.merge())
            .await()
    }

    private fun companyRoot(companyId: String) = firestore
        .collection("companies")
        .document(companyId)

    private fun WorkOrderEntity.toFirestoreMap(): Map<String, Any?> {
        val assignedTechIds = assignedTechnicianId
            ?.takeIf { it.isNotBlank() }
            ?.let { listOf(it) }
            .orEmpty()

        return mapOf(
            "id" to id,
            "companyId" to companyId,
            "workOrderNo" to workOrderNo,
            "requestId" to requestId,
            "assetId" to assetId,
            "title" to title,
            "description" to description,
            "status" to status.name,
            "priority" to priority,
            "assignedSupervisorId" to assignedSupervisorId,
            "assignedTechnicianId" to assignedTechnicianId,
            "assignedTechIds" to assignedTechIds,
            "plannedStartAt" to plannedStartAt,
            "dueAt" to dueAt,
            "startedAt" to startedAt,
            "startedBy" to startedBy,
            "completedAt" to completedAt,
            "completedBy" to completedBy,
            "closedAt" to closedAt,
            "closedBy" to closedBy,
            "materialAvailable" to materialAvailable,
            "requiresMaterialCheck" to requiresMaterialCheck,
            "actualLaborMinutes" to actualLaborMinutes,
            "technicianCompletionNotes" to technicianCompletionNotes,
            "executionSummary" to executionSummary,
            "lastStatusReason" to lastStatusReason,
            "createdAt" to createdAt,
            "createdBy" to createdBy,
            "updatedAt" to updatedAt,
            "updatedBy" to updatedBy,
            "deletedAt" to deletedAt,
            "deletedBy" to deletedBy,
            "isDeleted" to isDeleted,
            "version" to version,
            "syncVersion" to syncVersion + 1
        )
    }

    private fun WorkOrderStatusHistoryEntity.toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "companyId" to companyId,
        "workOrderId" to workOrderId,
        "fromStatus" to fromStatus?.name,
        "toStatus" to toStatus.name,
        "reason" to reason,
        "changedBy" to changedBy,
        "changedByRole" to changedByRole.name,
        "changedAt" to changedAt,
        "createdAt" to createdAt,
        "createdBy" to createdBy,
        "isDeleted" to isDeleted,
        "version" to version,
        "syncVersion" to syncVersion + 1
    )

    private fun WorkOrderExecutionLogEntity.toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "companyId" to companyId,
        "workOrderId" to workOrderId,
        "technicianId" to technicianId,
        "logType" to logType,
        "startedAt" to startedAt,
        "finishedAt" to finishedAt,
        "laborMinutes" to laborMinutes,
        "summary" to summary,
        "notes" to notes,
        "createdAt" to createdAt,
        "createdBy" to createdBy,
        "updatedAt" to updatedAt,
        "updatedBy" to updatedBy,
        "isDeleted" to isDeleted,
        "version" to version,
        "syncVersion" to syncVersion + 1
    )

    private fun AuditLogEntity.toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "companyId" to companyId,
        "entityType" to entityType,
        "entityId" to entityId,
        "action" to action.name,
        "oldValueJson" to oldValueJson,
        "newValueJson" to newValueJson,
        "performedBy" to performedBy,
        "performedByRole" to performedByRole.name,
        "performedAt" to performedAt,
        "deviceId" to deviceId,
        "source" to source
    )

    private fun ItemEntity.toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "companyId" to companyId,
        "itemCode" to itemCode,
        "itemName" to itemName,
        "unit" to unit,
        "category" to category,
        "isCriticalSpare" to isCriticalSpare,
        "minStock" to minStock,
        "maxStock" to maxStock,
        "reorderPoint" to reorderPoint,
        "createdAt" to createdAt,
        "createdBy" to createdBy,
        "updatedAt" to updatedAt,
        "updatedBy" to updatedBy,
        "isDeleted" to isDeleted,
        "version" to version,
        "syncVersion" to syncVersion + 1
    )

    private fun WarehouseEntity.toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "companyId" to companyId,
        "warehouseCode" to warehouseCode,
        "warehouseName" to warehouseName,
        "locationId" to locationId,
        "isMain" to isMain,
        "createdAt" to createdAt,
        "createdBy" to createdBy,
        "updatedAt" to updatedAt,
        "updatedBy" to updatedBy,
        "isDeleted" to isDeleted,
        "version" to version,
        "syncVersion" to syncVersion + 1
    )

    private fun StockBalanceEntity.toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "companyId" to companyId,
        "itemId" to itemId,
        "warehouseId" to warehouseId,
        "quantityOnHand" to quantityOnHand,
        "reservedQuantity" to reservedQuantity,
        "availableQuantity" to availableQuantity,
        "minStockSnapshot" to minStockSnapshot,
        "isBelowMinimum" to isBelowMinimum,
        "lastCalculatedAt" to lastCalculatedAt,
        "updatedAt" to updatedAt,
        "updatedBy" to updatedBy,
        "version" to version,
        "syncVersion" to syncVersion + 1
    )

    private fun StockTransactionEntity.toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "companyId" to companyId,
        "transactionNo" to transactionNo,
        "itemId" to itemId,
        "warehouseId" to warehouseId,
        "workOrderId" to workOrderId,
        "type" to type.name,
        "quantity" to quantity,
        "unitCost" to unitCost,
        "totalCost" to totalCost,
        "reason" to reason,
        "approvedBy" to approvedBy,
        "approvedAt" to approvedAt,
        "transactionAt" to transactionAt,
        "createdAt" to createdAt,
        "createdBy" to createdBy,
        "updatedAt" to updatedAt,
        "updatedBy" to updatedBy,
        "isDeleted" to isDeleted,
        "version" to version,
        "syncVersion" to syncVersion + 1
    )

    private fun StockTransactionEntity.onHandRemoteDelta(): Double = when (type) {
        StockTransactionType.OPENING,
        StockTransactionType.RECEIPT,
        StockTransactionType.RETURN_FROM_WORK_ORDER,
        StockTransactionType.TRANSFER_IN,
        StockTransactionType.ADJUSTMENT_PLUS -> quantity

        StockTransactionType.ISSUE_TO_WORK_ORDER,
        StockTransactionType.TRANSFER_OUT,
        StockTransactionType.ADJUSTMENT_MINUS -> -quantity

        StockTransactionType.RESERVATION,
        StockTransactionType.RESERVATION_CANCEL -> 0.0
    }

    private fun StockTransactionEntity.availableRemoteDelta(): Double = when (type) {
        StockTransactionType.OPENING,
        StockTransactionType.RECEIPT,
        StockTransactionType.RETURN_FROM_WORK_ORDER,
        StockTransactionType.TRANSFER_IN,
        StockTransactionType.ADJUSTMENT_PLUS,
        StockTransactionType.RESERVATION_CANCEL -> quantity

        StockTransactionType.ISSUE_TO_WORK_ORDER,
        StockTransactionType.TRANSFER_OUT,
        StockTransactionType.ADJUSTMENT_MINUS,
        StockTransactionType.RESERVATION -> -quantity
    }

    private fun InventoryRequestEntity.toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "companyId" to companyId,
        "requestNo" to requestNo,
        "type" to type.name,
        "status" to status.name,
        "workOrderId" to workOrderId,
        "requestedBy" to requestedBy,
        "requestedByRole" to requestedByRole,
        "requestedAt" to requestedAt,
        "approvedBy" to approvedBy,
        "approvedAt" to approvedAt,
        "issuedBy" to issuedBy,
        "issuedAt" to issuedAt,
        "reason" to reason,
        "notes" to notes,
        "lineCount" to lineCount,
        "createdAt" to createdAt,
        "createdBy" to createdBy,
        "updatedAt" to updatedAt,
        "updatedBy" to updatedBy,
        "isDeleted" to isDeleted,
        "version" to version,
        "syncVersion" to syncVersion + 1
    )

    private fun InventoryRequestLineEntity.toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "companyId" to companyId,
        "requestId" to requestId,
        "workOrderId" to workOrderId,
        "itemId" to itemId,
        "warehouseId" to warehouseId,
        "requestedQuantity" to requestedQuantity,
        "approvedQuantity" to approvedQuantity,
        "issuedQuantity" to issuedQuantity,
        "returnedQuantity" to returnedQuantity,
        "unitCostSnapshot" to unitCostSnapshot,
        "notes" to notes,
        "createdAt" to createdAt,
        "createdBy" to createdBy,
        "updatedAt" to updatedAt,
        "updatedBy" to updatedBy,
        "isDeleted" to isDeleted,
        "version" to version,
        "syncVersion" to syncVersion + 1
    )

    private fun WorkOrderMaterialEntity.toFirestoreMap(): Map<String, Any?> = mapOf(
        "id" to id,
        "companyId" to companyId,
        "workOrderId" to workOrderId,
        "itemId" to itemId,
        "warehouseId" to warehouseId,
        "plannedQuantity" to plannedQuantity,
        "requestedQuantity" to requestedQuantity,
        "reservedQuantity" to reservedQuantity,
        "issuedQuantity" to issuedQuantity,
        "returnedQuantity" to returnedQuantity,
        "unitCostSnapshot" to unitCostSnapshot,
        "inventoryRequestId" to inventoryRequestId,
        "notes" to notes,
        "createdAt" to createdAt,
        "createdBy" to createdBy,
        "updatedAt" to updatedAt,
        "updatedBy" to updatedBy,
        "isDeleted" to isDeleted,
        "version" to version,
        "syncVersion" to syncVersion + 1
    )

    private inline fun <reified T : Enum<T>> enumOrNull(value: String?): T? =
        value?.let { runCatching { enumValueOf<T>(it) }.getOrNull() }
}
