package com.alhadi.cmms.ui.inventory

import com.alhadi.cmms.database.entity.InventoryRequestEntity
import com.alhadi.cmms.database.entity.InventoryRequestLineEntity
import com.alhadi.cmms.database.entity.ItemEntity
import com.alhadi.cmms.database.entity.StockBalanceEntity
import com.alhadi.cmms.database.entity.StockTransactionEntity
import com.alhadi.cmms.database.entity.WarehouseEntity
import com.alhadi.cmms.database.entity.WorkOrderMaterialEntity
import com.alhadi.cmms.ui.workorders.SyncQueueUiSummary

data class InventoryUiState(
    val items: List<ItemEntity> = emptyList(),
    val warehouses: List<WarehouseEntity> = emptyList(),
    val balances: List<StockBalanceEntity> = emptyList(),
    val transactions: List<StockTransactionEntity> = emptyList(),
    val requests: List<InventoryRequestEntity> = emptyList(),
    val requestLines: List<InventoryRequestLineEntity> = emptyList(),
    val workOrderMaterials: List<WorkOrderMaterialEntity> = emptyList(),
    val syncQueueSummary: SyncQueueUiSummary = SyncQueueUiSummary(),
    val isBusy: Boolean = false,
    val messageAr: String? = null,
    val errorAr: String? = null
) {
    val lowStockCount: Int get() = balances.count { it.isBelowMinimum }
    val totalOnHand: Double get() = balances.sumOf { it.quantityOnHand }
    val pendingRequests: Int get() = requests.count { it.status.name == "REQUESTED" }
}
