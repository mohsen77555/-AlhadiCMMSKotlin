package com.alhadi.cmms.ui.inventory

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.alhadi.cmms.data.repository.InventoryRepositoryImpl
import com.alhadi.cmms.database.DatabaseProvider
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.domain.repository.InventoryRepository
import com.alhadi.cmms.sync.SyncQueueScheduler
import com.alhadi.cmms.ui.workorders.SyncQueueUiSummary
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class InventoryViewModel(
    application: Application,
    private val profile: UserEntity,
    private val repository: InventoryRepository = InventoryRepositoryImpl(
        database = DatabaseProvider.getDatabase(application)
    )
) : AndroidViewModel(application) {
    private val database = DatabaseProvider.getDatabase(application)
    private val operationState = MutableStateFlow(OperationState())

    private val inventoryBaseData = combine(
        repository.observeItems(profile.companyId),
        repository.observeWarehouses(profile.companyId),
        repository.observeStockBalances(profile.companyId),
        repository.observeStockTransactions(profile.companyId),
        repository.observeInventoryRequests(profile.companyId)
    ) { items, warehouses, balances, transactions, requests ->
        InventoryBaseData(
            items = items,
            warehouses = warehouses,
            balances = balances,
            transactions = transactions,
            requests = requests
        )
    }

    private val inventoryExtraData = combine(
        repository.observeInventoryRequestLines(profile.companyId),
        repository.observeWorkOrderMaterials(profile.companyId),
        database.syncQueueDao().observeForCompany(profile.companyId),
        operationState
    ) { lines, workOrderMaterials, queueItems, operation ->
        InventoryExtraData(
            lines = lines,
            workOrderMaterials = workOrderMaterials,
            queueSummary = SyncQueueUiSummary.from(queueItems),
            operation = operation
        )
    }

    val uiState = combine(inventoryBaseData, inventoryExtraData) { base, extra ->
        InventoryUiState(
            items = base.items,
            warehouses = base.warehouses,
            balances = base.balances,
            transactions = base.transactions,
            requests = base.requests,
            requestLines = extra.lines,
            workOrderMaterials = extra.workOrderMaterials,
            syncQueueSummary = extra.queueSummary,
            isBusy = extra.operation.isBusy,
            messageAr = extra.operation.messageAr,
            errorAr = extra.operation.errorAr
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = InventoryUiState()
    )

    fun createItem(code: String, name: String, unit: String, category: String?, minStock: Double, critical: Boolean) {
        runOperation("تم إنشاء الصنف محليًا وإرساله لطابور المزامنة.") {
            repository.createItem(profile, code, name, unit, category, minStock, critical)
        }
    }

    fun createWarehouse(code: String, name: String, isMain: Boolean) {
        runOperation("تم إنشاء المخزن محليًا وإرساله لطابور المزامنة.") {
            repository.createWarehouse(profile, code, name, isMain)
        }
    }

    fun addOpening(itemId: String, warehouseId: String, quantity: Double, unitCost: Double) {
        runOperation("تم تسجيل الرصيد الافتتاحي كحركة مخزون، وليس كتعديل مباشر للرصيد.") {
            repository.addOpeningBalance(profile, itemId, warehouseId, quantity, unitCost, "رصيد افتتاحي")
        }
    }

    fun receive(itemId: String, warehouseId: String, quantity: Double, unitCost: Double) {
        runOperation("تم تسجيل الاستلام كحركة مخزون.") {
            repository.receiveStock(profile, itemId, warehouseId, quantity, unitCost, "استلام مخزني")
        }
    }

    fun requestMaterial(workOrderId: String, itemId: String, warehouseId: String, quantity: Double, notes: String?) {
        runOperation("تم إنشاء طلب مادة محليًا. المخزن يعتمد ويصرف لاحقًا.") {
            repository.requestMaterialForWorkOrder(profile, workOrderId, itemId, warehouseId, quantity, notes)
        }
    }

    fun approveAndIssue(requestId: String) {
        runOperation("تم اعتماد طلب الصرف وإنشاء حركة صرف ضمن Transaction.") {
            repository.approveAndIssueRequest(profile, requestId)
        }
    }

    fun directIssue(workOrderId: String, itemId: String, warehouseId: String, quantity: Double, unitCost: Double) {
        runOperation("تم صرف المادة لأمر العمل عبر حركة مخزون.") {
            repository.issueToWorkOrder(profile, workOrderId, itemId, warehouseId, quantity, unitCost, "صرف مباشر لأمر عمل")
        }
    }

    fun returnFromWorkOrder(workOrderId: String, itemId: String, warehouseId: String, quantity: Double, unitCost: Double) {
        runOperation("تم إرجاع المادة من أمر العمل عبر حركة مخزون.") {
            repository.returnFromWorkOrder(profile, workOrderId, itemId, warehouseId, quantity, unitCost, "إرجاع من أمر عمل")
        }
    }

    fun runSyncNow() {
        SyncQueueScheduler.enqueueOneTimeSync(getApplication<Application>())
        operationState.value = OperationState(messageAr = "تم طلب تشغيل طابور المزامنة عند توفر الإنترنت.")
    }

    fun clearMessage() {
        operationState.value = OperationState()
    }

    private fun runOperation(successMessage: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            operationState.value = OperationState(isBusy = true)
            runCatching { block() }
                .onSuccess {
                    SyncQueueScheduler.enqueueOneTimeSync(getApplication<Application>())
                    operationState.value = OperationState(messageAr = successMessage)
                }
                .onFailure { error ->
                    operationState.value = OperationState(errorAr = error.message ?: "حدث خطأ أثناء عملية المخزون.")
                }
        }
    }


    private data class InventoryBaseData(
        val items: List<com.alhadi.cmms.database.entity.ItemEntity>,
        val warehouses: List<com.alhadi.cmms.database.entity.WarehouseEntity>,
        val balances: List<com.alhadi.cmms.database.entity.StockBalanceEntity>,
        val transactions: List<com.alhadi.cmms.database.entity.StockTransactionEntity>,
        val requests: List<com.alhadi.cmms.database.entity.InventoryRequestEntity>
    )

    private data class InventoryExtraData(
        val lines: List<com.alhadi.cmms.database.entity.InventoryRequestLineEntity>,
        val workOrderMaterials: List<com.alhadi.cmms.database.entity.WorkOrderMaterialEntity>,
        val queueSummary: SyncQueueUiSummary,
        val operation: OperationState
    )

    private data class OperationState(
        val isBusy: Boolean = false,
        val messageAr: String? = null,
        val errorAr: String? = null
    )
}

class InventoryViewModelFactory(
    private val application: Application,
    private val profile: UserEntity
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(InventoryViewModel::class.java)) {
            return InventoryViewModel(application, profile) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
