package com.alhadi.cmms.firebase

import com.alhadi.cmms.core.auth.MissingSignedInUserException
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.tasks.await

data class FirebaseUserSnapshot(
    val uid: String,
    val email: String?,
    val displayName: String?
)

class FirebaseAuthGateway(
    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    fun currentUser(): FirebaseUserSnapshot? {
        val user = firebaseAuth.currentUser ?: return null
        return FirebaseUserSnapshot(
            uid = user.uid,
            email = user.email,
            displayName = user.displayName
        )
    }

    suspend fun signInWithEmailAndPassword(
        email: String,
        password: String
    ): FirebaseUserSnapshot {
        val result = firebaseAuth
            .signInWithEmailAndPassword(email.trim(), password)
            .await()

        val user = result.user ?: throw MissingSignedInUserException()
        return FirebaseUserSnapshot(
            uid = user.uid,
            email = user.email,
            displayName = user.displayName
        )
    }

    fun signOut() {
        firebaseAuth.signOut()
    }
}
