package com.alhadi.cmms.ui.screens.home

import androidx.compose.runtime.Composable
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.ui.navigation.allowedHomeMenus
import com.alhadi.cmms.ui.navigation.stage04PolicyNotesAr

@Composable
fun RequesterHomeScreen(
    profile: UserEntity,
    onSignOut: () -> Unit
) {
    RoleHomeScaffold(
        profile = profile,
        screenTitleAr = "واجهة طالب الخدمة",
        welcomeAr = "مرحبًا، هذه واجهة طالب الخدمة لطلباته فقط.",
        allowedMenus = UserRole.REQUESTER.allowedHomeMenus(),
        policyNotes = UserRole.REQUESTER.stage04PolicyNotesAr(),
        onSignOut = onSignOut
    )
}
