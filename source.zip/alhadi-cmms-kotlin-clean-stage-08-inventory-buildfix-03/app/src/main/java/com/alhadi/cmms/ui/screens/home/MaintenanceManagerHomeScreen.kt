package com.alhadi.cmms.ui.screens.home

import androidx.compose.runtime.Composable
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.ui.navigation.allowedHomeMenus
import com.alhadi.cmms.ui.navigation.stage04PolicyNotesAr

@Composable
fun MaintenanceManagerHomeScreen(
    profile: UserEntity,
    onSignOut: () -> Unit
) {
    RoleHomeScaffold(
        profile = profile,
        screenTitleAr = "واجهة مدير الصيانة",
        welcomeAr = "مرحبًا، هذه واجهة مدير الصيانة بدون إعدادات النظام العامة.",
        allowedMenus = UserRole.MAINTENANCE_MANAGER.allowedHomeMenus(),
        policyNotes = UserRole.MAINTENANCE_MANAGER.stage04PolicyNotesAr(),
        onSignOut = onSignOut
    )
}
