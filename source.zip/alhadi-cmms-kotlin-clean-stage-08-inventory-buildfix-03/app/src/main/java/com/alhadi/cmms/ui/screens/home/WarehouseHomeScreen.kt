package com.alhadi.cmms.ui.screens.home

import androidx.compose.runtime.Composable
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.ui.navigation.allowedHomeMenus
import com.alhadi.cmms.ui.navigation.stage04PolicyNotesAr

@Composable
fun WarehouseHomeScreen(
    profile: UserEntity,
    onSignOut: () -> Unit
) {
    RoleHomeScaffold(
        profile = profile,
        screenTitleAr = "واجهة المخزن",
        welcomeAr = "مرحبًا، هذه واجهة المخزن لطلبات الصرف وحركات المخزون.",
        allowedMenus = UserRole.WAREHOUSE.allowedHomeMenus(),
        policyNotes = UserRole.WAREHOUSE.stage04PolicyNotesAr(),
        onSignOut = onSignOut
    )
}
