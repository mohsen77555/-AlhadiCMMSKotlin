package com.alhadi.cmms.data.repository

import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.database.dao.SyncQueueDao
import com.alhadi.cmms.database.entity.SyncQueueEntity
import com.alhadi.cmms.domain.repository.SyncQueueRepository
import kotlinx.coroutines.flow.Flow

class SyncQueueRepositoryImpl(
    private val syncQueueDao: SyncQueueDao
) : SyncQueueRepository {
    override fun observeQueue(companyId: String): Flow<List<SyncQueueEntity>> = syncQueueDao.observeForCompany(companyId)

    override suspend fun enqueue(item: SyncQueueEntity) = syncQueueDao.enqueue(item)

    override suspend fun enqueueAll(items: List<SyncQueueEntity>) = syncQueueDao.enqueueAll(items)

    override suspend fun nextPending(now: Long, limit: Int): List<SyncQueueEntity> = syncQueueDao.nextPending(now, limit)

    override suspend fun updateStatus(id: String, status: SyncStatus, retryCount: Int, lastError: String?, nextRetryAt: Long?) =
        syncQueueDao.updateStatus(id, status, retryCount, lastError, nextRetryAt)

    override suspend fun markStuckSyncingAsFailed(message: String, nextRetryAt: Long) =
        syncQueueDao.markStuckSyncingAsFailed(message, nextRetryAt)
}
