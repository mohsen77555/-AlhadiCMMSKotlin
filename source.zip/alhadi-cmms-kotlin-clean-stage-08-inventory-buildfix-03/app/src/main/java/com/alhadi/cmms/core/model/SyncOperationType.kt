package com.alhadi.cmms.core.model

enum class SyncOperationType {
    CREATE,
    UPDATE,
    SOFT_DELETE,
    UPLOAD_ATTACHMENT,
    STOCK_TRANSACTION,
    STATUS_CHANGE
}
