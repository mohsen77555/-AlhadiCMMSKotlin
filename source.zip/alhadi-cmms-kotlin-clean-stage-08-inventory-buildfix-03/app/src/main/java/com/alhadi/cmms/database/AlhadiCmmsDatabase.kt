package com.alhadi.cmms.database

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.alhadi.cmms.database.converter.RoomConverters
import com.alhadi.cmms.database.dao.AssetDao
import com.alhadi.cmms.database.dao.AuditLogDao
import com.alhadi.cmms.database.dao.ItemDao
import com.alhadi.cmms.database.dao.StockTransactionDao
import com.alhadi.cmms.database.dao.SyncQueueDao
import com.alhadi.cmms.database.dao.UserDao
import com.alhadi.cmms.database.dao.WorkOrderDao
import com.alhadi.cmms.database.dao.WorkOrderExecutionLogDao
import com.alhadi.cmms.database.dao.WorkOrderStatusHistoryDao
import com.alhadi.cmms.database.dao.WorkRequestDao
import com.alhadi.cmms.database.dao.WorkOrderMaterialDao
import com.alhadi.cmms.database.dao.InventoryRequestLineDao
import com.alhadi.cmms.database.dao.InventoryRequestDao
import com.alhadi.cmms.database.dao.StockBalanceDao
import com.alhadi.cmms.database.dao.WarehouseDao
import com.alhadi.cmms.database.entity.AssetEntity
import com.alhadi.cmms.database.entity.AuditLogEntity
import com.alhadi.cmms.database.entity.ItemEntity
import com.alhadi.cmms.database.entity.StockTransactionEntity
import com.alhadi.cmms.database.entity.SyncQueueEntity
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.database.entity.WorkOrderEntity
import com.alhadi.cmms.database.entity.WorkOrderExecutionLogEntity
import com.alhadi.cmms.database.entity.WorkOrderStatusHistoryEntity
import com.alhadi.cmms.database.entity.WorkRequestEntity
import com.alhadi.cmms.database.entity.WorkOrderMaterialEntity
import com.alhadi.cmms.database.entity.InventoryRequestLineEntity
import com.alhadi.cmms.database.entity.InventoryRequestEntity
import com.alhadi.cmms.database.entity.StockBalanceEntity
import com.alhadi.cmms.database.entity.WarehouseEntity

@Database(
    entities = [
        UserEntity::class,
        AssetEntity::class,
        WorkRequestEntity::class,
        WorkOrderEntity::class,
        WorkOrderStatusHistoryEntity::class,
        WorkOrderExecutionLogEntity::class,
        ItemEntity::class,
        StockTransactionEntity::class,
        WarehouseEntity::class,
        StockBalanceEntity::class,
        InventoryRequestEntity::class,
        InventoryRequestLineEntity::class,
        WorkOrderMaterialEntity::class,
        SyncQueueEntity::class,
        AuditLogEntity::class
    ],
    version = 4,
    exportSchema = true
)
@TypeConverters(RoomConverters::class)
abstract class AlhadiCmmsDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun assetDao(): AssetDao
    abstract fun workRequestDao(): WorkRequestDao
    abstract fun workOrderDao(): WorkOrderDao
    abstract fun workOrderStatusHistoryDao(): WorkOrderStatusHistoryDao
    abstract fun workOrderExecutionLogDao(): WorkOrderExecutionLogDao
    abstract fun itemDao(): ItemDao
    abstract fun stockTransactionDao(): StockTransactionDao
    abstract fun warehouseDao(): WarehouseDao
    abstract fun stockBalanceDao(): StockBalanceDao
    abstract fun inventoryRequestDao(): InventoryRequestDao
    abstract fun inventoryRequestLineDao(): InventoryRequestLineDao
    abstract fun workOrderMaterialDao(): WorkOrderMaterialDao
    abstract fun syncQueueDao(): SyncQueueDao
    abstract fun auditLogDao(): AuditLogDao
}
