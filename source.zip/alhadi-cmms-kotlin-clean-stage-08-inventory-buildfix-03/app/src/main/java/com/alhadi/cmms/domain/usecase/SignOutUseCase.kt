package com.alhadi.cmms.domain.usecase

import com.alhadi.cmms.domain.repository.AuthRepository

class SignOutUseCase(
    private val authRepository: AuthRepository
) {
    operator fun invoke() {
        authRepository.signOut()
    }
}
