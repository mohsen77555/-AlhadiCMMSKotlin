package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "work_order_execution_logs",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["workOrderId"]),
        Index(value = ["technicianId"]),
        Index(value = ["createdAt"]),
        Index(value = ["companyId", "workOrderId", "createdAt"])
    ]
)
data class WorkOrderExecutionLogEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val workOrderId: String,
    val technicianId: String,
    val logType: String = "TECHNICIAN_COMPLETION",
    val startedAt: Long? = null,
    val finishedAt: Long? = null,
    val laborMinutes: Int,
    val summary: String,
    val notes: String? = null,
    val createdAt: Long,
    val createdBy: String,
    val updatedAt: Long,
    val updatedBy: String,
    val isDeleted: Boolean = false,
    val version: Long = 1,
    val syncVersion: Long = 0
)
