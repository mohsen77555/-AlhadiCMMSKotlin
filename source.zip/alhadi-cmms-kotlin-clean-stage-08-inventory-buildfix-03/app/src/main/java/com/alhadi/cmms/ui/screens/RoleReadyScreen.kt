package com.alhadi.cmms.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.alhadi.cmms.core.model.arabicLabel
import com.alhadi.cmms.database.entity.UserEntity

@Composable
fun RoleReadyScreen(
    profile: UserEntity?,
    onSignOut: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(18.dp)
                ) {
                    Text(
                        text = "تم تحميل الصلاحيات بنجاح",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    if (profile == null) {
                        Text(
                            text = "لم يتم العثور على الملف المحلي. أعد تسجيل الدخول.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.error
                        )
                    } else {
                        Text("المستخدم: ${profile.displayName}")
                        Text("البريد: ${profile.email}")
                        Text("الدور: ${profile.role.arabicLabel()} / ${profile.role.name}")
                        Text("الشركة: ${profile.companyId.ifBlank { "غير محددة" }}")
                        Text("تم حفظ ملف المستخدم في Room كمصدر محلي بعد Firebase Auth.")
                        Text(
                            text = "تم تحميل الدور الحقيقي، ولن تظهر تبويبات غير مسموحة لهذا المستخدم.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = onSignOut,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("تسجيل الخروج")
                    }
                }
            }
        }
    }
}
