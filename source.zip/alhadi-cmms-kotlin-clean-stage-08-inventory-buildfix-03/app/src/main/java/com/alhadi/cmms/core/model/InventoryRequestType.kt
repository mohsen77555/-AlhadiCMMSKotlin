package com.alhadi.cmms.core.model

enum class InventoryRequestType {
    ISSUE_TO_WORK_ORDER,
    RETURN_FROM_WORK_ORDER,
    TRANSFER,
    ADJUSTMENT
}

fun InventoryRequestType.arabicLabel(): String = when (this) {
    InventoryRequestType.ISSUE_TO_WORK_ORDER -> "صرف لأمر عمل"
    InventoryRequestType.RETURN_FROM_WORK_ORDER -> "إرجاع من أمر عمل"
    InventoryRequestType.TRANSFER -> "تحويل مخزني"
    InventoryRequestType.ADJUSTMENT -> "تسوية مخزون"
}
