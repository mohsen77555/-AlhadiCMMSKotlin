package com.alhadi.cmms.core.model

enum class WorkRequestStatus {
    SUBMITTED,
    UNDER_REVIEW,
    APPROVED,
    REJECTED,
    CONVERTED_TO_WORK_ORDER,
    CANCELLED
}

fun WorkRequestStatus.arabicLabel(): String = when (this) {
    WorkRequestStatus.SUBMITTED -> "مقدم"
    WorkRequestStatus.UNDER_REVIEW -> "تحت المراجعة"
    WorkRequestStatus.APPROVED -> "معتمد"
    WorkRequestStatus.REJECTED -> "مرفوض"
    WorkRequestStatus.CONVERTED_TO_WORK_ORDER -> "محول إلى أمر عمل"
    WorkRequestStatus.CANCELLED -> "ملغي"
}
