package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.alhadi.cmms.database.entity.AuditLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AuditLogDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(log: AuditLogEntity)

    @Query("SELECT * FROM audit_logs WHERE companyId = :companyId ORDER BY performedAt DESC LIMIT :limit")
    fun observeLatest(companyId: String, limit: Int = 200): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_logs WHERE companyId = :companyId AND entityType = :entityType AND entityId = :entityId ORDER BY performedAt DESC")
    fun observeForEntity(companyId: String, entityType: String, entityId: String): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_logs WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): AuditLogEntity?
}
