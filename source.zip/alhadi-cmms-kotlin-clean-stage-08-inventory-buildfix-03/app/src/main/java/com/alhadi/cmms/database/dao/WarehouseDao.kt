package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.alhadi.cmms.database.entity.WarehouseEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WarehouseDao {
    @Upsert
    suspend fun upsert(warehouse: WarehouseEntity)

    @Upsert
    suspend fun upsertAll(warehouses: List<WarehouseEntity>)

    @Query("SELECT * FROM warehouses WHERE id = :id AND isDeleted = 0 LIMIT 1")
    suspend fun getById(id: String): WarehouseEntity?

    @Query("SELECT * FROM warehouses WHERE companyId = :companyId AND isDeleted = 0 ORDER BY isMain DESC, warehouseCode ASC")
    fun observeForCompany(companyId: String): Flow<List<WarehouseEntity>>

    @Query("SELECT * FROM warehouses WHERE companyId = :companyId AND isDeleted = 0 ORDER BY isMain DESC, warehouseCode ASC")
    suspend fun getForCompany(companyId: String): List<WarehouseEntity>
}
