package com.alhadi.cmms.domain.repository

import com.alhadi.cmms.database.entity.InventoryRequestEntity
import com.alhadi.cmms.database.entity.InventoryRequestLineEntity
import com.alhadi.cmms.database.entity.ItemEntity
import com.alhadi.cmms.database.entity.StockBalanceEntity
import com.alhadi.cmms.database.entity.StockTransactionEntity
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.database.entity.WarehouseEntity
import com.alhadi.cmms.database.entity.WorkOrderMaterialEntity
import kotlinx.coroutines.flow.Flow

interface InventoryRepository {
    fun observeItems(companyId: String): Flow<List<ItemEntity>>
    fun observeWarehouses(companyId: String): Flow<List<WarehouseEntity>>
    fun observeStockBalances(companyId: String): Flow<List<StockBalanceEntity>>
    fun observeStockTransactions(companyId: String): Flow<List<StockTransactionEntity>>
    fun observeInventoryRequests(companyId: String): Flow<List<InventoryRequestEntity>>
    fun observeInventoryRequestLines(companyId: String): Flow<List<InventoryRequestLineEntity>>
    fun observeWorkOrderMaterials(companyId: String): Flow<List<WorkOrderMaterialEntity>>

    suspend fun saveItemLocal(item: ItemEntity)
    suspend fun addStockTransaction(transaction: StockTransactionEntity)
    suspend fun calculateBalance(companyId: String, itemId: String, warehouseId: String): Double

    suspend fun createItem(profile: UserEntity, code: String, name: String, unit: String, category: String?, minStock: Double, critical: Boolean): ItemEntity
    suspend fun createWarehouse(profile: UserEntity, code: String, name: String, isMain: Boolean): WarehouseEntity
    suspend fun addOpeningBalance(profile: UserEntity, itemId: String, warehouseId: String, quantity: Double, unitCost: Double, reason: String): StockTransactionEntity
    suspend fun receiveStock(profile: UserEntity, itemId: String, warehouseId: String, quantity: Double, unitCost: Double, reason: String): StockTransactionEntity
    suspend fun requestMaterialForWorkOrder(profile: UserEntity, workOrderId: String, itemId: String, warehouseId: String, quantity: Double, notes: String?): InventoryRequestEntity
    suspend fun approveAndIssueRequest(profile: UserEntity, requestId: String): List<StockTransactionEntity>
    suspend fun issueToWorkOrder(profile: UserEntity, workOrderId: String, itemId: String, warehouseId: String, quantity: Double, unitCost: Double, reason: String): StockTransactionEntity
    suspend fun returnFromWorkOrder(profile: UserEntity, workOrderId: String, itemId: String, warehouseId: String, quantity: Double, unitCost: Double, reason: String): StockTransactionEntity
    suspend fun adjustStock(profile: UserEntity, itemId: String, warehouseId: String, quantity: Double, plus: Boolean, reason: String): StockTransactionEntity
}
