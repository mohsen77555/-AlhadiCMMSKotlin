package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.alhadi.cmms.core.model.UserRole

@Entity(
    tableName = "users",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["email"], unique = true),
        Index(value = ["role"])
    ]
)
data class UserEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val email: String,
    val displayName: String,
    val role: UserRole,
    val isActive: Boolean = true,
    val permissionsJson: String = "{}",
    val createdAt: Long,
    val createdBy: String,
    val updatedAt: Long,
    val updatedBy: String,
    val deletedAt: Long? = null,
    val deletedBy: String? = null,
    val isDeleted: Boolean = false,
    val version: Long = 1,
    val syncVersion: Long = 0
)
