package com.alhadi.cmms.domain.repository

import com.alhadi.cmms.core.model.WorkRequestStatus
import com.alhadi.cmms.database.entity.WorkRequestEntity
import kotlinx.coroutines.flow.Flow

interface WorkRequestRepository {
    fun observeRequesterRequests(companyId: String, requesterId: String): Flow<List<WorkRequestEntity>>
    fun observeCompanyRequests(companyId: String): Flow<List<WorkRequestEntity>>
    suspend fun saveLocal(request: WorkRequestEntity)
    suspend fun updateStatus(id: String, status: WorkRequestStatus, updatedAt: Long, updatedBy: String)
}
