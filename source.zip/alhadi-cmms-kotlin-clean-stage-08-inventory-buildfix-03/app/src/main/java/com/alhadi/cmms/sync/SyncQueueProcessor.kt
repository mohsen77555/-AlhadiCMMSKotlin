package com.alhadi.cmms.sync

import androidx.room.withTransaction
import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.core.model.WorkOrderStatus
import com.alhadi.cmms.database.AlhadiCmmsDatabase
import com.alhadi.cmms.database.entity.SyncQueueEntity
import com.alhadi.cmms.database.entity.WorkOrderEntity
import com.alhadi.cmms.firebase.SyncRemoteDataSource

class SyncQueueProcessor(
    private val database: AlhadiCmmsDatabase,
    private val remoteDataSource: SyncRemoteDataSource
) {
    private val syncQueueDao = database.syncQueueDao()
    private val workOrderDao = database.workOrderDao()
    private val statusHistoryDao = database.workOrderStatusHistoryDao()
    private val executionLogDao = database.workOrderExecutionLogDao()
    private val auditLogDao = database.auditLogDao()
    private val itemDao = database.itemDao()
    private val warehouseDao = database.warehouseDao()
    private val stockBalanceDao = database.stockBalanceDao()
    private val stockTransactionDao = database.stockTransactionDao()
    private val inventoryRequestDao = database.inventoryRequestDao()
    private val inventoryRequestLineDao = database.inventoryRequestLineDao()
    private val workOrderMaterialDao = database.workOrderMaterialDao()

    suspend fun processDueItems(limit: Int = DEFAULT_BATCH_LIMIT): SyncProcessResult {
        val now = now()
        syncQueueDao.markStuckSyncingAsFailed(
            message = "تمت إعادة فتح عملية مزامنة كانت عالقة في حالة SYNCING.",
            nextRetryAt = now
        )

        val items = syncQueueDao.nextPending(now, limit)
        var synced = 0
        var failed = 0
        var conflicts = 0
        var skipped = 0

        for (item in items) {
            when (processOne(item)) {
                ItemResult.SYNCED -> synced += 1
                ItemResult.FAILED -> failed += 1
                ItemResult.CONFLICT -> conflicts += 1
                ItemResult.SKIPPED -> skipped += 1
            }
        }

        return SyncProcessResult(
            scanned = items.size,
            synced = synced,
            failed = failed,
            conflicts = conflicts,
            skipped = skipped
        )
    }

    private suspend fun processOne(item: SyncQueueEntity): ItemResult {
        database.withTransaction {
            syncQueueDao.updateStatus(
                id = item.id,
                status = SyncStatus.SYNCING,
                retryCount = item.retryCount,
                lastError = null,
                nextRetryAt = null
            )
            if (item.entityType == SyncEntityType.WORK_ORDER) {
                val order = workOrderDao.getById(item.entityId)
                if (order != null) {
                    workOrderDao.updateSyncState(
                        id = order.id,
                        syncStatus = SyncStatus.SYNCING,
                        lastSyncError = null,
                        lastRemoteUpdatedAt = order.lastRemoteUpdatedAt,
                        syncVersion = order.syncVersion
                    )
                }
            }
        }

        return runCatching {
            when (item.entityType) {
                SyncEntityType.WORK_ORDER -> uploadWorkOrder(item)
                SyncEntityType.WORK_ORDER_STATUS_HISTORY -> uploadStatusHistory(item)
                SyncEntityType.WORK_ORDER_EXECUTION_LOG -> uploadExecutionLog(item)
                SyncEntityType.AUDIT_LOG -> uploadAuditLog(item)
                SyncEntityType.ITEM -> uploadItem(item)
                SyncEntityType.WAREHOUSE -> uploadWarehouse(item)
                SyncEntityType.STOCK_BALANCE -> uploadStockBalance(item)
                SyncEntityType.STOCK_TRANSACTION -> uploadStockTransaction(item)
                SyncEntityType.INVENTORY_REQUEST -> uploadInventoryRequest(item)
                SyncEntityType.INVENTORY_REQUEST_LINE -> uploadInventoryRequestLine(item)
                SyncEntityType.WORK_ORDER_MATERIAL -> uploadWorkOrderMaterial(item)
                else -> markFailed(item, "نوع كيان غير مدعوم في طابور المزامنة: ${item.entityType}")
            }
        }.getOrElse { error ->
            markFailed(item, error.message ?: "فشل غير معروف أثناء رفع العملية.")
        }
    }

    private suspend fun uploadWorkOrder(item: SyncQueueEntity): ItemResult {
        val order = workOrderDao.getById(item.entityId)
            ?: return markFailed(item, "أمر العمل غير موجود محليًا: ${item.entityId}")

        val conflictReason = detectWorkOrderConflict(order)
        if (conflictReason != null) {
            return markConflict(item, order, conflictReason)
        }

        remoteDataSource.upsertWorkOrder(order)
        markSynced(item)
        workOrderDao.updateSyncState(
            id = order.id,
            syncStatus = SyncStatus.SYNCED,
            lastSyncError = null,
            lastRemoteUpdatedAt = now(),
            syncVersion = order.syncVersion + 1
        )
        return ItemResult.SYNCED
    }

    private suspend fun uploadStatusHistory(item: SyncQueueEntity): ItemResult {
        val history = statusHistoryDao.getById(item.entityId)
            ?: return markFailed(item, "سجل الحالة غير موجود محليًا: ${item.entityId}")
        remoteDataSource.upsertStatusHistory(history)
        markSynced(item)
        return ItemResult.SYNCED
    }

    private suspend fun uploadExecutionLog(item: SyncQueueEntity): ItemResult {
        val log = executionLogDao.getById(item.entityId)
            ?: return markFailed(item, "سجل التنفيذ غير موجود محليًا: ${item.entityId}")
        remoteDataSource.upsertExecutionLog(log)
        markSynced(item)
        return ItemResult.SYNCED
    }

    private suspend fun uploadAuditLog(item: SyncQueueEntity): ItemResult {
        val log = auditLogDao.getById(item.entityId)
            ?: return markFailed(item, "Audit Log غير موجود محليًا: ${item.entityId}")
        remoteDataSource.upsertAuditLog(log)
        markSynced(item)
        return ItemResult.SYNCED
    }

    private suspend fun uploadItem(item: SyncQueueEntity): ItemResult {
        val local = itemDao.getById(item.entityId) ?: return markFailed(item, "الصنف غير موجود محليًا: ${item.entityId}")
        remoteDataSource.upsertItem(local)
        markSynced(item)
        return ItemResult.SYNCED
    }

    private suspend fun uploadWarehouse(item: SyncQueueEntity): ItemResult {
        val local = warehouseDao.getById(item.entityId) ?: return markFailed(item, "المخزن غير موجود محليًا: ${item.entityId}")
        remoteDataSource.upsertWarehouse(local)
        markSynced(item)
        return ItemResult.SYNCED
    }

    private suspend fun uploadStockBalance(item: SyncQueueEntity): ItemResult {
        val local = stockBalanceDao.getById(item.entityId) ?: return markFailed(item, "رصيد المخزون غير موجود محليًا: ${item.entityId}")
        remoteDataSource.upsertStockBalance(local)
        markSynced(item)
        return ItemResult.SYNCED
    }

    private suspend fun uploadStockTransaction(item: SyncQueueEntity): ItemResult {
        val local = stockTransactionDao.getById(item.entityId) ?: return markFailed(item, "حركة المخزون غير موجودة محليًا: ${item.entityId}")
        remoteDataSource.upsertStockTransaction(local)
        markSynced(item)
        return ItemResult.SYNCED
    }

    private suspend fun uploadInventoryRequest(item: SyncQueueEntity): ItemResult {
        val local = inventoryRequestDao.getById(item.entityId) ?: return markFailed(item, "طلب المخزون غير موجود محليًا: ${item.entityId}")
        remoteDataSource.upsertInventoryRequest(local)
        markSynced(item)
        return ItemResult.SYNCED
    }

    private suspend fun uploadInventoryRequestLine(item: SyncQueueEntity): ItemResult {
        val local = inventoryRequestLineDao.getById(item.entityId) ?: return markFailed(item, "سطر طلب المخزون غير موجود محليًا: ${item.entityId}")
        remoteDataSource.upsertInventoryRequestLine(local)
        markSynced(item)
        return ItemResult.SYNCED
    }

    private suspend fun uploadWorkOrderMaterial(item: SyncQueueEntity): ItemResult {
        val local = workOrderMaterialDao.getById(item.entityId) ?: return markFailed(item, "مادة أمر العمل غير موجودة محليًا: ${item.entityId}")
        remoteDataSource.upsertWorkOrderMaterial(local)
        markSynced(item)
        return ItemResult.SYNCED
    }

    private suspend fun detectWorkOrderConflict(order: WorkOrderEntity): String? {
        val remote = remoteDataSource.fetchWorkOrderState(order.companyId, order.id)
        if (!remote.exists) return null

        if (remote.status == WorkOrderStatus.CANCELLED && order.status != WorkOrderStatus.CANCELLED) {
            return "أمر العمل أصبح ملغيًا في السيرفر قبل رفع التعديل المحلي. يحتاج مراجعة."
        }

        if (remote.version > order.version && remote.status != null && remote.status != order.status) {
            return "تم تغيير حالة أمر العمل في السيرفر قبل رفع التعديل المحلي. النسخة المحلية=${order.version}، نسخة السيرفر=${remote.version}."
        }

        if (
            remote.updatedAt != null &&
            order.lastRemoteUpdatedAt != null &&
            remote.updatedAt > order.lastRemoteUpdatedAt &&
            remote.status != null &&
            remote.status != order.status
        ) {
            return "تم تحديث أمر العمل في السيرفر بعد آخر نسخة محلية مستلمة. يحتاج مراجعة قبل الرفع."
        }

        return null
    }

    private suspend fun markSynced(item: SyncQueueEntity) {
        syncQueueDao.updateStatus(
            id = item.id,
            status = SyncStatus.SYNCED,
            retryCount = item.retryCount,
            lastError = null,
            nextRetryAt = null
        )
    }

    private suspend fun markFailed(item: SyncQueueEntity, message: String): ItemResult {
        val now = now()
        val newRetryCount = item.retryCount + 1
        val nextRetryAt = SyncBackoffPolicy.nextRetryAt(now, newRetryCount)

        syncQueueDao.updateStatus(
            id = item.id,
            status = SyncStatus.FAILED,
            retryCount = newRetryCount,
            lastError = message,
            nextRetryAt = nextRetryAt
        )

        if (item.entityType == SyncEntityType.WORK_ORDER) {
            val order = workOrderDao.getById(item.entityId)
            if (order != null) {
                workOrderDao.updateSyncState(
                    id = order.id,
                    syncStatus = SyncStatus.FAILED,
                    lastSyncError = message,
                    lastRemoteUpdatedAt = order.lastRemoteUpdatedAt,
                    syncVersion = order.syncVersion
                )
            }
        }

        return ItemResult.FAILED
    }

    private suspend fun markConflict(item: SyncQueueEntity, order: WorkOrderEntity, message: String): ItemResult {
        syncQueueDao.updateStatus(
            id = item.id,
            status = SyncStatus.CONFLICT,
            retryCount = item.retryCount,
            lastError = message,
            nextRetryAt = null
        )
        workOrderDao.updateSyncState(
            id = order.id,
            syncStatus = SyncStatus.CONFLICT,
            lastSyncError = message,
            lastRemoteUpdatedAt = order.lastRemoteUpdatedAt,
            syncVersion = order.syncVersion
        )
        return ItemResult.CONFLICT
    }

    private fun now(): Long = System.currentTimeMillis()

    private enum class ItemResult {
        SYNCED,
        FAILED,
        CONFLICT,
        SKIPPED
    }

    private companion object {
        const val DEFAULT_BATCH_LIMIT = 25
    }
}
