package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.alhadi.cmms.core.model.SyncOperationType
import com.alhadi.cmms.core.model.SyncStatus

@Entity(
    tableName = "sync_queue",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["entityType", "entityId"]),
        Index(value = ["status"]),
        Index(value = ["nextRetryAt"]),
        Index(value = ["priority"])
    ]
)
data class SyncQueueEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val entityType: String,
    val entityId: String,
    val operationType: SyncOperationType,
    val payloadJson: String,
    val status: SyncStatus = SyncStatus.PENDING,
    val retryCount: Int = 0,
    val lastError: String? = null,
    val createdAt: Long,
    val nextRetryAt: Long? = null,
    val createdBy: String,
    val priority: Int = 5
)
