package com.alhadi.cmms.sync

import com.alhadi.cmms.core.model.SyncStatus

data class WorkOrderRealtimeSyncState(
    val status: SyncStatus,
    val messageAr: String,
    val receivedCount: Int = 0,
    val lastEventAt: Long? = null,
    val errorAr: String? = null
) {
    companion object {
        fun idle(): WorkOrderRealtimeSyncState = WorkOrderRealtimeSyncState(
            status = SyncStatus.LOCAL_ONLY,
            messageAr = "لم يبدأ مستمع Firestore بعد. الشاشة ما زالت تقرأ من Room."
        )

        fun listening(): WorkOrderRealtimeSyncState = WorkOrderRealtimeSyncState(
            status = SyncStatus.SYNCING,
            messageAr = "جارٍ تشغيل مستمع Firestore حسب الدور...",
            lastEventAt = System.currentTimeMillis()
        )

        fun synced(count: Int): WorkOrderRealtimeSyncState = WorkOrderRealtimeSyncState(
            status = SyncStatus.SYNCED,
            messageAr = "تم تحديث Room من Firestore بدون زر تحديث.",
            receivedCount = count,
            lastEventAt = System.currentTimeMillis()
        )

        fun failed(message: String): WorkOrderRealtimeSyncState = WorkOrderRealtimeSyncState(
            status = SyncStatus.FAILED,
            messageAr = "فشل مستمع Firestore أو رفع التحديث.",
            lastEventAt = System.currentTimeMillis(),
            errorAr = message
        )
    }
}
