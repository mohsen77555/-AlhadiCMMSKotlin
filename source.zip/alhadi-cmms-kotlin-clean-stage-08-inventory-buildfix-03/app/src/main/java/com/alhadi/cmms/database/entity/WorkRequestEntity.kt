package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.alhadi.cmms.core.model.WorkRequestStatus

@Entity(
    tableName = "work_requests",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["companyId", "requestNo"], unique = true),
        Index(value = ["requestedBy"]),
        Index(value = ["assetId"]),
        Index(value = ["status"])
    ]
)
data class WorkRequestEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val requestNo: String,
    val title: String,
    val description: String,
    val assetId: String? = null,
    val requestedBy: String,
    val status: WorkRequestStatus = WorkRequestStatus.SUBMITTED,
    val priority: String = "MEDIUM",
    val reviewNote: String? = null,
    val rejectedReason: String? = null,
    val convertedWorkOrderId: String? = null,
    val createdAt: Long,
    val createdBy: String,
    val updatedAt: Long,
    val updatedBy: String,
    val deletedAt: Long? = null,
    val deletedBy: String? = null,
    val isDeleted: Boolean = false,
    val version: Long = 1,
    val syncVersion: Long = 0
)
