package com.alhadi.cmms.domain.repository

import com.alhadi.cmms.database.entity.AuditLogEntity
import kotlinx.coroutines.flow.Flow

interface AuditLogRepository {
    fun observeLatest(companyId: String, limit: Int = 200): Flow<List<AuditLogEntity>>
    fun observeEntityAudit(companyId: String, entityType: String, entityId: String): Flow<List<AuditLogEntity>>
    suspend fun append(log: AuditLogEntity)
}
