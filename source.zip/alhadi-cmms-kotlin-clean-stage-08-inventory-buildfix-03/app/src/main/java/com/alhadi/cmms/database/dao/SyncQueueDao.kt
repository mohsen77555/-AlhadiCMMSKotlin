package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.database.entity.SyncQueueEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SyncQueueDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueue(item: SyncQueueEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun enqueueAll(items: List<SyncQueueEntity>)

    @Update
    suspend fun update(item: SyncQueueEntity)

    @Query("SELECT * FROM sync_queue WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): SyncQueueEntity?

    @Query("SELECT * FROM sync_queue WHERE companyId = :companyId ORDER BY priority ASC, createdAt ASC")
    fun observeForCompany(companyId: String): Flow<List<SyncQueueEntity>>

    @Query("SELECT * FROM sync_queue WHERE status IN ('PENDING','FAILED') AND (nextRetryAt IS NULL OR nextRetryAt <= :now) ORDER BY priority ASC, createdAt ASC LIMIT :limit")
    suspend fun nextPending(now: Long, limit: Int = 25): List<SyncQueueEntity>

    @Query("UPDATE sync_queue SET status = :status, retryCount = :retryCount, lastError = :lastError, nextRetryAt = :nextRetryAt WHERE id = :id")
    suspend fun updateStatus(id: String, status: SyncStatus, retryCount: Int, lastError: String?, nextRetryAt: Long?)

    @Query("DELETE FROM sync_queue WHERE id = :id AND status = 'SYNCED'")
    suspend fun deleteIfSynced(id: String)

    @Query("UPDATE sync_queue SET status = 'FAILED', lastError = :message, nextRetryAt = :nextRetryAt WHERE status = 'SYNCING'")
    suspend fun markStuckSyncingAsFailed(message: String, nextRetryAt: Long)
}
