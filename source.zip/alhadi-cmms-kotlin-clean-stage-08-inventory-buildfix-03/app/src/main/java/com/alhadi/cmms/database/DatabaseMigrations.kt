package com.alhadi.cmms.database

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

object DatabaseMigrations {
    private val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE work_orders ADD COLUMN startedBy TEXT")
            db.execSQL("ALTER TABLE work_orders ADD COLUMN completedBy TEXT")
            db.execSQL("ALTER TABLE work_orders ADD COLUMN closedBy TEXT")
            db.execSQL("ALTER TABLE work_orders ADD COLUMN actualLaborMinutes INTEGER")
            db.execSQL("ALTER TABLE work_orders ADD COLUMN technicianCompletionNotes TEXT")
            db.execSQL("ALTER TABLE work_orders ADD COLUMN lastStatusReason TEXT")

            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS work_order_status_history (
                    id TEXT NOT NULL PRIMARY KEY,
                    companyId TEXT NOT NULL,
                    workOrderId TEXT NOT NULL,
                    fromStatus TEXT,
                    toStatus TEXT NOT NULL,
                    reason TEXT,
                    changedBy TEXT NOT NULL,
                    changedByRole TEXT NOT NULL,
                    changedAt INTEGER NOT NULL,
                    createdAt INTEGER NOT NULL,
                    createdBy TEXT NOT NULL,
                    isDeleted INTEGER NOT NULL DEFAULT 0,
                    version INTEGER NOT NULL DEFAULT 1,
                    syncVersion INTEGER NOT NULL DEFAULT 0
                )
                """.trimIndent()
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_status_history_companyId ON work_order_status_history(companyId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_status_history_workOrderId ON work_order_status_history(workOrderId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_status_history_changedBy ON work_order_status_history(changedBy)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_status_history_changedAt ON work_order_status_history(changedAt)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_status_history_companyId_workOrderId_changedAt ON work_order_status_history(companyId, workOrderId, changedAt)")

            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS work_order_execution_logs (
                    id TEXT NOT NULL PRIMARY KEY,
                    companyId TEXT NOT NULL,
                    workOrderId TEXT NOT NULL,
                    technicianId TEXT NOT NULL,
                    logType TEXT NOT NULL DEFAULT 'TECHNICIAN_COMPLETION',
                    startedAt INTEGER,
                    finishedAt INTEGER,
                    laborMinutes INTEGER NOT NULL,
                    summary TEXT NOT NULL,
                    notes TEXT,
                    createdAt INTEGER NOT NULL,
                    createdBy TEXT NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    updatedBy TEXT NOT NULL,
                    isDeleted INTEGER NOT NULL DEFAULT 0,
                    version INTEGER NOT NULL DEFAULT 1,
                    syncVersion INTEGER NOT NULL DEFAULT 0
                )
                """.trimIndent()
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_execution_logs_companyId ON work_order_execution_logs(companyId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_execution_logs_workOrderId ON work_order_execution_logs(workOrderId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_execution_logs_technicianId ON work_order_execution_logs(technicianId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_execution_logs_createdAt ON work_order_execution_logs(createdAt)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_execution_logs_companyId_workOrderId_createdAt ON work_order_execution_logs(companyId, workOrderId, createdAt)")
        }
    }


    private val MIGRATION_2_3 = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE work_orders ADD COLUMN syncStatus TEXT NOT NULL DEFAULT 'SYNCED'")
            db.execSQL("ALTER TABLE work_orders ADD COLUMN lastSyncError TEXT")
            db.execSQL("ALTER TABLE work_orders ADD COLUMN lastRemoteUpdatedAt INTEGER")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_orders_syncStatus ON work_orders(syncStatus)")
        }
    }


    private val MIGRATION_3_4 = object : Migration(3, 4) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS warehouses (
                    id TEXT NOT NULL PRIMARY KEY,
                    companyId TEXT NOT NULL,
                    warehouseCode TEXT NOT NULL,
                    warehouseName TEXT NOT NULL,
                    locationId TEXT,
                    isMain INTEGER NOT NULL DEFAULT 0,
                    createdAt INTEGER NOT NULL,
                    createdBy TEXT NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    updatedBy TEXT NOT NULL,
                    deletedAt INTEGER,
                    deletedBy TEXT,
                    isDeleted INTEGER NOT NULL DEFAULT 0,
                    version INTEGER NOT NULL DEFAULT 1,
                    syncVersion INTEGER NOT NULL DEFAULT 0
                )
                """.trimIndent()
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS index_warehouses_companyId ON warehouses(companyId)")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_warehouses_companyId_warehouseCode ON warehouses(companyId, warehouseCode)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_warehouses_isMain ON warehouses(isMain)")

            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS stock_balances (
                    id TEXT NOT NULL PRIMARY KEY,
                    companyId TEXT NOT NULL,
                    itemId TEXT NOT NULL,
                    warehouseId TEXT NOT NULL,
                    quantityOnHand REAL NOT NULL,
                    reservedQuantity REAL NOT NULL DEFAULT 0.0,
                    availableQuantity REAL NOT NULL,
                    minStockSnapshot REAL NOT NULL DEFAULT 0.0,
                    isBelowMinimum INTEGER NOT NULL DEFAULT 0,
                    lastCalculatedAt INTEGER NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    updatedBy TEXT NOT NULL,
                    version INTEGER NOT NULL DEFAULT 1,
                    syncVersion INTEGER NOT NULL DEFAULT 0
                )
                """.trimIndent()
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS index_stock_balances_companyId ON stock_balances(companyId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_stock_balances_itemId ON stock_balances(itemId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_stock_balances_warehouseId ON stock_balances(warehouseId)")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_stock_balances_companyId_itemId_warehouseId ON stock_balances(companyId, itemId, warehouseId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_stock_balances_isBelowMinimum ON stock_balances(isBelowMinimum)")

            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS inventory_requests (
                    id TEXT NOT NULL PRIMARY KEY,
                    companyId TEXT NOT NULL,
                    requestNo TEXT NOT NULL,
                    type TEXT NOT NULL,
                    status TEXT NOT NULL,
                    workOrderId TEXT,
                    requestedBy TEXT NOT NULL,
                    requestedByRole TEXT NOT NULL,
                    requestedAt INTEGER NOT NULL,
                    approvedBy TEXT,
                    approvedAt INTEGER,
                    issuedBy TEXT,
                    issuedAt INTEGER,
                    rejectedBy TEXT,
                    rejectedAt INTEGER,
                    reason TEXT,
                    notes TEXT,
                    lineCount INTEGER NOT NULL DEFAULT 0,
                    createdAt INTEGER NOT NULL,
                    createdBy TEXT NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    updatedBy TEXT NOT NULL,
                    deletedAt INTEGER,
                    deletedBy TEXT,
                    isDeleted INTEGER NOT NULL DEFAULT 0,
                    version INTEGER NOT NULL DEFAULT 1,
                    syncVersion INTEGER NOT NULL DEFAULT 0,
                    syncStatus TEXT NOT NULL DEFAULT 'LOCAL_ONLY',
                    lastSyncError TEXT
                )
                """.trimIndent()
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_requests_companyId ON inventory_requests(companyId)")
            db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS index_inventory_requests_companyId_requestNo ON inventory_requests(companyId, requestNo)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_requests_workOrderId ON inventory_requests(workOrderId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_requests_requestedBy ON inventory_requests(requestedBy)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_requests_status ON inventory_requests(status)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_requests_type ON inventory_requests(type)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_requests_syncStatus ON inventory_requests(syncStatus)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_requests_createdAt ON inventory_requests(createdAt)")

            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS inventory_request_lines (
                    id TEXT NOT NULL PRIMARY KEY,
                    companyId TEXT NOT NULL,
                    requestId TEXT NOT NULL,
                    workOrderId TEXT,
                    itemId TEXT NOT NULL,
                    warehouseId TEXT NOT NULL,
                    requestedQuantity REAL NOT NULL,
                    approvedQuantity REAL NOT NULL DEFAULT 0.0,
                    issuedQuantity REAL NOT NULL DEFAULT 0.0,
                    returnedQuantity REAL NOT NULL DEFAULT 0.0,
                    unitCostSnapshot REAL NOT NULL DEFAULT 0.0,
                    notes TEXT,
                    createdAt INTEGER NOT NULL,
                    createdBy TEXT NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    updatedBy TEXT NOT NULL,
                    isDeleted INTEGER NOT NULL DEFAULT 0,
                    version INTEGER NOT NULL DEFAULT 1,
                    syncVersion INTEGER NOT NULL DEFAULT 0
                )
                """.trimIndent()
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_request_lines_companyId ON inventory_request_lines(companyId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_request_lines_requestId ON inventory_request_lines(requestId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_request_lines_itemId ON inventory_request_lines(itemId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_request_lines_warehouseId ON inventory_request_lines(warehouseId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_inventory_request_lines_workOrderId ON inventory_request_lines(workOrderId)")

            db.execSQL(
                """
                CREATE TABLE IF NOT EXISTS work_order_materials (
                    id TEXT NOT NULL PRIMARY KEY,
                    companyId TEXT NOT NULL,
                    workOrderId TEXT NOT NULL,
                    itemId TEXT NOT NULL,
                    warehouseId TEXT,
                    plannedQuantity REAL NOT NULL DEFAULT 0.0,
                    requestedQuantity REAL NOT NULL DEFAULT 0.0,
                    reservedQuantity REAL NOT NULL DEFAULT 0.0,
                    issuedQuantity REAL NOT NULL DEFAULT 0.0,
                    returnedQuantity REAL NOT NULL DEFAULT 0.0,
                    unitCostSnapshot REAL NOT NULL DEFAULT 0.0,
                    inventoryRequestId TEXT,
                    notes TEXT,
                    createdAt INTEGER NOT NULL,
                    createdBy TEXT NOT NULL,
                    updatedAt INTEGER NOT NULL,
                    updatedBy TEXT NOT NULL,
                    isDeleted INTEGER NOT NULL DEFAULT 0,
                    version INTEGER NOT NULL DEFAULT 1,
                    syncVersion INTEGER NOT NULL DEFAULT 0
                )
                """.trimIndent()
            )
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_materials_companyId ON work_order_materials(companyId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_materials_workOrderId ON work_order_materials(workOrderId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_materials_itemId ON work_order_materials(itemId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_materials_warehouseId ON work_order_materials(warehouseId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_work_order_materials_inventoryRequestId ON work_order_materials(inventoryRequestId)")
        }
    }

    fun all(): Array<Migration> = arrayOf(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
}
