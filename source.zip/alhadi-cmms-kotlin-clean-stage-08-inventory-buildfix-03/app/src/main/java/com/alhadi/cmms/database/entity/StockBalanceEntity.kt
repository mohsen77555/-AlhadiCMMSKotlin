package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "stock_balances",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["itemId"]),
        Index(value = ["warehouseId"]),
        Index(value = ["companyId", "itemId", "warehouseId"], unique = true),
        Index(value = ["isBelowMinimum"])
    ]
)
data class StockBalanceEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val itemId: String,
    val warehouseId: String,
    val quantityOnHand: Double,
    val reservedQuantity: Double = 0.0,
    val availableQuantity: Double = quantityOnHand - reservedQuantity,
    val minStockSnapshot: Double = 0.0,
    val isBelowMinimum: Boolean = false,
    val lastCalculatedAt: Long,
    val updatedAt: Long,
    val updatedBy: String,
    val version: Long = 1,
    val syncVersion: Long = 0
)
