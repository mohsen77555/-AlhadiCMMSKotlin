package com.alhadi.cmms.domain.repository

import com.alhadi.cmms.database.entity.UserEntity
import kotlinx.coroutines.flow.Flow

interface UserRepository {
    fun observeUser(userId: String): Flow<UserEntity?>
    fun observeCompanyUsers(companyId: String): Flow<List<UserEntity>>
    suspend fun getUser(userId: String): UserEntity?
    suspend fun cacheUserProfile(user: UserEntity)
}
