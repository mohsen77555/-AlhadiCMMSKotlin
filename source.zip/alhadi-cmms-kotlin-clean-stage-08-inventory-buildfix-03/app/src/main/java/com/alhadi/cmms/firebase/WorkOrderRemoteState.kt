package com.alhadi.cmms.firebase

import com.alhadi.cmms.core.model.WorkOrderStatus

data class WorkOrderRemoteState(
    val exists: Boolean,
    val version: Long,
    val status: WorkOrderStatus?,
    val updatedAt: Long?
)
