package com.alhadi.cmms

import android.app.Application
import com.alhadi.cmms.sync.SyncQueueScheduler

class AlhadiCmmsApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        SyncQueueScheduler.schedulePeriodicSync(this)
        SyncQueueScheduler.enqueueOneTimeSync(this)
    }
}
