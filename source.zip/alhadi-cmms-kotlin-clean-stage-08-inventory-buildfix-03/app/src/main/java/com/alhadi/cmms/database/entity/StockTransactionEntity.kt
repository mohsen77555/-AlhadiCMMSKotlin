package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.alhadi.cmms.core.model.StockTransactionType

@Entity(
    tableName = "stock_transactions",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["companyId", "transactionNo"], unique = true),
        Index(value = ["itemId"]),
        Index(value = ["warehouseId"]),
        Index(value = ["workOrderId"]),
        Index(value = ["type"]),
        Index(value = ["transactionAt"])
    ]
)
data class StockTransactionEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val transactionNo: String,
    val itemId: String,
    val warehouseId: String,
    val workOrderId: String? = null,
    val type: StockTransactionType,
    val quantity: Double,
    val unitCost: Double = 0.0,
    val totalCost: Double = 0.0,
    val reason: String? = null,
    val approvedBy: String? = null,
    val approvedAt: Long? = null,
    val transactionAt: Long,
    val createdAt: Long,
    val createdBy: String,
    val updatedAt: Long,
    val updatedBy: String,
    val deletedAt: Long? = null,
    val deletedBy: String? = null,
    val isDeleted: Boolean = false,
    val version: Long = 1,
    val syncVersion: Long = 0
)
