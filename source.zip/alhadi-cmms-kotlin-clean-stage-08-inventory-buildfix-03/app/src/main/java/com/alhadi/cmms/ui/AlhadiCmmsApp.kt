package com.alhadi.cmms.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.alhadi.cmms.ui.navigation.AppNavHost
import com.alhadi.cmms.ui.theme.AlhadiCmmsTheme

@Composable
fun AlhadiCmmsApp() {
    AlhadiCmmsTheme(darkTheme = false) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            AppNavHost()
        }
    }
}
