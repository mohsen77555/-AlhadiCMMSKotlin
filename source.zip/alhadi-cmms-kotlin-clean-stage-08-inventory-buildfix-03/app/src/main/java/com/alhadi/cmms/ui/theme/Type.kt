package com.alhadi.cmms.ui.theme

import androidx.compose.material3.Typography

// No Google Fonts and no external font downloads.
// Android system font is used to keep startup fast and fully offline.
val AlhadiTypography = Typography()
