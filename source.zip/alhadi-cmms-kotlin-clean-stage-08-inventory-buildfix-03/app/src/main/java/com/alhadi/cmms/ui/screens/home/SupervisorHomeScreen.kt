package com.alhadi.cmms.ui.screens.home

import androidx.compose.runtime.Composable
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.ui.navigation.allowedHomeMenus
import com.alhadi.cmms.ui.navigation.stage04PolicyNotesAr

@Composable
fun SupervisorHomeScreen(
    profile: UserEntity,
    onSignOut: () -> Unit
) {
    RoleHomeScaffold(
        profile = profile,
        screenTitleAr = "واجهة المشرف",
        welcomeAr = "مرحبًا، هذه واجهة المشرف وتعرض نطاق الإشراف فقط.",
        allowedMenus = UserRole.SUPERVISOR.allowedHomeMenus(),
        policyNotes = UserRole.SUPERVISOR.stage04PolicyNotesAr(),
        onSignOut = onSignOut
    )
}
