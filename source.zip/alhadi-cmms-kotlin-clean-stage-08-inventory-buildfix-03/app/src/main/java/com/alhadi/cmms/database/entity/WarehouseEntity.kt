package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "warehouses",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["companyId", "warehouseCode"], unique = true),
        Index(value = ["isMain"])
    ]
)
data class WarehouseEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val warehouseCode: String,
    val warehouseName: String,
    val locationId: String? = null,
    val isMain: Boolean = false,
    val createdAt: Long,
    val createdBy: String,
    val updatedAt: Long,
    val updatedBy: String,
    val deletedAt: Long? = null,
    val deletedBy: String? = null,
    val isDeleted: Boolean = false,
    val version: Long = 1,
    val syncVersion: Long = 0
)
