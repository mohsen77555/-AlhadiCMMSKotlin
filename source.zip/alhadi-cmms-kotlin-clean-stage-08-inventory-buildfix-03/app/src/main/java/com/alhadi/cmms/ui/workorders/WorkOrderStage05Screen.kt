package com.alhadi.cmms.ui.workorders

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.core.model.WorkOrderStatus
import com.alhadi.cmms.core.model.arabicLabel
import com.alhadi.cmms.database.entity.AuditLogEntity
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.database.entity.WorkOrderEntity
import com.alhadi.cmms.database.entity.WorkOrderExecutionLogEntity
import com.alhadi.cmms.database.entity.WorkOrderStatusHistoryEntity
import com.alhadi.cmms.ui.navigation.RoleMenuItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val ModernSurface = Color.White
private val ModernText = Color(0xFF111827)
private val MutedText = Color(0xFF64748B)
private val DeepNavy = Color(0xFF111827)
private val BrandBlue = Color(0xFF2563EB)
private val BrandOrange = Color(0xFFF97316)
private val BrandGreen = Color(0xFF16A34A)
private val BrandPurple = Color(0xFF7C3AED)
private val SoftBlue = Color(0xFFEAF1FF)
private val SoftOrange = Color(0xFFFFF1E8)
private val SoftGreen = Color(0xFFEAFBF1)
private val ErrorSoft = Color(0xFFFEE2E2)

@Composable
fun WorkOrderModernScreen(
    profile: UserEntity,
    menu: RoleMenuItem
) {
    val application = LocalContext.current.applicationContext as Application
    val viewModel: WorkOrderViewModel = viewModel(
        factory = WorkOrderViewModelFactory(application, profile)
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var showCreate by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableStateOf("all") }

    val baseOrders = state.orders.filteredForMenu(menu.id)
    val visibleOrders = baseOrders
        .filter { order -> filter == "all" || order.status.name == filter }
        .filter { order ->
            query.isBlank() || listOf(order.title, order.workOrderNo, order.assetId.orEmpty(), order.priority)
                .any { value -> value.contains(query, ignoreCase = true) }
        }
    val selectedOrder = state.selectedOrder ?: visibleOrders.firstOrNull() ?: baseOrders.firstOrNull()

    Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
        WorkOrderControlPanel(
            orderCount = baseOrders.size,
            syncQueueSummary = state.syncQueueSummary,
            syncMessage = state.realtimeSyncState.errorAr ?: state.realtimeSyncState.messageAr,
            onRunSync = viewModel::runSyncNow
        )

        state.messageAr?.let { MessageCard(message = it, isError = false, onDismiss = viewModel::clearMessage) }
        state.errorAr?.let { MessageCard(message = it.friendlyFirestoreMessage(), isError = true, onDismiss = viewModel::clearMessage) }

        SearchBar(value = query, onValueChange = { query = it })
        StatusFilters(selected = filter, onSelect = { filter = it })

        if (profile.role.canCreateWorkOrdersFromUi()) {
            Button(
                onClick = { showCreate = !showCreate },
                colors = ButtonDefaults.buttonColors(containerColor = BrandOrange, contentColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().height(58.dp)
            ) {
                Text(if (showCreate) "إغلاق نموذج أمر العمل" else "+ أمر عمل جديد", fontWeight = FontWeight.ExtraBold)
            }
            if (showCreate) {
                CreateWorkOrderPanel(
                    profile = profile,
                    isBusy = state.isBusy,
                    onCreate = { title, description, assetId, assignedTechnicianId, priority ->
                        viewModel.createWorkOrder(title, description, assetId, assignedTechnicianId, priority)
                        showCreate = false
                    }
                )
            }
        }

        if (visibleOrders.isEmpty()) {
            WorkOrdersEmptyCard(profile = profile, menu = menu)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("قائمة أوامر العمل", color = ModernText, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                visibleOrders.forEach { order ->
                    WorkOrderCompactCard(
                        order = order,
                        selected = selectedOrder?.id == order.id,
                        onSelect = { viewModel.selectWorkOrder(order.id) }
                    )
                }
            }
        }

        selectedOrder?.let { order ->
            WorkOrderDetailsPanel(
                profile = profile,
                order = order,
                statusHistory = state.statusHistory,
                executionLogs = state.executionLogs,
                auditLogs = state.auditLogs,
                isBusy = state.isBusy,
                onStart = viewModel::startSelectedWorkOrder,
                onComplete = viewModel::completeSelectedWorkOrder,
                onClose = viewModel::closeSelectedWorkOrder,
                onChangeStatus = viewModel::changeSelectedStatus
            )
        }
    }
}

@Composable
private fun WorkOrderControlPanel(
    orderCount: Int,
    syncQueueSummary: SyncQueueUiSummary,
    syncMessage: String,
    onRunSync: () -> Unit
) {
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface)) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text("أوامر العمل", color = ModernText, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text("إنشاء، متابعة، وإغلاق", color = MutedText, style = MaterialTheme.typography.bodyMedium)
                }
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(BrandBlue)) {
                    Text("▣", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                SummaryMini(title = "أوامر", value = orderCount.toString(), color = BrandBlue, modifier = Modifier.weight(1f))
                SummaryMini(title = "Queue", value = syncQueueSummary.total.toString(), color = DeepNavy, modifier = Modifier.weight(1f))
                SummaryMini(title = "Pending", value = syncQueueSummary.pending.toString(), color = BrandOrange, modifier = Modifier.weight(1f))
                SummaryMini(title = "Failed", value = syncQueueSummary.failed.toString(), color = Color(0xFFDC2626), modifier = Modifier.weight(1f))
            }
            if (syncMessage.isNotBlank()) {
                Surface(shape = RoundedCornerShape(18.dp), color = SoftBlue, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = syncMessage.friendlyFirestoreMessage(),
                        color = Color(0xFF1E3A8A),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
            OutlinedButton(onClick = onRunSync, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Text("تشغيل المزامنة عند توفر الإنترنت", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun SummaryMini(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFF8FAFC), modifier = modifier.height(74.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(value, color = color, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text(title, color = MutedText, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun SearchBar(value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text("بحث...") },
        leadingIcon = { Text("🔍") },
        shape = RoundedCornerShape(24.dp),
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun StatusFilters(selected: String, onSelect: (String) -> Unit) {
    val filters = listOf(
        "all" to "الكل",
        WorkOrderStatus.DRAFT.name to "مسودة",
        WorkOrderStatus.ASSIGNED.name to "جاهز",
        WorkOrderStatus.IN_PROGRESS.name to "قيد التنفيذ",
        WorkOrderStatus.COMPLETED_BY_TECHNICIAN.name to "مكتمل",
        WorkOrderStatus.CLOSED.name to "مغلق"
    )
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(filters, key = { it.first }) { item ->
            FilterPill(text = item.second, selected = item.first == selected, onClick = { onSelect(item.first) })
        }
    }
}

@Composable
private fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (selected) DeepNavy else ModernSurface,
        shadowElevation = if (selected) 5.dp else 1.dp,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = text,
            color = if (selected) Color.White else ModernText,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
        )
    }
}

@Composable
private fun CreateWorkOrderPanel(
    profile: UserEntity,
    isBusy: Boolean,
    onCreate: (String, String?, String?, String?, String) -> Unit
) {
    var title by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var assetId by rememberSaveable { mutableStateOf("") }
    var assignedTechnicianId by rememberSaveable { mutableStateOf(if (profile.role == UserRole.SUPERVISOR) profile.id else "") }
    var priority by rememberSaveable { mutableStateOf("MEDIUM") }

    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface)) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(16.dp)) {
            Text("إنشاء أمر عمل", color = ModernText, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            ModernTextField(value = title, onValueChange = { title = it }, label = "عنوان أمر العمل")
            ModernTextField(value = description, onValueChange = { description = it }, label = "الوصف", minLines = 2)
            ModernTextField(value = assetId, onValueChange = { assetId = it }, label = "Asset ID / Code مثل ELA-01")
            ModernTextField(value = assignedTechnicianId, onValueChange = { assignedTechnicianId = it }, label = "Technician User ID للإسناد")
            ModernTextField(value = priority, onValueChange = { priority = it.uppercase() }, label = "Priority: LOW / MEDIUM / HIGH / CRITICAL")
            Button(
                enabled = !isBusy,
                onClick = {
                    onCreate(title, description.ifBlank { null }, assetId.ifBlank { null }, assignedTechnicianId.ifBlank { null }, priority)
                    title = ""
                    description = ""
                },
                colors = ButtonDefaults.buttonColors(containerColor = BrandOrange, contentColor = Color.White),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) { Text("حفظ أمر العمل", fontWeight = FontWeight.ExtraBold) }
        }
    }
}

@Composable
private fun ModernTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    minLines: Int = 1,
    keyboardType: KeyboardType = KeyboardType.Text
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        shape = RoundedCornerShape(20.dp),
        singleLine = minLines == 1,
        minLines = minLines,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun WorkOrderCompactCard(order: WorkOrderEntity, selected: Boolean, onSelect: () -> Unit) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) SoftBlue else ModernSurface),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onSelect)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(14.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(order.title, color = ModernText, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(order.workOrderNo, color = MutedText, style = MaterialTheme.typography.bodySmall)
                }
                StatusBadge(status = order.status)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallTag("Asset: ${order.assetId ?: "—"}")
                SmallTag(order.priority)
                SmallTag(order.syncStatus.arabicLabel())
            }
        }
    }
}

@Composable
private fun WorkOrderDetailsPanel(
    profile: UserEntity,
    order: WorkOrderEntity,
    statusHistory: List<WorkOrderStatusHistoryEntity>,
    executionLogs: List<WorkOrderExecutionLogEntity>,
    auditLogs: List<AuditLogEntity>,
    isBusy: Boolean,
    onStart: () -> Unit,
    onComplete: (Int, String) -> Unit,
    onClose: (String) -> Unit,
    onChangeStatus: (WorkOrderStatus, String) -> Unit
) {
    var laborMinutesText by rememberSaveable(order.id) { mutableStateOf(order.actualLaborMinutes?.toString().orEmpty()) }
    var completionSummary by rememberSaveable(order.id) { mutableStateOf(order.executionSummary ?: order.technicianCompletionNotes.orEmpty()) }
    var managerReason by rememberSaveable(order.id) { mutableStateOf(order.lastStatusReason.orEmpty()) }

    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface), modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("تفاصيل أمر العمل", color = ModernText, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                    Text(order.title, color = MutedText, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                StatusBadge(status = order.status)
            }
            DetailLine("الأصل", order.assetId ?: "غير مرتبط")
            DetailLine("الأولوية", order.priority)
            DetailLine("الفني", order.assignedTechnicianId ?: "غير مسند")
            DetailLine("آخر تحديث", order.updatedAt.formatDateTimeAr())

            if (profile.role.canExecuteWorkOrders()) {
                TechnicianActions(
                    order = order,
                    isBusy = isBusy,
                    laborMinutesText = laborMinutesText,
                    completionSummary = completionSummary,
                    onLaborMinutesChange = { value -> laborMinutesText = value.filter { it.isDigit() } },
                    onSummaryChange = { completionSummary = it },
                    onStart = onStart,
                    onComplete = { onComplete(laborMinutesText.toIntOrNull() ?: 0, completionSummary) }
                )
            }
            if (profile.role.canManageWorkOrdersFromUi()) {
                ManagerActions(
                    currentStatus = order.status,
                    reason = managerReason,
                    isBusy = isBusy,
                    onReasonChange = { managerReason = it },
                    onClose = { onClose(managerReason) },
                    onChangeStatus = { target -> onChangeStatus(target, managerReason) }
                )
            }
            HistoryPreview(statusHistory = statusHistory, executionLogs = executionLogs, auditLogs = auditLogs)
        }
    }
}

@Composable
private fun TechnicianActions(
    order: WorkOrderEntity,
    isBusy: Boolean,
    laborMinutesText: String,
    completionSummary: String,
    onLaborMinutesChange: (String) -> Unit,
    onSummaryChange: (String) -> Unit,
    onStart: () -> Unit,
    onComplete: () -> Unit
) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = SoftGreen)) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(14.dp)) {
            Text("إجراءات الفني", color = Color(0xFF166534), fontWeight = FontWeight.ExtraBold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                ActionButton(
                    text = "بدء العمل",
                    color = BrandGreen,
                    enabled = !isBusy && order.status !in listOf(WorkOrderStatus.IN_PROGRESS, WorkOrderStatus.CLOSED, WorkOrderStatus.CANCELLED, WorkOrderStatus.COMPLETED_BY_TECHNICIAN),
                    modifier = Modifier.weight(1f),
                    onClick = onStart
                )
                ActionButton(
                    text = "إكمال",
                    color = BrandBlue,
                    enabled = !isBusy && order.status == WorkOrderStatus.IN_PROGRESS,
                    modifier = Modifier.weight(1f),
                    onClick = onComplete
                )
            }
            ModernTextField(value = laborMinutesText, onValueChange = onLaborMinutesChange, label = "وقت التنفيذ بالدقائق", keyboardType = KeyboardType.Number)
            ModernTextField(value = completionSummary, onValueChange = onSummaryChange, label = "ملخص التنفيذ", minLines = 2)
        }
    }
}

@Composable
private fun ManagerActions(
    currentStatus: WorkOrderStatus,
    reason: String,
    isBusy: Boolean,
    onReasonChange: (String) -> Unit,
    onClose: () -> Unit,
    onChangeStatus: (WorkOrderStatus) -> Unit
) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = SoftOrange)) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(14.dp)) {
            Text("إجراءات الإدارة", color = Color(0xFF9A3412), fontWeight = FontWeight.ExtraBold)
            ModernTextField(value = reason, onValueChange = onReasonChange, label = "سبب تغيير الحالة / الإغلاق", minLines = 2)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatusAction("مخطط", WorkOrderStatus.PLANNED, currentStatus, isBusy, onChangeStatus, Modifier.weight(1f))
                StatusAction("مسند", WorkOrderStatus.ASSIGNED, currentStatus, isBusy, onChangeStatus, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                StatusAction("مواد", WorkOrderStatus.WAITING_MATERIAL, currentStatus, isBusy, onChangeStatus, Modifier.weight(1f))
                StatusAction("إلغاء", WorkOrderStatus.CANCELLED, currentStatus, isBusy, onChangeStatus, Modifier.weight(1f))
            }
            ActionButton(
                text = "إغلاق أمر العمل",
                color = DeepNavy,
                enabled = !isBusy && currentStatus != WorkOrderStatus.CLOSED,
                modifier = Modifier.fillMaxWidth(),
                onClick = onClose
            )
        }
    }
}

@Composable
private fun StatusAction(
    label: String,
    target: WorkOrderStatus,
    current: WorkOrderStatus,
    isBusy: Boolean,
    onChangeStatus: (WorkOrderStatus) -> Unit,
    modifier: Modifier
) {
    OutlinedButton(
        enabled = !isBusy && current != target,
        onClick = { onChangeStatus(target) },
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) { Text(label) }
}

@Composable
private fun ActionButton(text: String, color: Color, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        enabled = enabled,
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White),
        shape = RoundedCornerShape(18.dp),
        modifier = modifier.height(52.dp)
    ) { Text(text, fontWeight = FontWeight.ExtraBold) }
}

@Composable
private fun HistoryPreview(
    statusHistory: List<WorkOrderStatusHistoryEntity>,
    executionLogs: List<WorkOrderExecutionLogEntity>,
    auditLogs: List<AuditLogEntity>
) {
    Surface(shape = RoundedCornerShape(22.dp), color = Color(0xFFF8FAFC), modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(14.dp)) {
            Text("السجل والتدقيق", color = ModernText, fontWeight = FontWeight.ExtraBold)
            Text("الحالات: ${statusHistory.size}  •  التنفيذ: ${executionLogs.size}  •  Audit: ${auditLogs.size}", color = MutedText)
            val latest = statusHistory.firstOrNull()?.let { "آخر حالة: ${it.toStatus.arabicLabel()}" }
                ?: executionLogs.firstOrNull()?.let { "آخر تنفيذ: ${it.summary}" }
                ?: "لا توجد سجلات بعد."
            Text(latest, color = MutedText, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun WorkOrdersEmptyCard(profile: UserEntity, menu: RoleMenuItem) {
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface), modifier = Modifier.fillMaxWidth()) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(24.dp)) {
            Text("○", color = Color(0xFFCBD5E1), style = MaterialTheme.typography.headlineLarge)
            Text("لا توجد أوامر عمل هنا", color = ModernText, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            Text("ستظهر أوامر ${menu.titleAr} من Room تلقائيًا عند إنشائها أو مزامنتها. الدور الحالي: ${profile.role.arabicLabel()}.", color = MutedText, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun MessageCard(message: String, isError: Boolean, onDismiss: () -> Unit) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = if (isError) ErrorSoft else SoftGreen),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(14.dp)) {
            Text(text = message, color = if (isError) Color(0xFF991B1B) else Color(0xFF166534))
            TextButton(onClick = onDismiss) { Text("إخفاء") }
        }
    }
}

@Composable
private fun StatusBadge(status: WorkOrderStatus) {
    val color = when (status) {
        WorkOrderStatus.IN_PROGRESS -> BrandBlue
        WorkOrderStatus.COMPLETED_BY_TECHNICIAN, WorkOrderStatus.CLOSED -> BrandGreen
        WorkOrderStatus.WAITING_MATERIAL, WorkOrderStatus.WAITING_APPROVAL -> BrandOrange
        WorkOrderStatus.CANCELLED -> Color(0xFFDC2626)
        else -> DeepNavy
    }
    Surface(shape = RoundedCornerShape(99.dp), color = color) {
        Text(status.arabicLabel(), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
    }
}

@Composable
private fun SmallTag(text: String) {
    Surface(shape = RoundedCornerShape(99.dp), color = Color(0xFFF1F5F9)) {
        Text(text, color = Color(0xFF475569), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
        Text(label, color = MutedText, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.width(12.dp))
        Text(value, color = ModernText, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    HorizontalDivider(color = Color(0xFFE2E8F0))
}

private fun List<WorkOrderEntity>.filteredForMenu(menuId: String): List<WorkOrderEntity> = when (menuId) {
    "in_progress" -> filter { it.status == WorkOrderStatus.IN_PROGRESS }
    "work_log" -> filter { it.status in setOf(WorkOrderStatus.IN_PROGRESS, WorkOrderStatus.COMPLETED_BY_TECHNICIAN, WorkOrderStatus.CLOSED) }
    else -> this
}

private fun UserRole.canCreateWorkOrdersFromUi(): Boolean = this in setOf(
    UserRole.ADMIN,
    UserRole.MAINTENANCE_MANAGER,
    UserRole.SUPERVISOR
)

private fun UserRole.canManageWorkOrdersFromUi(): Boolean = this in setOf(
    UserRole.ADMIN,
    UserRole.MAINTENANCE_MANAGER,
    UserRole.SUPERVISOR
)

private fun UserRole.canExecuteWorkOrders(): Boolean = this in setOf(
    UserRole.ADMIN,
    UserRole.MAINTENANCE_MANAGER,
    UserRole.SUPERVISOR,
    UserRole.TECHNICIAN
)

private fun Long?.formatDateTimeAr(): String {
    if (this == null || this <= 0L) return "غير محدد"
    val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
    return formatter.format(Date(this))
}

private fun String.friendlyFirestoreMessage(): String {
    val lower = lowercase()
    return when {
        contains("FAILED_PRECONDITION", ignoreCase = true) || lower.contains("requires an index") ->
            "يحتاج Firestore إلى فهرس لهذا الاستعلام. تم منع عرض الرابط الطويل داخل التطبيق. راجع ملف FIRESTORE_INDEXES_STAGE_06_AR.md أو أنشئ الفهرس من Firebase Console."
        lower.contains("client is offline") ->
            "لا يمكن الاتصال بـ Firestore الآن. سيتم الاعتماد على البيانات المحلية، وستتم المزامنة عند عودة الاتصال."
        length > 260 -> take(260) + "…"
        else -> this
    }
}

private fun SyncStatus.arabicLabel(): String = when (this) {
    SyncStatus.LOCAL_ONLY -> "محلي"
    SyncStatus.PENDING -> "بانتظار"
    SyncStatus.SYNCING -> "جارٍ"
    SyncStatus.SYNCED -> "مزامن"
    SyncStatus.FAILED -> "فشل"
    SyncStatus.CONFLICT -> "تعارض"
}
