package com.alhadi.cmms.domain.usecase

import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.domain.repository.AuthRepository

class LoadCurrentUserProfileUseCase(
    private val authRepository: AuthRepository
) {
    suspend operator fun invoke(): UserEntity {
        return authRepository.loadCurrentUserProfile()
    }
}
