package com.alhadi.cmms.ui.inventory

import android.app.Application
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alhadi.cmms.core.model.InventoryRequestStatus
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.core.model.arabicLabel
import com.alhadi.cmms.database.entity.InventoryRequestEntity
import com.alhadi.cmms.database.entity.ItemEntity
import com.alhadi.cmms.database.entity.StockBalanceEntity
import com.alhadi.cmms.database.entity.StockTransactionEntity
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.database.entity.WarehouseEntity
import com.alhadi.cmms.ui.navigation.RoleMenuItem

private val ModernSurface = Color.White
private val ModernText = Color(0xFF111827)
private val MutedText = Color(0xFF64748B)
private val DeepNavy = Color(0xFF111827)
private val BrandBlue = Color(0xFF2563EB)
private val BrandOrange = Color(0xFFF97316)
private val BrandGreen = Color(0xFF16A34A)
private val BrandPurple = Color(0xFF7C3AED)
private val Danger = Color(0xFFDC2626)
private val SoftBlue = Color(0xFFEAF1FF)
private val SoftOrange = Color(0xFFFFF1E8)
private val SoftGreen = Color(0xFFEAFBF1)
private val SoftRed = Color(0xFFFEE2E2)

@Composable
fun InventoryModernScreen(
    profile: UserEntity,
    menu: RoleMenuItem
) {
    val application = LocalContext.current.applicationContext as Application
    val viewModel: InventoryViewModel = viewModel(factory = InventoryViewModelFactory(application, profile))
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    var selectedTab by rememberSaveable { mutableStateOf("overview") }
    var query by rememberSaveable { mutableStateOf("") }

    val visibleItems = state.items.filter { item ->
        query.isBlank() || listOf(item.itemCode, item.itemName, item.category.orEmpty()).any { it.contains(query, ignoreCase = true) }
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.fillMaxWidth()) {
        InventoryHeader(state = state, onRunSync = viewModel::runSyncNow)
        state.messageAr?.let { InlineMessage(message = it, isError = false, onDismiss = viewModel::clearMessage) }
        state.errorAr?.let { InlineMessage(message = it, isError = true, onDismiss = viewModel::clearMessage) }
        InventoryKpiRow(state = state)
        InventoryTabs(selected = selectedTab, profile = profile, onSelect = { selectedTab = it })
        SearchBar(value = query, onValueChange = { query = it })

        when (selectedTab) {
            "overview" -> InventoryOverview(state = state, items = visibleItems)
            "items" -> ItemMasterPanel(profile = profile, state = state, items = visibleItems, isBusy = state.isBusy, onCreateItem = viewModel::createItem)
            "warehouses" -> WarehousePanel(profile = profile, state = state, isBusy = state.isBusy, onCreateWarehouse = viewModel::createWarehouse)
            "balance" -> BalancePanel(state = state)
            "transactions" -> TransactionsPanel(profile = profile, state = state, isBusy = state.isBusy, onOpening = viewModel::addOpening, onReceipt = viewModel::receive, onIssue = viewModel::directIssue, onReturn = viewModel::returnFromWorkOrder)
            "requests" -> RequestsPanel(profile = profile, state = state, isBusy = state.isBusy, onRequest = viewModel::requestMaterial, onApprove = viewModel::approveAndIssue)
        }

        GovernanceCard(profile = profile)
    }
}

@Composable
private fun InventoryHeader(state: InventoryUiState, onRunSync: () -> Unit) {
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface)) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(horizontalAlignment = Alignment.Start) {
                    Text("المخزون", color = ModernText, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                    Text("الأصناف، الأرصدة، طلبات الصرف، والحركات", color = MutedText, style = MaterialTheme.typography.bodyMedium)
                }
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(58.dp).clip(RoundedCornerShape(18.dp)).background(BrandOrange)) {
                    Text("▦", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                HeaderMini("أصناف", state.items.size.toString(), BrandBlue, Modifier.weight(1f))
                HeaderMini("Low Stock", state.lowStockCount.toString(), Danger, Modifier.weight(1f))
                HeaderMini("طلبات", state.pendingRequests.toString(), BrandOrange, Modifier.weight(1f))
                HeaderMini("Queue", state.syncQueueSummary.pending.toString(), DeepNavy, Modifier.weight(1f))
            }
            OutlinedButton(onClick = onRunSync, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Text("تشغيل مزامنة المخزون عند توفر الإنترنت", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun HeaderMini(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Surface(shape = RoundedCornerShape(20.dp), color = Color(0xFFF8FAFC), modifier = modifier.height(74.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(value, color = color, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Text(title, color = MutedText, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun InventoryKpiRow(state: InventoryUiState) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        KpiCard("الرصيد الكلي", formatQty(state.totalOnHand), BrandGreen, SoftGreen, Modifier.weight(1f))
        KpiCard("الحركات", state.transactions.size.toString(), BrandBlue, SoftBlue, Modifier.weight(1f))
        KpiCard("طلبات مفتوحة", state.pendingRequests.toString(), BrandOrange, SoftOrange, Modifier.weight(1f))
    }
}

@Composable
private fun KpiCard(title: String, value: String, color: Color, background: Color, modifier: Modifier = Modifier) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = background), modifier = modifier.height(92.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth().height(92.dp).padding(8.dp)) {
            Text(value, color = color, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            Text(title, color = MutedText, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun InventoryTabs(selected: String, profile: UserEntity, onSelect: (String) -> Unit) {
    val tabs = buildList {
        add("overview" to "نظرة عامة")
        add("items" to "الأصناف")
        add("warehouses" to "المخازن")
        add("balance" to "الأرصدة")
        add("transactions" to "الحركات")
        add("requests" to if (profile.role == UserRole.TECHNICIAN) "طلباتي" else "طلبات الصرف")
    }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(tabs, key = { it.first }) { tab ->
            FilterPill(text = tab.second, selected = selected == tab.first, onClick = { onSelect(tab.first) })
        }
    }
}

@Composable
private fun InventoryOverview(state: InventoryUiState, items: List<ItemEntity>) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionHeader("يحتاج انتباهك", BrandOrange)
        if (state.lowStockCount == 0 && state.pendingRequests == 0) {
            EmptyStateCard("لا شيء عاجل", "لا توجد طلبات صرف مفتوحة أو أصناف منخفضة المخزون.")
        } else {
            if (state.lowStockCount > 0) AlertCard("مواد منخفضة المخزون", "عدد الأصناف تحت الحد الأدنى: ${state.lowStockCount}", Danger)
            if (state.pendingRequests > 0) AlertCard("طلبات صرف تنتظر الاعتماد", "عدد الطلبات المفتوحة: ${state.pendingRequests}", BrandOrange)
        }
        SectionHeader("الأصناف الأحدث", BrandBlue)
        if (items.isEmpty()) EmptyStateCard("لا توجد أصناف", "أنشئ Item Master أولًا، ثم أضف رصيدًا افتتاحيًا كحركة مخزون.")
        items.take(5).forEach { item -> ItemCompactCard(item = item, balance = state.balances.firstOrNull { it.itemId == item.id }) }
    }
}

@Composable
private fun ItemMasterPanel(
    profile: UserEntity,
    state: InventoryUiState,
    items: List<ItemEntity>,
    isBusy: Boolean,
    onCreateItem: (String, String, String, String?, Double, Boolean) -> Unit
) {
    var code by rememberSaveable { mutableStateOf("") }
    var name by rememberSaveable { mutableStateOf("") }
    var unit by rememberSaveable { mutableStateOf("PCS") }
    var category by rememberSaveable { mutableStateOf("قطع غيار") }
    var minStock by rememberSaveable { mutableStateOf("0") }
    var critical by rememberSaveable { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (profile.role.canMaintainItemMaster()) {
            FormCard(title = "إضافة صنف / قطعة غيار", subtitle = "لا يتم إنشاء رصيد هنا. الرصيد ينتج من حركات المخزون فقط.") {
                OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Item Code مثل BRG-6205") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم الصنف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(value = unit, onValueChange = { unit = it }, label = { Text("الوحدة") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = minStock, onValueChange = { minStock = it }, label = { Text("الحد الأدنى") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("التصنيف") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = critical, onCheckedChange = { critical = it })
                    Text("Critical Spare", color = ModernText, fontWeight = FontWeight.Bold)
                }
                ActionButton(text = "+ حفظ الصنف", color = BrandBlue, enabled = !isBusy, modifier = Modifier.fillMaxWidth()) {
                    onCreateItem(code, name, unit, category, minStock.toDoubleOrNull() ?: 0.0, critical)
                }
            }
        }
        SectionHeader("Item Master", BrandBlue)
        if (items.isEmpty()) EmptyStateCard("لا توجد أصناف", "الأصناف ستظهر هنا من Room، ولا تقرأ الشاشة Firebase مباشرة.")
        items.forEach { item -> ItemCompactCard(item = item, balance = state.balances.firstOrNull { it.itemId == item.id }) }
    }
}

@Composable
private fun WarehousePanel(profile: UserEntity, state: InventoryUiState, isBusy: Boolean, onCreateWarehouse: (String, String, Boolean) -> Unit) {
    var code by rememberSaveable { mutableStateOf("MAIN") }
    var name by rememberSaveable { mutableStateOf("المخزن الرئيسي") }
    var isMain by rememberSaveable { mutableStateOf(true) }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (profile.role.canMaintainInventory()) {
            FormCard(title = "إضافة مخزن", subtitle = "المخزن مطلوب قبل أي رصيد أو حركة.") {
                OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Warehouse Code") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("اسم المخزن") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isMain, onCheckedChange = { isMain = it })
                    Text("مخزن رئيسي", color = ModernText, fontWeight = FontWeight.Bold)
                }
                ActionButton(text = "+ حفظ المخزن", color = BrandGreen, enabled = !isBusy, modifier = Modifier.fillMaxWidth()) { onCreateWarehouse(code, name, isMain) }
            }
        }
        if (state.warehouses.isEmpty()) EmptyStateCard("لا توجد مخازن", "أضف المخزن الرئيسي أولًا.")
        state.warehouses.forEach { WarehouseCard(it) }
    }
}

@Composable
private fun BalancePanel(state: InventoryUiState) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionHeader("الأرصدة الحالية", BrandGreen)
        if (state.balances.isEmpty()) EmptyStateCard("لا توجد أرصدة", "أدخل رصيدًا افتتاحيًا كحركة مخزون، ولا تعدل الرصيد مباشرة.")
        state.balances.forEach { balance ->
            val item = state.items.firstOrNull { it.id == balance.itemId }
            val warehouse = state.warehouses.firstOrNull { it.id == balance.warehouseId }
            BalanceCard(balance = balance, item = item, warehouse = warehouse)
        }
    }
}

@Composable
private fun TransactionsPanel(
    profile: UserEntity,
    state: InventoryUiState,
    isBusy: Boolean,
    onOpening: (String, String, Double, Double) -> Unit,
    onReceipt: (String, String, Double, Double) -> Unit,
    onIssue: (String, String, String, Double, Double) -> Unit,
    onReturn: (String, String, String, Double, Double) -> Unit
) {
    var selectedItemId by rememberSaveable { mutableStateOf("") }
    var selectedWarehouseId by rememberSaveable { mutableStateOf("") }
    var workOrderId by rememberSaveable { mutableStateOf("") }
    var quantity by rememberSaveable { mutableStateOf("1") }
    var unitCost by rememberSaveable { mutableStateOf("0") }
    val itemId = selectedItemId.ifBlank { state.items.firstOrNull()?.id.orEmpty() }
    val warehouseId = selectedWarehouseId.ifBlank { state.warehouses.firstOrNull()?.id.orEmpty() }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (profile.role.canMaintainInventory()) {
            FormCard(title = "حركة مخزون", subtitle = "كل رصيد ينتج من حركة. لا يوجد تعديل مباشر للرصيد.") {
                EntityPicker(title = "الصنف", selectedId = itemId, items = state.items.map { it.id to "${it.itemCode} - ${it.itemName}" }, onSelect = { selectedItemId = it })
                EntityPicker(title = "المخزن", selectedId = warehouseId, items = state.warehouses.map { it.id to "${it.warehouseCode} - ${it.warehouseName}" }, onSelect = { selectedWarehouseId = it })
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(value = quantity, onValueChange = { quantity = it }, label = { Text("الكمية") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = unitCost, onValueChange = { unitCost = it }, label = { Text("تكلفة الوحدة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.weight(1f))
                }
                OutlinedTextField(value = workOrderId, onValueChange = { workOrderId = it }, label = { Text("Work Order ID للصرف/الإرجاع") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    ActionButton("Opening", BrandGreen, !isBusy, Modifier.weight(1f)) { onOpening(itemId, warehouseId, quantity.toDoubleOrNull() ?: 0.0, unitCost.toDoubleOrNull() ?: 0.0) }
                    ActionButton("Receipt", BrandBlue, !isBusy, Modifier.weight(1f)) { onReceipt(itemId, warehouseId, quantity.toDoubleOrNull() ?: 0.0, unitCost.toDoubleOrNull() ?: 0.0) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    ActionButton("Issue WO", BrandOrange, !isBusy, Modifier.weight(1f)) { onIssue(workOrderId, itemId, warehouseId, quantity.toDoubleOrNull() ?: 0.0, unitCost.toDoubleOrNull() ?: 0.0) }
                    ActionButton("Return WO", BrandPurple, !isBusy, Modifier.weight(1f)) { onReturn(workOrderId, itemId, warehouseId, quantity.toDoubleOrNull() ?: 0.0, unitCost.toDoubleOrNull() ?: 0.0) }
                }
            }
        } else {
            AlertCard("الفني لا يصرف مباشرة", "استخدم تبويب طلبات الصرف لإنشاء طلب مادة، ثم يعتمدها المخزن.", BrandOrange)
        }
        SectionHeader("آخر الحركات", BrandOrange)
        if (state.transactions.isEmpty()) EmptyStateCard("لا توجد حركات", "أول حركة يجب أن تكون Opening أو Receipt غالبًا.")
        state.transactions.take(20).forEach { trx -> TransactionCard(trx = trx, item = state.items.firstOrNull { it.id == trx.itemId }, warehouse = state.warehouses.firstOrNull { it.id == trx.warehouseId }) }
    }
}

@Composable
private fun RequestsPanel(
    profile: UserEntity,
    state: InventoryUiState,
    isBusy: Boolean,
    onRequest: (String, String, String, Double, String?) -> Unit,
    onApprove: (String) -> Unit
) {
    var selectedItemId by rememberSaveable { mutableStateOf("") }
    var selectedWarehouseId by rememberSaveable { mutableStateOf("") }
    var workOrderId by rememberSaveable { mutableStateOf("") }
    var quantity by rememberSaveable { mutableStateOf("1") }
    var notes by rememberSaveable { mutableStateOf("") }
    val itemId = selectedItemId.ifBlank { state.items.firstOrNull()?.id.orEmpty() }
    val warehouseId = selectedWarehouseId.ifBlank { state.warehouses.firstOrNull()?.id.orEmpty() }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        FormCard(title = "طلب مادة لأمر عمل", subtitle = "يحفظ الطلب محليًا ثم يرفع عبر WorkManager. الفني لا يعدل الرصيد.") {
            OutlinedTextField(value = workOrderId, onValueChange = { workOrderId = it }, label = { Text("Work Order ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            EntityPicker(title = "الصنف", selectedId = itemId, items = state.items.map { it.id to "${it.itemCode} - ${it.itemName}" }, onSelect = { selectedItemId = it })
            EntityPicker(title = "المخزن", selectedId = warehouseId, items = state.warehouses.map { it.id to "${it.warehouseCode} - ${it.warehouseName}" }, onSelect = { selectedWarehouseId = it })
            OutlinedTextField(value = quantity, onValueChange = { quantity = it }, label = { Text("الكمية المطلوبة") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
            ActionButton("إرسال طلب المادة", BrandOrange, !isBusy, Modifier.fillMaxWidth()) { onRequest(workOrderId, itemId, warehouseId, quantity.toDoubleOrNull() ?: 0.0, notes) }
        }
        SectionHeader("طلبات الصرف", BrandOrange)
        if (state.requests.isEmpty()) EmptyStateCard("لا توجد طلبات", "طلبات الفنيين ستظهر هنا للمخزن والمدير.")
        state.requests.take(20).forEach { request ->
            RequestCard(
                request = request,
                lines = state.requestLines.filter { it.requestId == request.id },
                canApprove = profile.role.canMaintainInventory() && request.status == InventoryRequestStatus.REQUESTED,
                isBusy = isBusy,
                onApprove = { onApprove(request.id) }
            )
        }
    }
}

@Composable
private fun EntityPicker(title: String, selectedId: String, items: List<Pair<String, String>>, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = ModernText, fontWeight = FontWeight.Bold)
        if (items.isEmpty()) {
            Surface(shape = RoundedCornerShape(18.dp), color = SoftRed, modifier = Modifier.fillMaxWidth()) {
                Text("لا توجد بيانات للاختيار", color = Danger, modifier = Modifier.padding(12.dp), textAlign = TextAlign.Center)
            }
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.first }) { item ->
                    FilterPill(text = item.second.take(24), selected = item.first == selectedId, onClick = { onSelect(item.first) })
                }
            }
        }
    }
}

@Composable
private fun FormCard(title: String, subtitle: String, content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface)) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(16.dp)) {
            SectionHeader(title, BrandOrange)
            Text(subtitle, color = MutedText, style = MaterialTheme.typography.bodyMedium)
            content()
        }
    }
}

@Composable
private fun ItemCompactCard(item: ItemEntity, balance: StockBalanceEntity?) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface), modifier = Modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(16.dp)) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(item.itemName, color = ModernText, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${item.itemCode} • ${item.unit} • ${item.category ?: "بدون تصنيف"}", color = MutedText, style = MaterialTheme.typography.bodySmall)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(formatQty(balance?.quantityOnHand ?: 0.0), color = if (balance?.isBelowMinimum == true) Danger else BrandGreen, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
                Text("الرصيد", color = MutedText, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun WarehouseCard(warehouse: WarehouseEntity) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface), modifier = Modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(16.dp)) {
            Column {
                Text(warehouse.warehouseName, color = ModernText, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text(warehouse.warehouseCode, color = MutedText, style = MaterialTheme.typography.bodySmall)
            }
            StatusPill(if (warehouse.isMain) "رئيسي" else "فرعي", if (warehouse.isMain) BrandGreen else BrandBlue)
        }
    }
}

@Composable
private fun BalanceCard(balance: StockBalanceEntity, item: ItemEntity?, warehouse: WarehouseEntity?) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = if (balance.isBelowMinimum) SoftRed else ModernSurface), modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item?.itemName ?: balance.itemId, color = ModernText, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(warehouse?.warehouseName ?: balance.warehouseId, color = MutedText, style = MaterialTheme.typography.bodySmall)
                }
                Text(formatQty(balance.quantityOnHand), color = if (balance.isBelowMinimum) Danger else BrandGreen, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
            }
            Text("المتاح: ${formatQty(balance.availableQuantity)} • محجوز: ${formatQty(balance.reservedQuantity)} • حد أدنى: ${formatQty(balance.minStockSnapshot)}", color = MutedText, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun TransactionCard(trx: StockTransactionEntity, item: ItemEntity?, warehouse: WarehouseEntity?) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface), modifier = Modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(16.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                Text(trx.type.name, color = ModernText, fontWeight = FontWeight.ExtraBold)
                Text("${item?.itemCode ?: trx.itemId} • ${warehouse?.warehouseCode ?: trx.warehouseId}", color = MutedText, style = MaterialTheme.typography.bodySmall)
                trx.workOrderId?.let { Text("WO: $it", color = MutedText, style = MaterialTheme.typography.bodySmall) }
            }
            Text(formatQty(trx.quantity), color = if (trx.type.name.contains("ISSUE") || trx.type.name.contains("MINUS")) Danger else BrandGreen, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
private fun RequestCard(request: InventoryRequestEntity, lines: List<com.alhadi.cmms.database.entity.InventoryRequestLineEntity>, canApprove: Boolean, isBusy: Boolean, onApprove: () -> Unit) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface), modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(16.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column {
                    Text(request.requestNo, color = ModernText, fontWeight = FontWeight.ExtraBold)
                    Text(request.status.arabicLabel(), color = MutedText, style = MaterialTheme.typography.bodySmall)
                }
                StatusPill(request.type.name.replace('_', ' '), BrandOrange)
            }
            Text("أمر العمل: ${request.workOrderId ?: "غير محدد"} • عدد الأسطر: ${lines.size}", color = MutedText, style = MaterialTheme.typography.bodySmall)
            if (canApprove) {
                ActionButton("اعتماد وصرف", BrandGreen, !isBusy, Modifier.fillMaxWidth(), onApprove)
            }
        }
    }
}

@Composable
private fun GovernanceCard(profile: UserEntity) {
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(16.dp)) {
            Text("قواعد المخزون المطبقة", color = Color.White, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleLarge)
            Text("• لا يوجد تعديل رصيد مباشر.\n• الصرف يتطلب أمر عمل أو طلب صرف.\n• الفني يطلب مادة ولا يصرف مباشرة.\n• كل تغيير ينشئ Stock Transaction و Audit Log.", color = Color(0xFFCBD5E1), style = MaterialTheme.typography.bodyMedium)
            Text("الدور الحالي: ${profile.role.arabicLabel()}", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun InlineMessage(message: String, isError: Boolean, onDismiss: () -> Unit) {
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = if (isError) SoftRed else SoftGreen)) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            Text(message, color = if (isError) Danger else Color(0xFF15803D), modifier = Modifier.weight(1f))
            TextButton(onClick = onDismiss) { Text("إخفاء") }
        }
    }
}

@Composable
private fun SearchBar(value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text("بحث عن صنف أو رقم قطعة") },
        leadingIcon = { Text("🔍") },
        shape = RoundedCornerShape(24.dp),
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(20.dp), color = if (selected) DeepNavy else ModernSurface, shadowElevation = if (selected) 5.dp else 1.dp, modifier = Modifier.clickable(onClick = onClick)) {
        Text(text = text, color = if (selected) Color.White else ModernText, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp), maxLines = 1)
    }
}

@Composable
private fun ActionButton(text: String, color: Color, enabled: Boolean = true, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White), shape = RoundedCornerShape(18.dp), modifier = modifier.height(56.dp)) {
        Text(text, fontWeight = FontWeight.ExtraBold, maxLines = 1)
    }
}

@Composable
private fun EmptyStateCard(title: String, subtitle: String) {
    Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface), modifier = Modifier.fillMaxWidth()) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(22.dp)) {
            Text("○", color = Color(0xFFCBD5E1), style = MaterialTheme.typography.headlineMedium)
            Text(title, color = ModernText, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(subtitle, color = MutedText, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun AlertCard(title: String, subtitle: String, color: Color) {
    Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface), modifier = Modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(16.dp)) {
            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(color))
            Column {
                Text(title, color = ModernText, fontWeight = FontWeight.ExtraBold)
                Text(subtitle, color = MutedText, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(accent))
        Text(title, color = ModernText, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun StatusPill(text: String, color: Color) {
    Surface(shape = RoundedCornerShape(999.dp), color = color.copy(alpha = 0.12f)) {
        Text(text, color = color, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), maxLines = 1)
    }
}

private fun UserRole.canMaintainItemMaster(): Boolean = this in setOf(UserRole.ADMIN, UserRole.MAINTENANCE_MANAGER, UserRole.WAREHOUSE)
private fun UserRole.canMaintainInventory(): Boolean = this in setOf(UserRole.ADMIN, UserRole.WAREHOUSE)
private fun formatQty(value: Double): String = if (value % 1.0 == 0.0) value.toInt().toString() else "%.2f".format(value)
