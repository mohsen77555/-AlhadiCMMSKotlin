package com.alhadi.cmms.ui.navigation

enum class AppRoute(val route: String, val titleAr: String) {
    SPLASH("splash", "شاشة البداية"),
    LOGIN("login", "تسجيل الدخول"),
    LOADING_PERMISSIONS("loading_permissions", "تحميل الصلاحيات"),
    PERMISSION_ERROR("permission_error", "خطأ الصلاحيات"),
    ROLE_READY("role_ready", "تم تحميل الدور"),
    ROLE_HOME("role_home", "واجهة الدور")
}
