package com.alhadi.cmms.domain.repository

import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.database.entity.SyncQueueEntity
import kotlinx.coroutines.flow.Flow

interface SyncQueueRepository {
    fun observeQueue(companyId: String): Flow<List<SyncQueueEntity>>
    suspend fun enqueue(item: SyncQueueEntity)
    suspend fun enqueueAll(items: List<SyncQueueEntity>)
    suspend fun nextPending(now: Long, limit: Int = 25): List<SyncQueueEntity>
    suspend fun updateStatus(id: String, status: SyncStatus, retryCount: Int, lastError: String?, nextRetryAt: Long?)
    suspend fun markStuckSyncingAsFailed(message: String, nextRetryAt: Long)
}
