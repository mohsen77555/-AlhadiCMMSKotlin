package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.alhadi.cmms.database.entity.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Upsert
    suspend fun upsert(user: UserEntity)

    @Upsert
    suspend fun upsertAll(users: List<UserEntity>)

    @Query("SELECT * FROM users WHERE id = :id AND isDeleted = 0 LIMIT 1")
    suspend fun getById(id: String): UserEntity?

    @Query("SELECT * FROM users WHERE id = :id AND isDeleted = 0 LIMIT 1")
    fun observeById(id: String): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE companyId = :companyId AND isDeleted = 0 ORDER BY displayName ASC")
    fun observeCompanyUsers(companyId: String): Flow<List<UserEntity>>

    @Query("UPDATE users SET isDeleted = 1, deletedAt = :deletedAt, deletedBy = :deletedBy, updatedAt = :deletedAt, updatedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)
}
