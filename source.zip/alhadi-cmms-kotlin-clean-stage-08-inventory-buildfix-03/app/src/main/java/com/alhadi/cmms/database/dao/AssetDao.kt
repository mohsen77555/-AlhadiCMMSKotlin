package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.alhadi.cmms.database.entity.AssetEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AssetDao {
    @Upsert
    suspend fun upsert(asset: AssetEntity)

    @Upsert
    suspend fun upsertAll(assets: List<AssetEntity>)

    @Query("SELECT * FROM assets WHERE id = :id AND isDeleted = 0 LIMIT 1")
    suspend fun getById(id: String): AssetEntity?

    @Query("SELECT * FROM assets WHERE id = :id AND isDeleted = 0 LIMIT 1")
    fun observeById(id: String): Flow<AssetEntity?>

    @Query("SELECT * FROM assets WHERE companyId = :companyId AND isDeleted = 0 ORDER BY code ASC")
    fun observeCompanyAssets(companyId: String): Flow<List<AssetEntity>>

    @Query("SELECT * FROM assets WHERE companyId = :companyId AND groupId = :groupId AND isDeleted = 0 ORDER BY code ASC")
    fun observeAssetsByGroup(companyId: String, groupId: String): Flow<List<AssetEntity>>

    @Query("UPDATE assets SET isDeleted = 1, deletedAt = :deletedAt, deletedBy = :deletedBy, updatedAt = :deletedAt, updatedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)
}
