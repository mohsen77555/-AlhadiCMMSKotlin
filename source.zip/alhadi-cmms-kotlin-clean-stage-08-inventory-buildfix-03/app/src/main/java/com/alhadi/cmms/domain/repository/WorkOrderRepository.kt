package com.alhadi.cmms.domain.repository

import com.alhadi.cmms.core.model.WorkOrderStatus
import com.alhadi.cmms.database.entity.AuditLogEntity
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.database.entity.WorkOrderEntity
import com.alhadi.cmms.database.entity.WorkOrderExecutionLogEntity
import com.alhadi.cmms.database.entity.WorkOrderStatusHistoryEntity
import com.alhadi.cmms.sync.WorkOrderRealtimeSyncState
import kotlinx.coroutines.flow.Flow

interface WorkOrderRepository {
    fun observeCompanyWorkOrders(companyId: String): Flow<List<WorkOrderEntity>>
    fun observeTechnicianWorkOrders(companyId: String, technicianId: String): Flow<List<WorkOrderEntity>>
    fun observeSupervisorWorkOrders(companyId: String, supervisorId: String): Flow<List<WorkOrderEntity>>
    fun observeWorkOrdersForRole(profile: UserEntity): Flow<List<WorkOrderEntity>>
    fun observeWorkOrder(id: String): Flow<WorkOrderEntity?>
    fun observeStatusHistory(companyId: String, workOrderId: String): Flow<List<WorkOrderStatusHistoryEntity>>
    fun observeExecutionLogs(companyId: String, workOrderId: String): Flow<List<WorkOrderExecutionLogEntity>>
    fun observeAuditLogs(companyId: String, workOrderId: String): Flow<List<AuditLogEntity>>
    fun startRealtimeSyncForRole(profile: UserEntity): Flow<WorkOrderRealtimeSyncState>
    suspend fun getWorkOrder(id: String): WorkOrderEntity?
    suspend fun saveLocal(workOrder: WorkOrderEntity)
    suspend fun createLocalWorkOrder(
        profile: UserEntity,
        title: String,
        description: String?,
        assetId: String?,
        assignedTechnicianId: String?,
        priority: String
    ): WorkOrderEntity
    suspend fun startWorkOrder(profile: UserEntity, workOrderId: String)
    suspend fun completeWorkOrder(profile: UserEntity, workOrderId: String, laborMinutes: Int, summary: String)
    suspend fun closeWorkOrder(profile: UserEntity, workOrderId: String, reason: String)
    suspend fun changeStatus(profile: UserEntity, workOrderId: String, status: WorkOrderStatus, reason: String)
    suspend fun updateStatus(id: String, status: WorkOrderStatus, updatedAt: Long, updatedBy: String)
}
