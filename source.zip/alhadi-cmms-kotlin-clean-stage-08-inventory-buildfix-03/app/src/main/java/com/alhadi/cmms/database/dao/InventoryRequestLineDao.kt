package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.alhadi.cmms.database.entity.InventoryRequestLineEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface InventoryRequestLineDao {
    @Upsert
    suspend fun upsert(line: InventoryRequestLineEntity)

    @Upsert
    suspend fun upsertAll(lines: List<InventoryRequestLineEntity>)

    @Query("SELECT * FROM inventory_request_lines WHERE id = :id AND isDeleted = 0 LIMIT 1")
    suspend fun getById(id: String): InventoryRequestLineEntity?

    @Query("SELECT * FROM inventory_request_lines WHERE companyId = :companyId AND isDeleted = 0 ORDER BY createdAt DESC")
    fun observeForCompany(companyId: String): Flow<List<InventoryRequestLineEntity>>

    @Query("SELECT * FROM inventory_request_lines WHERE requestId = :requestId AND isDeleted = 0 ORDER BY createdAt ASC")
    suspend fun getForRequest(requestId: String): List<InventoryRequestLineEntity>

    @Query("UPDATE inventory_request_lines SET approvedQuantity = :approvedQuantity, issuedQuantity = :issuedQuantity, updatedAt = :updatedAt, updatedBy = :updatedBy, syncVersion = syncVersion + 1 WHERE id = :id")
    suspend fun markIssued(id: String, approvedQuantity: Double, issuedQuantity: Double, updatedAt: Long, updatedBy: String)
}
