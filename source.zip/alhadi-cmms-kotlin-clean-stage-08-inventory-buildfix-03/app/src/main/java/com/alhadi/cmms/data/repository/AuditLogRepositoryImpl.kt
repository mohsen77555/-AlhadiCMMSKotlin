package com.alhadi.cmms.data.repository

import com.alhadi.cmms.database.dao.AuditLogDao
import com.alhadi.cmms.database.entity.AuditLogEntity
import com.alhadi.cmms.domain.repository.AuditLogRepository
import kotlinx.coroutines.flow.Flow

class AuditLogRepositoryImpl(
    private val auditLogDao: AuditLogDao
) : AuditLogRepository {
    override fun observeLatest(companyId: String, limit: Int): Flow<List<AuditLogEntity>> =
        auditLogDao.observeLatest(companyId, limit)

    override fun observeEntityAudit(companyId: String, entityType: String, entityId: String): Flow<List<AuditLogEntity>> =
        auditLogDao.observeForEntity(companyId, entityType, entityId)

    override suspend fun append(log: AuditLogEntity) = auditLogDao.insert(log)
}
