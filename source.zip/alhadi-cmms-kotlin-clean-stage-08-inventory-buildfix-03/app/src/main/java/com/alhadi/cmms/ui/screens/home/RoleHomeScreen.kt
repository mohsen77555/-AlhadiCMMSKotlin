package com.alhadi.cmms.ui.screens.home

import androidx.compose.runtime.Composable
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.ui.screens.LoadingPermissionsScreen

@Composable
fun RoleHomeScreen(
    profile: UserEntity?,
    onSignOut: () -> Unit
) {
    if (profile == null) {
        LoadingPermissionsScreen(
            message = "جارٍ تحميل الصلاحيات...",
            details = "لن يتم فتح واجهة أي دور بدون ملف مستخدم حقيقي من users/{uid}."
        )
        return
    }

    when (profile.role) {
        UserRole.ADMIN -> AdminHomeScreen(profile = profile, onSignOut = onSignOut)
        UserRole.MAINTENANCE_MANAGER -> MaintenanceManagerHomeScreen(profile = profile, onSignOut = onSignOut)
        UserRole.SUPERVISOR -> SupervisorHomeScreen(profile = profile, onSignOut = onSignOut)
        UserRole.TECHNICIAN -> TechnicianHomeScreen(profile = profile, onSignOut = onSignOut)
        UserRole.WAREHOUSE -> WarehouseHomeScreen(profile = profile, onSignOut = onSignOut)
        UserRole.REQUESTER -> RequesterHomeScreen(profile = profile, onSignOut = onSignOut)
        UserRole.VIEWER -> ViewerHomeScreen(profile = profile, onSignOut = onSignOut)
    }
}
