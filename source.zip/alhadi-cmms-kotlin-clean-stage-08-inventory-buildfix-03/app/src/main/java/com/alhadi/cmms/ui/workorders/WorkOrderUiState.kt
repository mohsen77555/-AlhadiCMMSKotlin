package com.alhadi.cmms.ui.workorders

import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.database.entity.AuditLogEntity
import com.alhadi.cmms.database.entity.SyncQueueEntity
import com.alhadi.cmms.database.entity.WorkOrderEntity
import com.alhadi.cmms.database.entity.WorkOrderExecutionLogEntity
import com.alhadi.cmms.database.entity.WorkOrderStatusHistoryEntity
import com.alhadi.cmms.sync.WorkOrderRealtimeSyncState

data class WorkOrderUiState(
    val orders: List<WorkOrderEntity> = emptyList(),
    val selectedOrder: WorkOrderEntity? = null,
    val statusHistory: List<WorkOrderStatusHistoryEntity> = emptyList(),
    val executionLogs: List<WorkOrderExecutionLogEntity> = emptyList(),
    val auditLogs: List<AuditLogEntity> = emptyList(),
    val syncQueueSummary: SyncQueueUiSummary = SyncQueueUiSummary(),
    val realtimeSyncState: WorkOrderRealtimeSyncState = WorkOrderRealtimeSyncState.idle(),
    val isBusy: Boolean = false,
    val messageAr: String? = null,
    val errorAr: String? = null
)

data class SyncQueueUiSummary(
    val total: Int = 0,
    val pending: Int = 0,
    val syncing: Int = 0,
    val synced: Int = 0,
    val failed: Int = 0,
    val conflict: Int = 0
) {
    companion object {
        fun from(items: List<SyncQueueEntity>): SyncQueueUiSummary = SyncQueueUiSummary(
            total = items.size,
            pending = items.count { it.status == SyncStatus.PENDING },
            syncing = items.count { it.status == SyncStatus.SYNCING },
            synced = items.count { it.status == SyncStatus.SYNCED },
            failed = items.count { it.status == SyncStatus.FAILED },
            conflict = items.count { it.status == SyncStatus.CONFLICT }
        )
    }
}
