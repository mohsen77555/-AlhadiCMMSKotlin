package com.alhadi.cmms.ui.auth

enum class AuthScreen {
    SPLASH,
    LOGIN,
    LOADING_PERMISSIONS,
    PERMISSION_ERROR,
    ROLE_READY,
    ROLE_HOME
}
