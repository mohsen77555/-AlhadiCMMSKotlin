package com.alhadi.cmms.database.converter

import androidx.room.TypeConverter
import com.alhadi.cmms.core.model.AuditAction
import com.alhadi.cmms.core.model.InventoryRequestType
import com.alhadi.cmms.core.model.InventoryRequestStatus
import com.alhadi.cmms.core.model.StockTransactionType
import com.alhadi.cmms.core.model.SyncOperationType
import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.core.model.WorkOrderStatus
import com.alhadi.cmms.core.model.WorkRequestStatus

class RoomConverters {
    @TypeConverter
    fun userRoleToString(value: UserRole?): String? = value?.name

    @TypeConverter
    fun stringToUserRole(value: String?): UserRole? = value?.let(UserRole::valueOf)

    @TypeConverter
    fun workOrderStatusToString(value: WorkOrderStatus?): String? = value?.name

    @TypeConverter
    fun stringToWorkOrderStatus(value: String?): WorkOrderStatus? = value?.let(WorkOrderStatus::valueOf)

    @TypeConverter
    fun workRequestStatusToString(value: WorkRequestStatus?): String? = value?.name

    @TypeConverter
    fun stringToWorkRequestStatus(value: String?): WorkRequestStatus? = value?.let(WorkRequestStatus::valueOf)

    @TypeConverter
    fun stockTransactionTypeToString(value: StockTransactionType?): String? = value?.name

    @TypeConverter
    fun stringToStockTransactionType(value: String?): StockTransactionType? = value?.let(StockTransactionType::valueOf)

    @TypeConverter
    fun syncStatusToString(value: SyncStatus?): String? = value?.name

    @TypeConverter
    fun stringToSyncStatus(value: String?): SyncStatus? = value?.let(SyncStatus::valueOf)

    @TypeConverter
    fun syncOperationTypeToString(value: SyncOperationType?): String? = value?.name

    @TypeConverter
    fun stringToSyncOperationType(value: String?): SyncOperationType? = value?.let(SyncOperationType::valueOf)


    @TypeConverter
    fun inventoryRequestStatusToString(value: InventoryRequestStatus?): String? = value?.name

    @TypeConverter
    fun stringToInventoryRequestStatus(value: String?): InventoryRequestStatus? = value?.let(InventoryRequestStatus::valueOf)

    @TypeConverter
    fun inventoryRequestTypeToString(value: InventoryRequestType?): String? = value?.name

    @TypeConverter
    fun stringToInventoryRequestType(value: String?): InventoryRequestType? = value?.let(InventoryRequestType::valueOf)

    @TypeConverter
    fun auditActionToString(value: AuditAction?): String? = value?.name

    @TypeConverter
    fun stringToAuditAction(value: String?): AuditAction? = value?.let(AuditAction::valueOf)
}
