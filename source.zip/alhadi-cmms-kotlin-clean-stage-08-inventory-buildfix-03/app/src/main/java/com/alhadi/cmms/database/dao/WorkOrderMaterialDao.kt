package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.alhadi.cmms.database.entity.WorkOrderMaterialEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkOrderMaterialDao {
    @Upsert
    suspend fun upsert(material: WorkOrderMaterialEntity)

    @Query("SELECT * FROM work_order_materials WHERE id = :id AND isDeleted = 0 LIMIT 1")
    suspend fun getById(id: String): WorkOrderMaterialEntity?

    @Query("SELECT * FROM work_order_materials WHERE companyId = :companyId AND isDeleted = 0 ORDER BY updatedAt DESC")
    fun observeForCompany(companyId: String): Flow<List<WorkOrderMaterialEntity>>

    @Query("SELECT * FROM work_order_materials WHERE workOrderId = :workOrderId AND isDeleted = 0 ORDER BY updatedAt DESC")
    fun observeForWorkOrder(workOrderId: String): Flow<List<WorkOrderMaterialEntity>>

    @Query("UPDATE work_order_materials SET issuedQuantity = issuedQuantity + :issuedQuantity, updatedAt = :updatedAt, updatedBy = :updatedBy, syncVersion = syncVersion + 1 WHERE id = :id")
    suspend fun addIssuedQuantity(id: String, issuedQuantity: Double, updatedAt: Long, updatedBy: String)
}
