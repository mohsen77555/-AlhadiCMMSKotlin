package com.alhadi.cmms.core.model

enum class SyncStatus {
    LOCAL_ONLY,
    PENDING,
    SYNCING,
    SYNCED,
    FAILED,
    CONFLICT
}

fun SyncStatus.arabicLabel(): String = when (this) {
    SyncStatus.LOCAL_ONLY -> "محفوظ محليًا"
    SyncStatus.PENDING -> "بانتظار المزامنة"
    SyncStatus.SYNCING -> "جارٍ المزامنة"
    SyncStatus.SYNCED -> "تمت المزامنة"
    SyncStatus.FAILED -> "فشل الإرسال"
    SyncStatus.CONFLICT -> "تعارض يحتاج مراجعة"
}
