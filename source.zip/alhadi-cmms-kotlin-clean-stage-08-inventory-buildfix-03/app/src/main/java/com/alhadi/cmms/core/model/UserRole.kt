package com.alhadi.cmms.core.model

enum class UserRole {
    ADMIN,
    MAINTENANCE_MANAGER,
    SUPERVISOR,
    TECHNICIAN,
    WAREHOUSE,
    REQUESTER,
    VIEWER
}

fun UserRole.arabicLabel(): String = when (this) {
    UserRole.ADMIN -> "مدير النظام"
    UserRole.MAINTENANCE_MANAGER -> "مدير الصيانة"
    UserRole.SUPERVISOR -> "مشرف"
    UserRole.TECHNICIAN -> "فني"
    UserRole.WAREHOUSE -> "المخزن"
    UserRole.REQUESTER -> "طالب خدمة"
    UserRole.VIEWER -> "مشاهدة فقط"
}
