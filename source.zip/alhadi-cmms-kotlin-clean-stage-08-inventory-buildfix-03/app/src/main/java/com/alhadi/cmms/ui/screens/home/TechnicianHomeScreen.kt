package com.alhadi.cmms.ui.screens.home

import androidx.compose.runtime.Composable
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.ui.navigation.allowedHomeMenus
import com.alhadi.cmms.ui.navigation.stage04PolicyNotesAr

@Composable
fun TechnicianHomeScreen(
    profile: UserEntity,
    onSignOut: () -> Unit
) {
    RoleHomeScaffold(
        profile = profile,
        screenTitleAr = "واجهة الفني",
        welcomeAr = "مرحبًا، هذه واجهة الفني ولا تحتوي على تبويب المزيد أو إدارة المخزون.",
        allowedMenus = UserRole.TECHNICIAN.allowedHomeMenus(),
        policyNotes = UserRole.TECHNICIAN.stage04PolicyNotesAr(),
        onSignOut = onSignOut
    )
}
