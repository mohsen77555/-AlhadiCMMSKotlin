package com.alhadi.cmms.core.auth

class MissingSignedInUserException : IllegalStateException(
    "No Firebase authenticated user is available."
)

class MissingUserProfileException(
    val uid: String
) : IllegalStateException(
    "No permissions profile exists for Firebase user $uid."
)

class InactiveUserException(
    val uid: String
) : IllegalStateException(
    "User profile $uid is inactive."
)

class InvalidUserRoleException(
    val rawRole: String?
) : IllegalStateException(
    "Unsupported user role: $rawRole"
)
