package com.alhadi.cmms.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.core.model.arabicLabel
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.ui.navigation.RoleMenuItem
import com.alhadi.cmms.ui.inventory.InventoryModernScreen
import com.alhadi.cmms.ui.workorders.WorkOrderModernScreen

private val ModernBackground = Color(0xFFF5F6FA)
private val ModernSurface = Color.White
private val ModernText = Color(0xFF111827)
private val MutedText = Color(0xFF6B7280)
private val DeepNavy = Color(0xFF111827)
private val BrandBlue = Color(0xFF2563EB)
private val BrandOrange = Color(0xFFF97316)
private val BrandGreen = Color(0xFF16A34A)
private val BrandPurple = Color(0xFF7C3AED)
private val SoftGreen = Color(0xFFEAFBF1)
private val SoftBlue = Color(0xFFEAF1FF)
private val SoftOrange = Color(0xFFFFF1E8)
private val SoftPurple = Color(0xFFF3EAFE)
private val CardStroke = Color(0xFFE6EAF2)

@Composable
fun RoleHomeScaffold(
    profile: UserEntity,
    screenTitleAr: String,
    welcomeAr: String,
    allowedMenus: List<RoleMenuItem>,
    policyNotes: List<String>,
    onSignOut: () -> Unit
) {
    val dashboardId = allowedMenus.firstOrNull { it.id.contains("dashboard") }?.id
        ?: allowedMenus.firstOrNull()?.id.orEmpty()
    var selectedMenuId by rememberSaveable(allowedMenus.joinToString("|") { it.id }) {
        mutableStateOf(dashboardId)
    }
    var actionMessage by rememberSaveable { mutableStateOf<String?>(null) }
    val selectedMenu = allowedMenus.firstOrNull { it.id == selectedMenuId } ?: allowedMenus.firstOrNull()
    val navItems = bottomNavigationItems(profile.role, allowedMenus, dashboardId)

    Surface(modifier = Modifier.fillMaxSize(), color = ModernBackground) {
        Box(modifier = Modifier.fillMaxSize()) {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 110.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                item {
                    ModernTopBar(
                        profile = profile,
                        selectedMenu = selectedMenu,
                        appTitle = "Alhadi CMMS",
                        onSignOut = onSignOut
                    )
                }
                item {
                    TopMetricStrip(
                        profile = profile,
                        selectedMenu = selectedMenu,
                        menuCount = allowedMenus.size
                    )
                }
                item {
                    QuickActionChips(
                        profile = profile,
                        allowedMenus = allowedMenus,
                        onSelect = { id ->
                            selectedMenuId = id
                            actionMessage = null
                        }
                    )
                }
                actionMessage?.let { message ->
                    item { InlineFeedback(message = message, onDismiss = { actionMessage = null }) }
                }
                item {
                    if (selectedMenu == null || selectedMenu.id == dashboardId) {
                        DashboardContent(
                            profile = profile,
                            allowedMenus = allowedMenus,
                            onSelect = { id ->
                                selectedMenuId = id
                                actionMessage = null
                            }
                        )
                    } else if (selectedMenu.id.isWorkOrderMenu()) {
                        WorkOrderModernScreen(profile = profile, menu = selectedMenu)
                    } else {
                        ModernModuleContent(
                            profile = profile,
                            menu = selectedMenu,
                            allowedMenus = allowedMenus,
                            onSelect = { id ->
                                selectedMenuId = id
                                actionMessage = null
                            },
                            onPrimaryAction = {
                                actionMessage = moduleActionMessage(selectedMenu.id)
                            }
                        )
                    }
                }
            }

            FloatingBottomNavigation(
                items = navItems,
                selectedId = selectedMenuId,
                onSelect = { id ->
                    selectedMenuId = id
                    actionMessage = null
                },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }
    }
}

@Composable
private fun ModernTopBar(
    profile: UserEntity,
    selectedMenu: RoleMenuItem?,
    appTitle: String,
    onSignOut: () -> Unit
) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusPill(text = "Production", color = BrandGreen, textColor = Color.White)
            Text(
                text = "الأدوار من Firebase",
                style = MaterialTheme.typography.labelMedium,
                color = MutedText,
                fontWeight = FontWeight.Medium
            )
            TextButton(onClick = onSignOut, contentPadding = PaddingValues(0.dp)) {
                Text("تسجيل الخروج", color = MutedText, style = MaterialTheme.typography.labelMedium)
            }
        }
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = appTitle,
                    style = MaterialTheme.typography.labelLarge,
                    color = MutedText,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = selectedMenu?.titleAr ?: "الرئيسية",
                    style = MaterialTheme.typography.headlineLarge,
                    color = ModernText,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = selectedMenu?.subtitleAr ?: profile.role.arabicLabel(),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(60.dp)
                    .shadow(10.dp, RoundedCornerShape(20.dp), clip = false)
                    .clip(RoundedCornerShape(20.dp))
                    .background(sectionGradient(selectedMenu?.id ?: "home"))
            ) {
                Text(
                    text = selectedMenu?.modernIcon() ?: "⌂",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun TopMetricStrip(profile: UserEntity, selectedMenu: RoleMenuItem?, menuCount: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        SyncStatusCard(modifier = Modifier.weight(1.25f))
        MiniMetricCard(title = "أصل", value = "0", color = BrandGreen, modifier = Modifier.weight(0.8f))
        MiniMetricCard(title = "أمر مفتوح", value = "0", color = BrandBlue, modifier = Modifier.weight(0.8f))
    }
}

@Composable
private fun SyncStatusCard(modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = SoftGreen),
        modifier = modifier.height(82.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp)
        ) {
            Text("حالة المزامنة", color = BrandGreen, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.ExtraBold)
            Text("محلي أولًا", color = Color(0xFF15803D), style = MaterialTheme.typography.bodySmall, maxLines = 1)
            LinearProgressIndicator(
                progress = { 1f },
                color = BrandGreen,
                trackColor = Color.White,
                modifier = Modifier
                    .padding(top = 6.dp)
                    .fillMaxWidth()
                    .height(5.dp)
                    .clip(RoundedCornerShape(99.dp))
            )
        }
    }
}

@Composable
private fun MiniMetricCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = ModernSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = modifier.height(82.dp)
    ) {
        Column(
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize().padding(8.dp)
        ) {
            Text(value, color = color, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
            Text(title, color = MutedText, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun QuickActionChips(profile: UserEntity, allowedMenus: List<RoleMenuItem>, onSelect: (String) -> Unit) {
    val chips = when (profile.role) {
        UserRole.ADMIN -> listOf(
            QuickChip("التنبيهات", "🔔", "reports"),
            QuickChip("إدارة الصيانة", "⚙", "work_orders"),
            QuickChip("محرك الجدولة", "◷", "work_requests")
        )
        UserRole.TECHNICIAN -> listOf(
            QuickChip("أوامري", "▣", "my_orders"),
            QuickChip("طلبات المواد", "▤", "material_requests"),
            QuickChip("سجل العمل", "◷", "work_log")
        )
        UserRole.WAREHOUSE -> listOf(
            QuickChip("طلبات الصرف", "▤", "issue_requests"),
            QuickChip("الحركات", "↕", "stock_transactions"),
            QuickChip("الأصناف", "▦", "items")
        )
        else -> listOf(
            QuickChip("التنبيهات", "🔔", allowedMenus.getOrNull(0)?.id.orEmpty()),
            QuickChip("الحساب", "●", allowedMenus.lastOrNull()?.id.orEmpty())
        )
    }.filter { chip -> allowedMenus.any { it.id == chip.targetId } }

    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(chips, key = { it.label }) { chip ->
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = ModernSurface,
                shadowElevation = 3.dp,
                modifier = Modifier.clickable { onSelect(chip.targetId) }
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp)
                ) {
                    Text(chip.icon, style = MaterialTheme.typography.titleMedium)
                    Text(chip.label, color = ModernText, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun DashboardContent(profile: UserEntity, allowedMenus: List<RoleMenuItem>, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(18.dp), modifier = Modifier.fillMaxWidth()) {
        SectionHeader(title = dashboardSectionTitle(profile.role), accent = BrandOrange)
        MetricGrid(profile.role)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            BigActionButton(
                title = "التقارير",
                color = BrandBlue,
                targetId = allowedMenus.firstOrNull { it.id.contains("reports") }?.id,
                onSelect = onSelect,
                modifier = Modifier.weight(1f)
            )
            BigActionButton(
                title = "حوكمة 100%",
                color = DeepNavy,
                targetId = allowedMenus.firstOrNull { it.id == "settings" || it.id == "account" }?.id,
                onSelect = onSelect,
                modifier = Modifier.weight(1f)
            )
        }
        NeedAttentionCard()
        ModuleGrid(
            items = dashboardModules(profile.role, allowedMenus),
            onSelect = onSelect
        )
    }
}

@Composable
private fun MetricGrid(role: UserRole) {
    val metrics = when (role) {
        UserRole.ADMIN -> listOf(
            DisplayMetric("أوامر مفتوحة", "0", BrandBlue),
            DisplayMetric("متأخرة", "0", Color(0xFF64748B)),
            DisplayMetric("CAPA", "0", Color(0xFFB45309)),
            DisplayMetric("أصول حرجة", "0", Color(0xFFDC2626)),
            DisplayMetric("طارئ", "0", Color(0xFFDC2626)),
            DisplayMetric("متأخر", "0", Color(0xFF64748B)),
            DisplayMetric("بانتظار المراجعة", "0", Color(0xFF64748B)),
            DisplayMetric("مفتوح", "0", Color(0xFF64748B))
        )
        UserRole.TECHNICIAN -> listOf(
            DisplayMetric("أوامري", "0", BrandBlue),
            DisplayMetric("قيد التنفيذ", "0", BrandGreen),
            DisplayMetric("مواد مطلوبة", "0", BrandOrange),
            DisplayMetric("مكتمل اليوم", "0", BrandPurple)
        )
        UserRole.WAREHOUSE -> listOf(
            DisplayMetric("طلبات صرف", "0", BrandOrange),
            DisplayMetric("Low Stock", "0", Color(0xFFDC2626)),
            DisplayMetric("حركات اليوم", "0", BrandBlue),
            DisplayMetric("أصناف", "0", BrandGreen)
        )
        else -> listOf(
            DisplayMetric("مفتوح", "0", BrandBlue),
            DisplayMetric("بانتظار", "0", BrandOrange),
            DisplayMetric("منجز", "0", BrandGreen),
            DisplayMetric("تنبيهات", "0", Color(0xFFDC2626))
        )
    }
    TwoColumnGrid(metrics) { metric, modifier ->
        ModernMetricCard(metric = metric, modifier = modifier)
    }
}

@Composable
private fun ModernMetricCard(metric: DisplayMetric, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = ModernSurface),
        modifier = modifier.height(116.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxSize().padding(10.dp)
        ) {
            Text(metric.value, color = metric.color, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
            Text(metric.title, color = Color(0xFF64748B), style = MaterialTheme.typography.titleSmall, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun NeedAttentionCard() {
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = ModernSurface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(18.dp)) {
            SectionHeader(title = "يحتاج انتباهك", accent = BrandOrange)
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(86.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFFF8FAFC))
            ) {
                Text("لا شيء عاجل، كل شيء تحت السيطرة.", color = MutedText, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
private fun ModernModuleContent(
    profile: UserEntity,
    menu: RoleMenuItem,
    allowedMenus: List<RoleMenuItem>,
    onSelect: (String) -> Unit,
    onPrimaryAction: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
        when {
            menu.id.contains("assets") -> AssetsModule(onPrimaryAction = onPrimaryAction)
            menu.id.contains("inventory") || menu.id.contains("stock") || menu.id == "items" || menu.id.contains("material") || menu.id == "issue_requests" -> InventoryModernScreen(profile = profile, menu = menu)
            menu.id.contains("reports") -> ReportsModule(onPrimaryAction = onPrimaryAction)
            menu.id == "more" -> MoreModule(allowedMenus = allowedMenus, onSelect = onSelect)
            menu.id == "users" -> UsersModule(onPrimaryAction = onPrimaryAction)
            menu.id == "settings" -> SettingsModule(onPrimaryAction = onPrimaryAction)
            menu.id == "account" -> AccountModule(profile = profile, onPrimaryAction = onPrimaryAction)
            else -> GenericModule(menu = menu, onPrimaryAction = onPrimaryAction)
        }
    }
}

@Composable
private fun AssetsModule(onPrimaryAction: () -> Unit) {
    ScanCard(onAction = onPrimaryAction)
    SearchBar(label = "بحث ذكي: اكتب كلمة أو عبارة")
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(listOf("الكل", "أصول مؤسسة", "أصول عملاء", "أوامر مرتبطة")) { filter ->
            FilterPill(text = filter, selected = filter == "الكل")
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        ActionButton(text = "+ تسجيل أصل", color = BrandOrange, modifier = Modifier.weight(1f), onClick = onPrimaryAction)
        ActionButton(text = "ملصقات QR", color = BrandGreen, modifier = Modifier.weight(1f), onClick = onPrimaryAction)
        ActionButton(text = "CSV", color = BrandBlue, modifier = Modifier.weight(0.7f), onClick = onPrimaryAction)
    }
    EmptyStateCard(title = "لا توجد أصول بعد", subtitle = "ستظهر الأصول هنا بعد إضافتها أو مزامنتها من Room.")
}

@Composable
private fun ScanCard(onAction: () -> Unit) {
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface)) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(18.dp)) {
            SectionHeader(title = "QR / Barcode للأصول", accent = BrandGreen)
            Text("امسح ملصق الأصل أو أدخل رقم الأصل للوصول إلى Asset 360.", color = MutedText)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                ActionButton(text = "مسح", color = DeepNavy, modifier = Modifier.weight(0.9f), onClick = onAction)
                ActionButton(text = "فتح", color = BrandGreen, modifier = Modifier.weight(0.9f), onClick = onAction)
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color(0xFFF8FAFC),
                    modifier = Modifier.weight(1.8f).height(56.dp)
                ) { Box(contentAlignment = Alignment.Center) { Text("LA-01 / CC-01 / Serial", color = MutedText) } }
            }
        }
    }
}

@Composable
private fun InventoryModule(menu: RoleMenuItem, onPrimaryAction: () -> Unit) {
    SearchBar(label = "بحث عن صنف أو رقم قطعة")
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(listOf("الكل", "Low Stock", "طلبات صرف", "حركات")) { filter -> FilterPill(filter, filter == "الكل") }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        ActionButton(text = "طلب صرف", color = BrandOrange, modifier = Modifier.weight(1f), onClick = onPrimaryAction)
        ActionButton(text = "حركة مخزون", color = BrandBlue, modifier = Modifier.weight(1f), onClick = onPrimaryAction)
    }
    ModuleGrid(
        items = listOf(
            ModuleTile("الأصناف", "Item Master وقطع الغيار", "▦", BrandBlue, menu.id),
            ModuleTile("الأرصدة", "الرصيد ينتج من الحركات فقط", "▤", BrandGreen, menu.id),
            ModuleTile("طلبات الصرف", "الفني يطلب والمخزن يعتمد", "↗", BrandOrange, menu.id),
            ModuleTile("الحركات", "لا حذف للحركات المعتمدة", "↕", BrandPurple, menu.id)
        ),
        onSelect = { onPrimaryAction() }
    )
}

@Composable
private fun ReportsModule(onPrimaryAction: () -> Unit) {
    SectionHeader(title = "مؤشرات وتحليلات", accent = BrandPurple)
    ModuleGrid(
        items = listOf(
            ModuleTile("أوامر حسب الحالة", "مفتوح، متأخر، مغلق", "◌", BrandBlue, "reports"),
            ModuleTile("استهلاك المواد", "حسب الأصل وأمر العمل", "▤", BrandGreen, "reports"),
            ModuleTile("تحليل الأعطال", "MTTR و MTBF", "△", Color(0xFFDC2626), "reports"),
            ModuleTile("المخزون", "Low Stock وDead Stock", "▦", BrandOrange, "reports")
        ),
        onSelect = { onPrimaryAction() }
    )
}

@Composable
private fun MoreModule(allowedMenus: List<RoleMenuItem>, onSelect: (String) -> Unit) {
    ModuleGrid(
        items = listOf(
            ModuleTile("سجل الأصول و360", "عرض تاريخ الأصل الكامل", "▣", BrandGreen, "assets"),
            ModuleTile("QR للأصول", "توليد وطباعة ملصقات", "▥", BrandGreen, "assets"),
            ModuleTile("مجموعات الأصول", "تجميع وقواعد تحقق", "▤", BrandPurple, "assets"),
            ModuleTile("العدادات", "قراءات وتشغيل واستهلاك", "◷", BrandPurple, "assets"),
            ModuleTile("الضمانات", "عقود ومطالبات", "★", BrandGreen, "assets"),
            ModuleTile("الهرميات والمسارات", "هياكل ومسارات منطقية", "◇", BrandBlue, "assets"),
            ModuleTile("التقارير", "مؤشرات وتصدير وتحليلات", "◌", BrandPurple, "reports"),
            ModuleTile("البيانات والنسخ", "تصدير واستيراد ونسخ احتياطي", "⇩", Color(0xFF64748B), "settings"),
            ModuleTile("تحليل الأعطال", "أعطال متكررة وMTTR", "△", Color(0xFFDC2626), "reports"),
            ModuleTile("المستخدمون", "أدوار وصلاحيات", "●", BrandOrange, "users")
        ).filter { tile -> allowedMenus.any { it.id == tile.targetId } },
        onSelect = onSelect
    )
}

@Composable
private fun UsersModule(onPrimaryAction: () -> Unit) {
    ModuleHero(title = "المستخدمون والصلاحيات", subtitle = "إدارة الأدوار دون عرض شاشات غير مسموحة.", icon = "●", color = BrandOrange)
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        ActionButton(text = "+ مستخدم", color = BrandOrange, modifier = Modifier.weight(1f), onClick = onPrimaryAction)
        ActionButton(text = "الأدوار", color = DeepNavy, modifier = Modifier.weight(1f), onClick = onPrimaryAction)
    }
    EmptyStateCard(title = "لا توجد قائمة مستخدمين محلية بعد", subtitle = "هذه الشاشة ستقرأ من Room وتبقى محمية بقواعد Firestore.")
}

@Composable
private fun SettingsModule(onPrimaryAction: () -> Unit) {
    ModuleHero(title = "الإعدادات", subtitle = "إعدادات الشركة والتطبيق والجهاز والمزامنة.", icon = "⚙", color = DeepNavy)
    ModuleGrid(
        items = listOf(
            ModuleTile("الشركة", "الاسم والفروع والمواقع", "▣", BrandBlue, "settings"),
            ModuleTile("التزامن", "آخر مزامنة وحالة الطابور", "↻", BrandGreen, "settings"),
            ModuleTile("اللغة والمظهر", "عربي وواجهة RTL", "◐", BrandPurple, "settings"),
            ModuleTile("الأمان", "أدوار وقواعد Firestore", "◉", BrandOrange, "settings")
        ),
        onSelect = { onPrimaryAction() }
    )
}

@Composable
private fun AccountModule(profile: UserEntity, onPrimaryAction: () -> Unit) {
    ModuleHero(title = "حسابي", subtitle = profile.email, icon = "●", color = BrandBlue)
    DetailLine("الاسم", profile.displayName)
    DetailLine("الدور", profile.role.arabicLabel())
    DetailLine("الشركة", profile.companyId)
    ActionButton(text = "تحديث بيانات الحساب", color = BrandBlue, modifier = Modifier.fillMaxWidth(), onClick = onPrimaryAction)
}

@Composable
private fun GenericModule(menu: RoleMenuItem, onPrimaryAction: () -> Unit) {
    ModuleHero(title = menu.titleAr, subtitle = menu.subtitleAr, icon = menu.modernIcon(), color = colorForMenu(menu.id))
    EmptyStateCard(title = "لا توجد بيانات حتى الآن", subtitle = "عند توفر بيانات محلية من Room ستظهر هنا مباشرة.")
    ActionButton(text = "فتح التفاصيل", color = colorForMenu(menu.id), modifier = Modifier.fillMaxWidth(), onClick = onPrimaryAction)
}

@Composable
private fun ModuleHero(title: String, subtitle: String, icon: String, color: Color) {
    Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface)) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(18.dp)
        ) {
            Box(contentAlignment = Alignment.Center, modifier = Modifier.size(58.dp).clip(RoundedCornerShape(18.dp)).background(color)) {
                Text(icon, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = ModernText, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                Text(subtitle, color = MutedText, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun SearchBar(label: String) {
    Surface(shape = RoundedCornerShape(24.dp), color = ModernSurface, shadowElevation = 2.dp, modifier = Modifier.fillMaxWidth().height(62.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(horizontal = 18.dp)) {
            Text("🔍", style = MaterialTheme.typography.titleLarge)
            Text(label, color = Color(0xFF94A3B8), style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
private fun FilterPill(text: String, selected: Boolean) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (selected) DeepNavy else ModernSurface,
        shadowElevation = if (selected) 5.dp else 1.dp
    ) {
        Text(
            text = text,
            color = if (selected) Color.White else ModernText,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
        )
    }
}

@Composable
private fun ActionButton(text: String, color: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White),
        shape = RoundedCornerShape(18.dp),
        modifier = modifier.height(56.dp)
    ) { Text(text, fontWeight = FontWeight.ExtraBold) }
}

@Composable
private fun BigActionButton(title: String, color: Color, targetId: String?, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = { targetId?.let(onSelect) },
        enabled = targetId != null,
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White),
        shape = RoundedCornerShape(22.dp),
        modifier = modifier.height(58.dp)
    ) { Text(title, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium) }
}

@Composable
private fun EmptyStateCard(title: String, subtitle: String) {
    Card(shape = RoundedCornerShape(26.dp), colors = CardDefaults.cardColors(containerColor = ModernSurface), modifier = Modifier.fillMaxWidth()) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(22.dp)) {
            Text("○", color = Color(0xFFCBD5E1), style = MaterialTheme.typography.headlineMedium)
            Text(title, color = ModernText, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(subtitle, color = MutedText, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun ModuleGrid(items: List<ModuleTile>, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items.chunked(2).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                rowItems.forEach { item ->
                    ModuleTileCard(item = item, onSelect = onSelect, modifier = Modifier.weight(1f))
                }
                if (rowItems.size == 1) Spacer(modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ModuleTileCard(item: ModuleTile, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = ModernSurface),
        modifier = modifier
            .height(172.dp)
            .clickable { onSelect(item.targetId) }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Box(modifier = Modifier.align(Alignment.CenterEnd).width(6.dp).height(120.dp).clip(RoundedCornerShape(99.dp)).background(item.color))
            Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize().padding(16.dp)) {
                Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top, modifier = Modifier.fillMaxWidth()) {
                    Text("›", color = Color(0xFF94A3B8), style = MaterialTheme.typography.titleLarge)
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(item.color)) {
                        Text(item.icon, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(item.title, color = ModernText, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(item.subtitle, color = MutedText, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Surface(shape = RoundedCornerShape(18.dp), color = ModernSurface, modifier = Modifier.fillMaxWidth()) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.padding(16.dp)) {
            Text(label, color = MutedText, fontWeight = FontWeight.SemiBold)
            Text(value.ifBlank { "غير محدد" }, color = ModernText, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SectionHeader(title: String, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(modifier = Modifier.size(7.dp).clip(CircleShape).background(accent))
        Text(title, color = ModernText, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
private fun FloatingBottomNavigation(
    items: List<RoleMenuItem>,
    selectedId: String,
    onSelect: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(30.dp),
        color = ModernSurface,
        shadowElevation = 14.dp,
        modifier = modifier
            .padding(horizontal = 14.dp, vertical = 12.dp)
            .navigationBarsPadding()
            .fillMaxWidth()
    ) {
        Row(horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
            items.forEach { item ->
                val selected = item.id == selectedId || (selectedId.contains("dashboard") && item.id.contains("dashboard"))
                BottomNavItem(item = item, selected = selected, onClick = { onSelect(item.id) })
            }
        }
    }
}

@Composable
private fun BottomNavItem(item: RoleMenuItem, selected: Boolean, onClick: () -> Unit) {
    val color = colorForMenu(item.id)
    val background = if (selected) color else Color.Transparent
    val content = if (selected) Color.White else Color(0xFF64748B)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(22.dp))
            .background(background)
            .clickable(onClick = onClick)
            .padding(horizontal = 11.dp, vertical = 10.dp)
    ) {
        Text(item.modernIcon(), color = content, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text(item.shortTitle(), color = content, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun InlineFeedback(message: String, onDismiss: () -> Unit) {
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = SoftBlue)) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            Text(message, color = Color(0xFF1E3A8A), modifier = Modifier.weight(1f))
            TextButton(onClick = onDismiss) { Text("إخفاء") }
        }
    }
}

@Composable
private fun TwoColumnGrid(items: List<DisplayMetric>, content: @Composable (DisplayMetric, Modifier) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items.chunked(4).forEach { rowItems ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                rowItems.forEach { item -> content(item, Modifier.weight(1f)) }
                repeat(4 - rowItems.size) { Spacer(modifier = Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun StatusPill(text: String, color: Color, textColor: Color) {
    Surface(shape = RoundedCornerShape(999.dp), color = color) {
        Text(text, color = textColor, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
    }
}

private data class QuickChip(val label: String, val icon: String, val targetId: String)
private data class DisplayMetric(val title: String, val value: String, val color: Color)
private data class ModuleTile(val title: String, val subtitle: String, val icon: String, val color: Color, val targetId: String)

private fun dashboardSectionTitle(role: UserRole): String = when (role) {
    UserRole.ADMIN -> "واجهة الإدارة السريعة"
    UserRole.TECHNICIAN -> "واجهة الفني السريعة"
    UserRole.WAREHOUSE -> "واجهة المخزن السريعة"
    UserRole.REQUESTER -> "طلبات الخدمة"
    else -> "لوحة التشغيل السريعة"
}

private fun dashboardModules(role: UserRole, allowedMenus: List<RoleMenuItem>): List<ModuleTile> {
    val menus = allowedMenus.associateBy { it.id }
    return when (role) {
        UserRole.ADMIN -> listOfNotNull(
            menus["work_orders"]?.toModuleTile(BrandBlue),
            menus["assets"]?.toModuleTile(BrandGreen),
            menus["inventory"]?.toModuleTile(BrandOrange),
            menus["reports"]?.toModuleTile(BrandPurple),
            menus["users"]?.toModuleTile(BrandOrange),
            menus["settings"]?.toModuleTile(DeepNavy),
            menus["more"]?.toModuleTile(Color(0xFF92400E))
        )
        else -> allowedMenus.take(6).map { it.toModuleTile(colorForMenu(it.id)) }
    }
}

private fun RoleMenuItem.toModuleTile(color: Color): ModuleTile = ModuleTile(titleAr, subtitleAr, modernIcon(), color, id)

private fun bottomNavigationItems(role: UserRole, allowedMenus: List<RoleMenuItem>, dashboardId: String): List<RoleMenuItem> {
    fun first(vararg ids: String): RoleMenuItem? = ids.firstNotNullOfOrNull { id -> allowedMenus.firstOrNull { it.id == id } }
    return when (role) {
        UserRole.ADMIN -> listOfNotNull(
            first(dashboardId), first("work_orders"), first("work_requests"), first("assets"), first("more")
        )
        UserRole.TECHNICIAN -> listOfNotNull(
            first("my_orders"), first("in_progress"), first("material_requests"), first("work_log"), first("account")
        )
        UserRole.WAREHOUSE -> listOfNotNull(
            first("inventory"), first("issue_requests"), first("stock_transactions"), first("items"), first("warehouse_reports")
        )
        UserRole.REQUESTER -> allowedMenus.take(4)
        else -> listOfNotNull(first(dashboardId)) + allowedMenus.filterNot { it.id == dashboardId }.take(4)
    }.distinctBy { it.id }.take(5)
}

private fun RoleMenuItem.shortTitle(): String = when {
    id.contains("dashboard") -> "الرئيسية"
    id == "work_orders" || id == "my_orders" -> "أوامر"
    id == "work_requests" || id == "my_requests" -> "طلبات"
    id.contains("assets") -> "الأصول"
    id.contains("inventory") -> "المخزون"
    id.contains("reports") -> "تقارير"
    id == "users" -> "مستخدمون"
    id == "settings" -> "إعدادات"
    id == "more" -> "المزيد"
    id == "account" -> "حسابي"
    else -> titleAr.take(8)
}

private fun RoleMenuItem.modernIcon(): String = when (id) {
    "admin_dashboard", "maintenance_dashboard", "supervisor_dashboard", "viewer_dashboard" -> "⌂"
    "work_orders", "my_orders", "in_progress", "work_log", "work_orders_readonly" -> "▣"
    "work_requests", "new_request", "my_requests" -> "◇"
    "assets", "assets_readonly" -> "▤"
    "inventory", "issue_requests", "stock_transactions", "items", "material_requests" -> "▦"
    "reports", "reports_limited", "warehouse_reports", "reports_readonly" -> "◌"
    "users", "technicians" -> "●"
    "settings" -> "⚙"
    "pm" -> "↻"
    "notifications" -> "🔔"
    "account" -> "●"
    "more" -> "☰"
    else -> "◆"
}

private fun colorForMenu(id: String): Color = when {
    id.contains("dashboard") -> DeepNavy
    id.contains("work") || id == "my_orders" || id == "in_progress" -> BrandBlue
    id.contains("assets") -> BrandGreen
    id.contains("inventory") || id.contains("stock") || id == "items" || id.contains("material") -> BrandOrange
    id.contains("reports") -> BrandPurple
    id == "users" || id == "technicians" -> BrandOrange
    id == "settings" -> DeepNavy
    id == "more" -> Color(0xFF92400E)
    id == "account" -> BrandBlue
    else -> BrandBlue
}

private fun sectionGradient(id: String): Brush = Brush.linearGradient(
    colors = when {
        id.contains("assets") -> listOf(BrandGreen, Color(0xFF047857))
        id.contains("work") || id == "my_orders" -> listOf(BrandBlue, Color(0xFF1E40AF))
        id.contains("inventory") || id.contains("stock") -> listOf(BrandOrange, Color(0xFFC2410C))
        id.contains("reports") -> listOf(BrandPurple, Color(0xFF5B21B6))
        id == "more" -> listOf(Color(0xFF92400E), Color(0xFF7C2D12))
        else -> listOf(DeepNavy, Color(0xFF1F2937))
    }
)

private fun String.isWorkOrderMenu(): Boolean = this in setOf(
    "work_orders",
    "my_orders",
    "in_progress",
    "work_log",
    "work_orders_readonly"
)

private fun moduleActionMessage(id: String): String = when {
    id.contains("assets") -> "تم فتح إجراءات الأصول. ستقرأ البيانات من Room وتظهر هنا مباشرة عند توفرها."
    id.contains("inventory") || id.contains("stock") || id == "items" -> "تم فتح إجراءات المخزون. الرصيد سيبقى ناتجًا عن الحركات فقط."
    id.contains("reports") -> "تم فتح مؤشرات التقارير. سيتم تغذيتها من Room بعد اكتمال مراحل التقارير."
    id == "users" -> "تم فتح إدارة المستخدمين. الصلاحيات تعتمد على role وقواعد Firestore."
    else -> "تم فتح الإجراء بنجاح."
}
