package com.alhadi.cmms.core.model

enum class WorkOrderStatus {
    DRAFT,
    REQUESTED,
    APPROVED,
    PLANNED,
    ASSIGNED,
    IN_PROGRESS,
    WAITING_MATERIAL,
    WAITING_APPROVAL,
    COMPLETED_BY_TECHNICIAN,
    CLOSED,
    CANCELLED
}

fun WorkOrderStatus.arabicLabel(): String = when (this) {
    WorkOrderStatus.DRAFT -> "مسودة"
    WorkOrderStatus.REQUESTED -> "مطلوب"
    WorkOrderStatus.APPROVED -> "معتمد"
    WorkOrderStatus.PLANNED -> "مخطط"
    WorkOrderStatus.ASSIGNED -> "مسند"
    WorkOrderStatus.IN_PROGRESS -> "قيد التنفيذ"
    WorkOrderStatus.WAITING_MATERIAL -> "بانتظار مواد"
    WorkOrderStatus.WAITING_APPROVAL -> "بانتظار اعتماد"
    WorkOrderStatus.COMPLETED_BY_TECHNICIAN -> "مكتمل من الفني"
    WorkOrderStatus.CLOSED -> "مغلق"
    WorkOrderStatus.CANCELLED -> "ملغي"
}
