package com.alhadi.cmms.data.repository

import android.content.Context
import androidx.room.withTransaction
import com.alhadi.cmms.core.model.AuditAction
import com.alhadi.cmms.core.model.SyncOperationType
import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.core.model.WorkOrderStatus
import com.alhadi.cmms.database.AlhadiCmmsDatabase
import com.alhadi.cmms.database.entity.AuditLogEntity
import com.alhadi.cmms.database.entity.SyncQueueEntity
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.database.entity.WorkOrderEntity
import com.alhadi.cmms.database.entity.WorkOrderExecutionLogEntity
import com.alhadi.cmms.database.entity.WorkOrderStatusHistoryEntity
import com.alhadi.cmms.domain.repository.WorkOrderRepository
import com.alhadi.cmms.firebase.WorkOrderRemoteDataSource
import com.alhadi.cmms.sync.SyncEntityType
import com.alhadi.cmms.sync.SyncQueueScheduler
import com.alhadi.cmms.sync.WorkOrderRealtimeSyncState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.onStart
import java.util.UUID

class WorkOrderRepositoryImpl(
    private val database: AlhadiCmmsDatabase,
    private val appContext: Context? = null,
    private val remoteDataSource: WorkOrderRemoteDataSource = WorkOrderRemoteDataSource()
) : WorkOrderRepository {
    private val workOrderDao = database.workOrderDao()
    private val statusHistoryDao = database.workOrderStatusHistoryDao()
    private val executionLogDao = database.workOrderExecutionLogDao()
    private val auditLogDao = database.auditLogDao()
    private val syncQueueDao = database.syncQueueDao()

    override fun observeCompanyWorkOrders(companyId: String): Flow<List<WorkOrderEntity>> =
        workOrderDao.observeForCompany(companyId)

    override fun observeTechnicianWorkOrders(companyId: String, technicianId: String): Flow<List<WorkOrderEntity>> =
        workOrderDao.observeForTechnician(companyId, technicianId)

    override fun observeSupervisorWorkOrders(companyId: String, supervisorId: String): Flow<List<WorkOrderEntity>> =
        workOrderDao.observeForSupervisor(companyId, supervisorId)

    override fun observeWorkOrdersForRole(profile: UserEntity): Flow<List<WorkOrderEntity>> = when (profile.role) {
        UserRole.ADMIN,
        UserRole.MAINTENANCE_MANAGER -> workOrderDao.observeForCompany(profile.companyId)
        UserRole.SUPERVISOR -> workOrderDao.observeForSupervisor(profile.companyId, profile.id)
        UserRole.TECHNICIAN -> workOrderDao.observeForTechnician(profile.companyId, profile.id)
        UserRole.VIEWER -> workOrderDao.observeForCompany(profile.companyId)
        UserRole.WAREHOUSE,
        UserRole.REQUESTER -> flowOf(emptyList())
    }

    override fun observeWorkOrder(id: String): Flow<WorkOrderEntity?> = workOrderDao.observeById(id)

    override fun observeStatusHistory(companyId: String, workOrderId: String): Flow<List<WorkOrderStatusHistoryEntity>> =
        statusHistoryDao.observeForWorkOrder(companyId, workOrderId)

    override fun observeExecutionLogs(companyId: String, workOrderId: String): Flow<List<WorkOrderExecutionLogEntity>> =
        executionLogDao.observeForWorkOrder(companyId, workOrderId)

    override fun observeAuditLogs(companyId: String, workOrderId: String): Flow<List<AuditLogEntity>> =
        auditLogDao.observeForEntity(companyId, SyncEntityType.WORK_ORDER, workOrderId)

    override fun startRealtimeSyncForRole(profile: UserEntity): Flow<WorkOrderRealtimeSyncState> =
        remoteDataSource.listenForRole(profile)
            .map { batch ->
                if (batch.orders.isNotEmpty()) {
                    database.withTransaction {
                        workOrderDao.upsertAll(batch.orders)
                    }
                }
                WorkOrderRealtimeSyncState.synced(batch.orders.size)
            }
            .onStart { emit(WorkOrderRealtimeSyncState.listening()) }
            .catch { error ->
                emit(WorkOrderRealtimeSyncState.failed(error.message ?: "خطأ غير معروف في مستمع Firestore."))
            }
            .flowOn(Dispatchers.IO)

    override suspend fun getWorkOrder(id: String): WorkOrderEntity? = workOrderDao.getById(id)

    override suspend fun saveLocal(workOrder: WorkOrderEntity) = workOrderDao.upsert(workOrder)

    override suspend fun updateStatus(id: String, status: WorkOrderStatus, updatedAt: Long, updatedBy: String) =
        workOrderDao.updateStatus(id, status, updatedAt, updatedBy)

    override suspend fun createLocalWorkOrder(
        profile: UserEntity,
        title: String,
        description: String?,
        assetId: String?,
        assignedTechnicianId: String?,
        priority: String
    ): WorkOrderEntity {
        require(profile.canCreateWorkOrders()) { "ليس لديك صلاحية إنشاء أمر عمل." }
        val cleanTitle = title.trim()
        require(cleanTitle.isNotBlank()) { "عنوان أمر العمل مطلوب." }
        val now = now()
        val orderId = newId()
        val assignedTech = assignedTechnicianId?.trim()?.takeIf { it.isNotBlank() }
        val initialStatus = if (assignedTech == null) WorkOrderStatus.DRAFT else WorkOrderStatus.ASSIGNED
        val order = WorkOrderEntity(
            id = orderId,
            companyId = profile.companyId,
            workOrderNo = "WO-${now}-${orderId.take(6).uppercase()}",
            assetId = assetId?.trim()?.takeIf { it.isNotBlank() },
            title = cleanTitle,
            description = description?.trim()?.takeIf { it.isNotBlank() },
            status = initialStatus,
            priority = priority.ifBlank { "MEDIUM" }.uppercase(),
            assignedSupervisorId = if (profile.role == UserRole.SUPERVISOR) profile.id else null,
            assignedTechnicianId = assignedTech,
            dueAt = now + DEFAULT_DUE_OFFSET_MS,
            materialAvailable = false,
            requiresMaterialCheck = true,
            lastStatusReason = "إنشاء محلي وإضافة لطابور المزامنة",
            createdAt = now,
            createdBy = profile.id,
            updatedAt = now,
            updatedBy = profile.id,
            syncStatus = SyncStatus.PENDING
        )

        database.withTransaction {
            val queueItems = mutableListOf<SyncQueueEntity>()
            workOrderDao.upsert(order)
            queueItems += order.toQueueItem(SyncOperationType.CREATE, profile.id, priority = 1)

            val history = insertStatusHistory(
                order = order,
                profile = profile,
                from = null,
                to = initialStatus,
                reason = "إنشاء أمر عمل"
            )
            queueItems += history.toQueueItem(profile.id, priority = 2)

            val createAudit = insertAudit(
                order = order,
                profile = profile,
                action = AuditAction.CREATE_WORK_ORDER,
                oldValueJson = null,
                newValueJson = order.toAuditJson()
            )
            queueItems += createAudit.toQueueItem(profile.id, priority = 8)

            if (assignedTech != null) {
                val assignAudit = insertAudit(
                    order = order,
                    profile = profile,
                    action = AuditAction.ASSIGN_TECHNICIAN,
                    oldValueJson = null,
                    newValueJson = """{"assignedTechnicianId":"${assignedTech.jsonEscape()}"}"""
                )
                queueItems += assignAudit.toQueueItem(profile.id, priority = 8)
            }

            syncQueueDao.enqueueAll(queueItems)
        }
        scheduleSyncWorker()
        return order
    }

    override suspend fun startWorkOrder(profile: UserEntity, workOrderId: String) {
        val current = getExistingOrder(workOrderId)
        validateCanTouchWorkOrder(profile, current)
        require(current.status != WorkOrderStatus.CLOSED) { "لا يمكن بدء أمر عمل مغلق." }
        require(current.status != WorkOrderStatus.CANCELLED) { "لا يمكن بدء أمر عمل ملغي." }
        require(current.status != WorkOrderStatus.COMPLETED_BY_TECHNICIAN) { "أمر العمل مكتمل من الفني بالفعل." }
        val now = now()
        val updated = current.copy(
            status = WorkOrderStatus.IN_PROGRESS,
            startedAt = current.startedAt ?: now,
            startedBy = current.startedBy ?: profile.id,
            updatedAt = now,
            updatedBy = profile.id,
            lastStatusReason = "بدء التنفيذ",
            version = current.version + 1,
            syncStatus = SyncStatus.PENDING,
            lastSyncError = null
        )
        applyStatusChange(profile, current, updated, AuditAction.START_WORK_ORDER, "بدء التنفيذ")
    }

    override suspend fun completeWorkOrder(profile: UserEntity, workOrderId: String, laborMinutes: Int, summary: String) {
        val current = getExistingOrder(workOrderId)
        validateCanTouchWorkOrder(profile, current)
        require(current.status == WorkOrderStatus.IN_PROGRESS) { "يجب بدء أمر العمل قبل إكماله." }
        require(laborMinutes > 0) { "لا يمكن إكمال أمر عمل بدون وقت تنفيذ." }
        val cleanSummary = summary.trim()
        require(cleanSummary.isNotBlank()) { "اكتب ملخص التنفيذ قبل الإكمال." }
        val now = now()
        val updated = current.copy(
            status = WorkOrderStatus.COMPLETED_BY_TECHNICIAN,
            completedAt = now,
            completedBy = profile.id,
            actualLaborMinutes = laborMinutes,
            technicianCompletionNotes = cleanSummary,
            executionSummary = cleanSummary,
            updatedAt = now,
            updatedBy = profile.id,
            lastStatusReason = "إكمال من الفني",
            version = current.version + 1,
            syncStatus = SyncStatus.PENDING,
            lastSyncError = null
        )
        val executionLog = WorkOrderExecutionLogEntity(
            id = newId(),
            companyId = current.companyId,
            workOrderId = current.id,
            technicianId = profile.id,
            startedAt = current.startedAt,
            finishedAt = now,
            laborMinutes = laborMinutes,
            summary = cleanSummary,
            notes = "إكمال أمر العمل من واجهة أوامر العمل",
            createdAt = now,
            createdBy = profile.id,
            updatedAt = now,
            updatedBy = profile.id
        )

        database.withTransaction {
            val queueItems = mutableListOf<SyncQueueEntity>()
            workOrderDao.upsert(updated)
            executionLogDao.insert(executionLog)
            queueItems += updated.toQueueItem(SyncOperationType.STATUS_CHANGE, profile.id, priority = 1)
            queueItems += executionLog.toQueueItem(profile.id, priority = 3)

            val history = insertStatusHistory(updated, profile, current.status, updated.status, "إكمال من الفني")
            queueItems += history.toQueueItem(profile.id, priority = 2)

            val audit = insertAudit(
                order = updated,
                profile = profile,
                action = AuditAction.COMPLETE_WORK_ORDER,
                oldValueJson = current.toAuditJson(),
                newValueJson = updated.toAuditJson()
            )
            queueItems += audit.toQueueItem(profile.id, priority = 8)

            syncQueueDao.enqueueAll(queueItems)
        }
        scheduleSyncWorker()
    }

    override suspend fun closeWorkOrder(profile: UserEntity, workOrderId: String, reason: String) {
        val current = getExistingOrder(workOrderId)
        require(profile.canCloseWorkOrders()) { "ليس لديك صلاحية إغلاق أمر العمل." }
        require(current.status != WorkOrderStatus.CANCELLED) { "لا يمكن إغلاق أمر عمل ملغي." }
        require(current.status != WorkOrderStatus.CLOSED) { "أمر العمل مغلق بالفعل." }
        require(executionLogDao.hasAnyForWorkOrder(current.companyId, current.id)) { "لا يمكن إغلاق أمر عمل بدون سجل تنفيذ." }
        val now = now()
        val cleanReason = reason.trim().ifBlank { "إغلاق بعد مراجعة التنفيذ" }
        val updated = current.copy(
            status = WorkOrderStatus.CLOSED,
            closedAt = now,
            closedBy = profile.id,
            updatedAt = now,
            updatedBy = profile.id,
            lastStatusReason = cleanReason,
            version = current.version + 1,
            syncStatus = SyncStatus.PENDING,
            lastSyncError = null
        )
        applyStatusChange(profile, current, updated, AuditAction.CLOSE_WORK_ORDER, cleanReason)
    }

    override suspend fun changeStatus(profile: UserEntity, workOrderId: String, status: WorkOrderStatus, reason: String) {
        if (status == WorkOrderStatus.CLOSED) {
            closeWorkOrder(profile, workOrderId, reason)
            return
        }
        val current = getExistingOrder(workOrderId)
        require(profile.canManageWorkOrders()) { "ليس لديك صلاحية تغيير حالة أمر العمل." }
        if (current.status == WorkOrderStatus.CLOSED && profile.role != UserRole.ADMIN) {
            error("لا يمكن تعديل أمر مغلق إلا بصلاحية مدير النظام.")
        }
        require(current.status != WorkOrderStatus.CANCELLED || profile.role == UserRole.ADMIN) {
            "لا يمكن تعديل أمر ملغي إلا بصلاحية مدير النظام."
        }
        val now = now()
        val cleanReason = reason.trim().ifBlank { "تغيير حالة من واجهة الإدارة" }
        val updated = current.copy(
            status = status,
            updatedAt = now,
            updatedBy = profile.id,
            lastStatusReason = cleanReason,
            version = current.version + 1,
            syncStatus = SyncStatus.PENDING,
            lastSyncError = null
        )
        val action = if (status == WorkOrderStatus.CANCELLED) {
            AuditAction.CANCEL_WORK_ORDER
        } else {
            AuditAction.CHANGE_WORK_ORDER_STATUS
        }
        applyStatusChange(profile, current, updated, action, cleanReason)
    }

    private suspend fun applyStatusChange(
        profile: UserEntity,
        current: WorkOrderEntity,
        updated: WorkOrderEntity,
        action: AuditAction,
        reason: String
    ) {
        database.withTransaction {
            val queueItems = mutableListOf<SyncQueueEntity>()
            workOrderDao.upsert(updated)
            queueItems += updated.toQueueItem(SyncOperationType.STATUS_CHANGE, profile.id, priority = 1)

            val history = insertStatusHistory(updated, profile, current.status, updated.status, reason)
            queueItems += history.toQueueItem(profile.id, priority = 2)

            val audit = insertAudit(
                order = updated,
                profile = profile,
                action = action,
                oldValueJson = current.toAuditJson(),
                newValueJson = updated.toAuditJson()
            )
            queueItems += audit.toQueueItem(profile.id, priority = 8)

            syncQueueDao.enqueueAll(queueItems)
        }
        scheduleSyncWorker()
    }

    private suspend fun getExistingOrder(workOrderId: String): WorkOrderEntity =
        workOrderDao.getById(workOrderId) ?: error("أمر العمل غير موجود محليًا.")

    private fun validateCanTouchWorkOrder(profile: UserEntity, order: WorkOrderEntity) {
        when (profile.role) {
            UserRole.TECHNICIAN -> require(order.assignedTechnicianId == profile.id) { "الفني يرى وينفذ أوامره فقط." }
            UserRole.ADMIN,
            UserRole.MAINTENANCE_MANAGER -> Unit
            UserRole.SUPERVISOR -> require(order.assignedSupervisorId == profile.id || order.assignedSupervisorId == null) { "المشرف يرى أوامر نطاقه فقط." }
            UserRole.WAREHOUSE -> error("المخزن لا يبدأ ولا يكمل أوامر العمل.")
            UserRole.REQUESTER -> error("طالب الخدمة لا ينفذ أوامر العمل.")
            UserRole.VIEWER -> error("دور المشاهدة للقراءة فقط.")
        }
    }

    private suspend fun insertStatusHistory(
        order: WorkOrderEntity,
        profile: UserEntity,
        from: WorkOrderStatus?,
        to: WorkOrderStatus,
        reason: String?
    ): WorkOrderStatusHistoryEntity {
        val now = now()
        val history = WorkOrderStatusHistoryEntity(
            id = newId(),
            companyId = order.companyId,
            workOrderId = order.id,
            fromStatus = from,
            toStatus = to,
            reason = reason,
            changedBy = profile.id,
            changedByRole = profile.role,
            changedAt = now,
            createdAt = now,
            createdBy = profile.id
        )
        statusHistoryDao.insert(history)
        return history
    }

    private suspend fun insertAudit(
        order: WorkOrderEntity,
        profile: UserEntity,
        action: AuditAction,
        oldValueJson: String?,
        newValueJson: String?
    ): AuditLogEntity {
        val log = AuditLogEntity(
            id = newId(),
            companyId = order.companyId,
            entityType = SyncEntityType.WORK_ORDER,
            entityId = order.id,
            action = action,
            oldValueJson = oldValueJson,
            newValueJson = newValueJson,
            performedBy = profile.id,
            performedByRole = profile.role,
            performedAt = now(),
            deviceId = "android-local-stage07",
            source = "ANDROID_ROOM_WORKMANAGER_QUEUE"
        )
        auditLogDao.insert(log)
        return log
    }

    private fun WorkOrderEntity.toQueueItem(
        operationType: SyncOperationType,
        createdBy: String,
        priority: Int
    ): SyncQueueEntity = SyncQueueEntity(
        id = newId(),
        companyId = companyId,
        entityType = SyncEntityType.WORK_ORDER,
        entityId = id,
        operationType = operationType,
        payloadJson = toSyncPayloadJson(operationType),
        status = SyncStatus.PENDING,
        retryCount = 0,
        lastError = null,
        createdAt = now(),
        nextRetryAt = null,
        createdBy = createdBy,
        priority = priority
    )

    private fun WorkOrderStatusHistoryEntity.toQueueItem(createdBy: String, priority: Int): SyncQueueEntity = SyncQueueEntity(
        id = newId(),
        companyId = companyId,
        entityType = SyncEntityType.WORK_ORDER_STATUS_HISTORY,
        entityId = id,
        operationType = SyncOperationType.CREATE,
        payloadJson = """{"id":"${id.jsonEscape()}","workOrderId":"${workOrderId.jsonEscape()}","toStatus":"${toStatus.name}","changedAt":$changedAt}""",
        status = SyncStatus.PENDING,
        createdAt = now(),
        createdBy = createdBy,
        priority = priority
    )

    private fun WorkOrderExecutionLogEntity.toQueueItem(createdBy: String, priority: Int): SyncQueueEntity = SyncQueueEntity(
        id = newId(),
        companyId = companyId,
        entityType = SyncEntityType.WORK_ORDER_EXECUTION_LOG,
        entityId = id,
        operationType = SyncOperationType.CREATE,
        payloadJson = """{"id":"${id.jsonEscape()}","workOrderId":"${workOrderId.jsonEscape()}","laborMinutes":$laborMinutes,"createdAt":$createdAt}""",
        status = SyncStatus.PENDING,
        createdAt = now(),
        createdBy = createdBy,
        priority = priority
    )

    private fun AuditLogEntity.toQueueItem(createdBy: String, priority: Int): SyncQueueEntity = SyncQueueEntity(
        id = newId(),
        companyId = companyId,
        entityType = SyncEntityType.AUDIT_LOG,
        entityId = id,
        operationType = SyncOperationType.CREATE,
        payloadJson = """{"id":"${id.jsonEscape()}","entityType":"${entityType.jsonEscape()}","entityId":"${entityId.jsonEscape()}","action":"${action.name}","performedAt":$performedAt}""",
        status = SyncStatus.PENDING,
        createdAt = now(),
        createdBy = createdBy,
        priority = priority
    )

    private fun WorkOrderEntity.toSyncPayloadJson(operationType: SyncOperationType): String = """
        {"id":"${id.jsonEscape()}","entityType":"${SyncEntityType.WORK_ORDER}","operationType":"${operationType.name}","status":"${status.name}","version":$version,"updatedAt":$updatedAt}
    """.trimIndent()

    private fun scheduleSyncWorker() {
        appContext?.let { context ->
            SyncQueueScheduler.enqueueOneTimeSync(context)
        }
    }

    private fun UserEntity.canCreateWorkOrders(): Boolean = role in setOf(
        UserRole.ADMIN,
        UserRole.MAINTENANCE_MANAGER,
        UserRole.SUPERVISOR
    )

    private fun UserEntity.canManageWorkOrders(): Boolean = role in setOf(
        UserRole.ADMIN,
        UserRole.MAINTENANCE_MANAGER,
        UserRole.SUPERVISOR
    )

    private fun UserEntity.canCloseWorkOrders(): Boolean = role in setOf(
        UserRole.ADMIN,
        UserRole.MAINTENANCE_MANAGER,
        UserRole.SUPERVISOR
    )

    private fun WorkOrderEntity.toAuditJson(): String {
        val assignedTechJson = assignedTechnicianId?.let { "\"${it.jsonEscape()}\"" } ?: "null"
        return """{"id":"${id.jsonEscape()}","status":"${status.name}","assignedTechnicianId":$assignedTechJson,"version":$version,"syncStatus":"${syncStatus.name}"}"""
    }

    private fun String.jsonEscape(): String =
        replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\n", "\\n")
            .replace("\r", "\\r")

    private fun now(): Long = System.currentTimeMillis()
    private fun newId(): String = UUID.randomUUID().toString()

    private companion object {
        const val DEFAULT_DUE_OFFSET_MS = 7L * 24L * 60L * 60L * 1000L
    }
}
