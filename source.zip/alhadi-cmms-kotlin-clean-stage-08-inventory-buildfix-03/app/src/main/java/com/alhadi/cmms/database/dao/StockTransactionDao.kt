package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.alhadi.cmms.database.entity.StockTransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StockTransactionDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(transaction: StockTransactionEntity)

    @Query("SELECT * FROM stock_transactions WHERE id = :id AND isDeleted = 0 LIMIT 1")
    suspend fun getById(id: String): StockTransactionEntity?

    @Query("SELECT * FROM stock_transactions WHERE companyId = :companyId AND isDeleted = 0 ORDER BY transactionAt DESC")
    fun observeForCompany(companyId: String): Flow<List<StockTransactionEntity>>

    @Query("SELECT * FROM stock_transactions WHERE companyId = :companyId AND itemId = :itemId AND warehouseId = :warehouseId AND isDeleted = 0 ORDER BY transactionAt DESC")
    fun observeForItemWarehouse(companyId: String, itemId: String, warehouseId: String): Flow<List<StockTransactionEntity>>

    @Query("SELECT COALESCE(SUM(CASE WHEN type IN ('OPENING','RECEIPT','RETURN_FROM_WORK_ORDER','TRANSFER_IN','ADJUSTMENT_PLUS','RESERVATION_CANCEL') THEN quantity ELSE -quantity END), 0.0) FROM stock_transactions WHERE companyId = :companyId AND itemId = :itemId AND warehouseId = :warehouseId AND isDeleted = 0")
    suspend fun calculateBalance(companyId: String, itemId: String, warehouseId: String): Double
}
