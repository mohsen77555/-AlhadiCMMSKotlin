package com.alhadi.cmms.ui.screens.home

import androidx.compose.runtime.Composable
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.ui.navigation.allowedHomeMenus
import com.alhadi.cmms.ui.navigation.stage04PolicyNotesAr

@Composable
fun AdminHomeScreen(
    profile: UserEntity,
    onSignOut: () -> Unit
) {
    RoleHomeScaffold(
        profile = profile,
        screenTitleAr = "واجهة المدير",
        welcomeAr = "مرحبًا، هذه واجهة المدير وتعرض شاشات الإدارة فقط.",
        allowedMenus = UserRole.ADMIN.allowedHomeMenus(),
        policyNotes = UserRole.ADMIN.stage04PolicyNotesAr(),
        onSignOut = onSignOut
    )
}
