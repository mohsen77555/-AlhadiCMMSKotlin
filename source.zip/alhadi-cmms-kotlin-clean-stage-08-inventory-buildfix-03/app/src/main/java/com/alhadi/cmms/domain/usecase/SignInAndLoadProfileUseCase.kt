package com.alhadi.cmms.domain.usecase

import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.domain.repository.AuthRepository

class SignInAndLoadProfileUseCase(
    private val authRepository: AuthRepository
) {
    suspend operator fun invoke(email: String, password: String): UserEntity {
        return authRepository.signInAndLoadProfile(email, password)
    }
}
