package com.alhadi.cmms.core.model

enum class InventoryRequestStatus {
    DRAFT,
    REQUESTED,
    APPROVED,
    PARTIALLY_ISSUED,
    ISSUED,
    REJECTED,
    CANCELLED,
    RETURNED
}

fun InventoryRequestStatus.arabicLabel(): String = when (this) {
    InventoryRequestStatus.DRAFT -> "مسودة"
    InventoryRequestStatus.REQUESTED -> "مطلوب"
    InventoryRequestStatus.APPROVED -> "معتمد"
    InventoryRequestStatus.PARTIALLY_ISSUED -> "مصروف جزئيًا"
    InventoryRequestStatus.ISSUED -> "مصروف"
    InventoryRequestStatus.REJECTED -> "مرفوض"
    InventoryRequestStatus.CANCELLED -> "ملغي"
    InventoryRequestStatus.RETURNED -> "مرتجع"
}
