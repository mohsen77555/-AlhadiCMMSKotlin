package com.alhadi.cmms.data.repository

import com.alhadi.cmms.core.model.WorkRequestStatus
import com.alhadi.cmms.database.dao.WorkRequestDao
import com.alhadi.cmms.database.entity.WorkRequestEntity
import com.alhadi.cmms.domain.repository.WorkRequestRepository
import kotlinx.coroutines.flow.Flow

class WorkRequestRepositoryImpl(
    private val workRequestDao: WorkRequestDao
) : WorkRequestRepository {
    override fun observeRequesterRequests(companyId: String, requesterId: String): Flow<List<WorkRequestEntity>> =
        workRequestDao.observeForRequester(companyId, requesterId)

    override fun observeCompanyRequests(companyId: String): Flow<List<WorkRequestEntity>> =
        workRequestDao.observeForCompany(companyId)

    override suspend fun saveLocal(request: WorkRequestEntity) = workRequestDao.upsert(request)

    override suspend fun updateStatus(id: String, status: WorkRequestStatus, updatedAt: Long, updatedBy: String) =
        workRequestDao.updateStatus(id, status, updatedAt, updatedBy)
}
