package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.alhadi.cmms.database.entity.WorkOrderExecutionLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkOrderExecutionLogDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(log: WorkOrderExecutionLogEntity)

    @Query("SELECT * FROM work_order_execution_logs WHERE companyId = :companyId AND workOrderId = :workOrderId AND isDeleted = 0 ORDER BY createdAt DESC")
    fun observeForWorkOrder(companyId: String, workOrderId: String): Flow<List<WorkOrderExecutionLogEntity>>

    @Query("SELECT * FROM work_order_execution_logs WHERE companyId = :companyId AND workOrderId = :workOrderId AND isDeleted = 0 ORDER BY createdAt DESC")
    suspend fun listForWorkOrder(companyId: String, workOrderId: String): List<WorkOrderExecutionLogEntity>

    @Query("SELECT COUNT(*) > 0 FROM work_order_execution_logs WHERE companyId = :companyId AND workOrderId = :workOrderId AND isDeleted = 0")
    suspend fun hasAnyForWorkOrder(companyId: String, workOrderId: String): Boolean

    @Query("SELECT * FROM work_order_execution_logs WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): WorkOrderExecutionLogEntity?
}
