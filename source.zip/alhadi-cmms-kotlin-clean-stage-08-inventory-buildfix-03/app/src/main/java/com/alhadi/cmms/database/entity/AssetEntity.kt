package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "assets",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["companyId", "code"], unique = true),
        Index(value = ["groupId"]),
        Index(value = ["locationId"]),
        Index(value = ["parentAssetId"])
    ]
)
data class AssetEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val code: String,
    val name: String,
    val groupId: String? = null,
    val locationId: String? = null,
    val parentAssetId: String? = null,
    val status: String = "ACTIVE",
    val criticality: String = "MEDIUM",
    val description: String? = null,
    val technicalSpecsJson: String = "{}",
    val createdAt: Long,
    val createdBy: String,
    val updatedAt: Long,
    val updatedBy: String,
    val deletedAt: Long? = null,
    val deletedBy: String? = null,
    val isDeleted: Boolean = false,
    val version: Long = 1,
    val syncVersion: Long = 0
)
