package com.alhadi.cmms.ui.navigation

import com.alhadi.cmms.core.model.UserRole

data class RoleMenuItem(
    val id: String,
    val titleAr: String,
    val subtitleAr: String,
    val badgeAr: String
)

fun UserRole.homeTitleAr(): String = when (this) {
    UserRole.ADMIN -> "لوحة مدير النظام"
    UserRole.MAINTENANCE_MANAGER -> "لوحة مدير الصيانة"
    UserRole.SUPERVISOR -> "لوحة المشرف"
    UserRole.TECHNICIAN -> "لوحة الفني"
    UserRole.WAREHOUSE -> "لوحة المخزن"
    UserRole.REQUESTER -> "لوحة طالب الخدمة"
    UserRole.VIEWER -> "لوحة المشاهدة"
}

fun UserRole.allowedHomeMenus(): List<RoleMenuItem> = when (this) {
    UserRole.ADMIN -> listOf(
        RoleMenuItem("admin_dashboard", "لوحة التحكم", "مؤشرات عامة لكل النظام", "جاهز"),
        RoleMenuItem("work_requests", "طلبات الصيانة", "كل طلبات الصيانة والمراجعة", "جاهز"),
        RoleMenuItem("work_orders", "أوامر العمل", "كل أوامر العمل والحالات", "جاهز"),
        RoleMenuItem("assets", "الأصول", "الأصول والمواقع والمجموعات", "تجهيز"),
        RoleMenuItem("inventory", "المخزون", "الأصناف والأرصدة والحركات", "تجهيز"),
        RoleMenuItem("reports", "التقارير", "تقارير الصيانة والمخزون", "تجهيز"),
        RoleMenuItem("users", "المستخدمون", "إدارة المستخدمين والصلاحيات", "إداري"),
        RoleMenuItem("settings", "الإعدادات", "إعدادات الشركة والتطبيق", "إداري"),
        RoleMenuItem("more", "المزيد", "وظائف إدارية إضافية", "إداري")
    )

    UserRole.MAINTENANCE_MANAGER -> listOf(
        RoleMenuItem("maintenance_dashboard", "لوحة التحكم", "مؤشرات الصيانة", "جاهز"),
        RoleMenuItem("work_requests", "طلبات الصيانة", "طلبات الصيانة ضمن صلاحيات الصيانة", "جاهز"),
        RoleMenuItem("work_orders", "أوامر العمل", "التخطيط والمتابعة والإغلاق", "جاهز"),
        RoleMenuItem("assets", "الأصول", "الأصول ضمن نطاق الصيانة", "تجهيز"),
        RoleMenuItem("pm", "الصيانة الوقائية", "قوالب PM والتوقعات", "تجهيز"),
        RoleMenuItem("technicians", "الفنيون", "متابعة الأحمال والمهام", "جاهز"),
        RoleMenuItem("reports", "التقارير", "تقارير الأداء والأعطال", "تجهيز")
    )

    UserRole.SUPERVISOR -> listOf(
        RoleMenuItem("supervisor_dashboard", "لوحة التحكم", "ملخص نطاق المشرف", "جاهز"),
        RoleMenuItem("work_requests", "طلبات الصيانة", "مراجعة وقبول أو رفض الطلبات", "جاهز"),
        RoleMenuItem("work_orders", "أوامر العمل", "أوامر العمل ضمن النطاق", "جاهز"),
        RoleMenuItem("technicians", "الفنيون", "الفنيون التابعون للمشرف", "جاهز"),
        RoleMenuItem("assets", "الأصول", "الأصول ضمن النطاق", "تجهيز"),
        RoleMenuItem("reports_limited", "تقارير محدودة", "تقارير نطاق المشرف فقط", "تجهيز")
    )

    UserRole.TECHNICIAN -> listOf(
        RoleMenuItem("my_orders", "أوامري", "أوامر العمل المسندة للفني فقط", "جاهز"),
        RoleMenuItem("in_progress", "قيد التنفيذ", "الأعمال المفتوحة حاليًا", "جاهز"),
        RoleMenuItem("material_requests", "طلبات المواد", "طلب قطع الغيار من أمر العمل", "تجهيز"),
        RoleMenuItem("work_log", "سجل العمل", "سجل التنفيذ والملاحظات", "جاهز"),
        RoleMenuItem("account", "حسابي", "بيانات المستخدم والجلسة", "جاهز")
    )

    UserRole.WAREHOUSE -> listOf(
        RoleMenuItem("inventory", "المخزون", "الأصناف والأرصدة", "تجهيز"),
        RoleMenuItem("issue_requests", "طلبات الصرف", "طلبات المواد من أوامر العمل", "تجهيز"),
        RoleMenuItem("stock_transactions", "حركات المخزون", "الصرف والإرجاع والتحويل", "تجهيز"),
        RoleMenuItem("items", "الأصناف", "Item Master وقطع الغيار", "تجهيز"),
        RoleMenuItem("warehouse_reports", "التقارير المخزنية", "Low Stock وCritical Spares", "تجهيز")
    )

    UserRole.REQUESTER -> listOf(
        RoleMenuItem("new_request", "طلب جديد", "إنشاء طلب صيانة", "جاهز"),
        RoleMenuItem("my_requests", "طلباتي", "متابعة الطلبات التي أنشأتها فقط", "جاهز"),
        RoleMenuItem("notifications", "الإشعارات", "تنبيهات حالة الطلب", "جاهز"),
        RoleMenuItem("account", "حسابي", "بيانات المستخدم والجلسة", "جاهز")
    )

    UserRole.VIEWER -> listOf(
        RoleMenuItem("viewer_dashboard", "لوحة مشاهدة", "عرض محدود بدون تعديل", "جاهز"),
        RoleMenuItem("assets_readonly", "الأصول", "مشاهدة الأصول فقط", "تجهيز"),
        RoleMenuItem("work_orders_readonly", "أوامر العمل", "مشاهدة محدودة لأوامر العمل", "جاهز"),
        RoleMenuItem("reports_readonly", "التقارير", "تقارير للقراءة فقط", "تجهيز"),
        RoleMenuItem("account", "حسابي", "بيانات المستخدم والجلسة", "جاهز")
    )
}

fun UserRole.stage04PolicyNotesAr(): List<String> = when (this) {
    UserRole.ADMIN -> listOf(
        "يرى المدير كل الشاشات الإدارية المسموحة فقط.",
        "تبويب المزيد يظهر للمدير فقط ولا يظهر للفني.",
        "إدارة المستخدمين والصلاحيات ستُحمى بقواعد Firestore Security Rules."
    )
    UserRole.MAINTENANCE_MANAGER -> listOf(
        "يرى مدير الصيانة شاشات الصيانة والتقارير ولا يرى إعدادات النظام العامة.",
        "بياناته التفصيلية ستأتي من Room ثم Firestore حسب النطاق في المراحل القادمة."
    )
    UserRole.SUPERVISOR -> listOf(
        "يرى المشرف نطاقه فقط وليس كل النظام.",
        "تحويل طلب الصيانة إلى أمر عمل يتم بسجل تدقيق واضح."
    )
    UserRole.TECHNICIAN -> listOf(
        "الفني لا يرى تبويب المزيد إطلاقًا.",
        "الفني يرى أوامره وطلبات مواده وسجل عمله فقط.",
        "لا توجد شاشة لتعديل المخزون في واجهة الفني."
    )
    UserRole.WAREHOUSE -> listOf(
        "المخزن يرى المخزون وطلبات الصرف والحركات فقط.",
        "المخزن لا يغلق أوامر العمل ولا يعدل دور المستخدمين."
    )
    UserRole.REQUESTER -> listOf(
        "طالب الخدمة يرى طلباته فقط.",
        "لا يتم تحويل المستخدم تلقائيًا إلى طالب خدمة عند فشل تحميل الصلاحيات."
    )
    UserRole.VIEWER -> listOf(
        "المشاهدة للقراءة فقط.",
        "أي وظائف تعديل غير ظاهرة لهذا الدور."
    )
}
