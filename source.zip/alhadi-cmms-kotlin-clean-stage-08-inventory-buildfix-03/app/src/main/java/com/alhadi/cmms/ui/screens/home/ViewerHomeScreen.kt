package com.alhadi.cmms.ui.screens.home

import androidx.compose.runtime.Composable
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.ui.navigation.allowedHomeMenus
import com.alhadi.cmms.ui.navigation.stage04PolicyNotesAr

@Composable
fun ViewerHomeScreen(
    profile: UserEntity,
    onSignOut: () -> Unit
) {
    RoleHomeScaffold(
        profile = profile,
        screenTitleAr = "واجهة المشاهدة",
        welcomeAr = "مرحبًا، هذه واجهة قراءة فقط بدون تعديل.",
        allowedMenus = UserRole.VIEWER.allowedHomeMenus(),
        policyNotes = UserRole.VIEWER.stage04PolicyNotesAr(),
        onSignOut = onSignOut
    )
}
