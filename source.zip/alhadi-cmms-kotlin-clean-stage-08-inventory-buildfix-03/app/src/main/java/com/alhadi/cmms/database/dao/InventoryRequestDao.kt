package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.alhadi.cmms.core.model.InventoryRequestStatus
import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.database.entity.InventoryRequestEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface InventoryRequestDao {
    @Upsert
    suspend fun upsert(request: InventoryRequestEntity)

    @Query("SELECT * FROM inventory_requests WHERE id = :id AND isDeleted = 0 LIMIT 1")
    suspend fun getById(id: String): InventoryRequestEntity?

    @Query("SELECT * FROM inventory_requests WHERE companyId = :companyId AND isDeleted = 0 ORDER BY createdAt DESC")
    fun observeForCompany(companyId: String): Flow<List<InventoryRequestEntity>>

    @Query("SELECT * FROM inventory_requests WHERE companyId = :companyId AND status = :status AND isDeleted = 0 ORDER BY createdAt DESC")
    fun observeForStatus(companyId: String, status: InventoryRequestStatus): Flow<List<InventoryRequestEntity>>

    @Query("UPDATE inventory_requests SET status = :status, approvedBy = :approvedBy, approvedAt = :approvedAt, issuedBy = :issuedBy, issuedAt = :issuedAt, updatedAt = :updatedAt, updatedBy = :updatedBy, syncStatus = :syncStatus, syncVersion = syncVersion + 1 WHERE id = :id")
    suspend fun markIssued(
        id: String,
        status: InventoryRequestStatus,
        approvedBy: String,
        approvedAt: Long,
        issuedBy: String,
        issuedAt: Long,
        updatedAt: Long,
        updatedBy: String,
        syncStatus: SyncStatus
    )

    @Query("UPDATE inventory_requests SET status = :status, rejectedBy = :rejectedBy, rejectedAt = :rejectedAt, reason = :reason, updatedAt = :updatedAt, updatedBy = :updatedBy, syncStatus = :syncStatus, syncVersion = syncVersion + 1 WHERE id = :id")
    suspend fun reject(
        id: String,
        status: InventoryRequestStatus,
        rejectedBy: String,
        rejectedAt: Long,
        reason: String,
        updatedAt: Long,
        updatedBy: String,
        syncStatus: SyncStatus
    )
}
