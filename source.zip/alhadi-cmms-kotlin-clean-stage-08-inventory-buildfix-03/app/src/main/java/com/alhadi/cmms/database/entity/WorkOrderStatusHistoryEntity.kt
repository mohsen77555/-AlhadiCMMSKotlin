package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.core.model.WorkOrderStatus

@Entity(
    tableName = "work_order_status_history",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["workOrderId"]),
        Index(value = ["changedBy"]),
        Index(value = ["changedAt"]),
        Index(value = ["companyId", "workOrderId", "changedAt"])
    ]
)
data class WorkOrderStatusHistoryEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val workOrderId: String,
    val fromStatus: WorkOrderStatus? = null,
    val toStatus: WorkOrderStatus,
    val reason: String? = null,
    val changedBy: String,
    val changedByRole: UserRole,
    val changedAt: Long,
    val createdAt: Long,
    val createdBy: String,
    val isDeleted: Boolean = false,
    val version: Long = 1,
    val syncVersion: Long = 0
)
