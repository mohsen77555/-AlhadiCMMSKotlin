package com.alhadi.cmms.ui.navigation

import android.app.Application
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.alhadi.cmms.ui.auth.AuthGateViewModel
import com.alhadi.cmms.ui.auth.AuthGateViewModelFactory
import com.alhadi.cmms.ui.auth.AuthScreen
import com.alhadi.cmms.ui.screens.LoadingPermissionsScreen
import com.alhadi.cmms.ui.screens.LoginScreen
import com.alhadi.cmms.ui.screens.PermissionErrorScreen
import com.alhadi.cmms.ui.screens.RoleReadyScreen
import com.alhadi.cmms.ui.screens.SplashScreen
import com.alhadi.cmms.ui.screens.home.RoleHomeScreen

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    val application = LocalContext.current.applicationContext as Application
    val authViewModel: AuthGateViewModel = viewModel(
        factory = AuthGateViewModelFactory(application)
    )
    val authUiState by authViewModel.uiState.collectAsStateWithLifecycle()
    val currentBackStackEntry by navController.currentBackStackEntryAsState()
    val targetRoute = authUiState.screen.toAppRoute().route

    LaunchedEffect(targetRoute, currentBackStackEntry?.destination?.route) {
        val currentRoute = currentBackStackEntry?.destination?.route
        if (currentRoute != null && currentRoute != targetRoute) {
            navController.navigate(targetRoute) {
                launchSingleTop = true
                popUpTo(AppRoute.SPLASH.route) { inclusive = false }
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = AppRoute.SPLASH.route
    ) {
        composable(AppRoute.SPLASH.route) {
            SplashScreen(onFinished = authViewModel::onSplashFinished)
        }

        composable(AppRoute.LOGIN.route) {
            LoginScreen(
                isBusy = authUiState.isBusy,
                errorMessage = authUiState.errorMessageAr,
                onLoginClicked = authViewModel::signIn
            )
        }

        composable(AppRoute.LOADING_PERMISSIONS.route) {
            LoadingPermissionsScreen(
                message = authUiState.loadingMessageAr,
                details = "لن يتم فتح أي واجهة دور قبل قراءة ملف users/{uid} وتخزينه في Room."
            )
        }

        composable(AppRoute.PERMISSION_ERROR.route) {
            PermissionErrorScreen(
                message = authUiState.errorMessageAr ?: "لا يوجد ملف صلاحيات لهذا المستخدم. تواصل مع مدير النظام.",
                onRetry = authViewModel::retryCurrentProfileLoad,
                onBackToLogin = authViewModel::signOutAndReturnToLogin
            )
        }

        composable(AppRoute.ROLE_READY.route) {
            RoleReadyScreen(
                profile = authUiState.profile,
                onSignOut = authViewModel::signOutAndReturnToLogin
            )
        }

        composable(AppRoute.ROLE_HOME.route) {
            RoleHomeScreen(
                profile = authUiState.profile,
                onSignOut = authViewModel::signOutAndReturnToLogin
            )
        }
    }
}

private fun AuthScreen.toAppRoute(): AppRoute = when (this) {
    AuthScreen.SPLASH -> AppRoute.SPLASH
    AuthScreen.LOGIN -> AppRoute.LOGIN
    AuthScreen.LOADING_PERMISSIONS -> AppRoute.LOADING_PERMISSIONS
    AuthScreen.PERMISSION_ERROR -> AppRoute.PERMISSION_ERROR
    AuthScreen.ROLE_READY -> AppRoute.ROLE_READY
    AuthScreen.ROLE_HOME -> AppRoute.ROLE_HOME
}
