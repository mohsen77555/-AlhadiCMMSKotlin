package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "inventory_request_lines",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["requestId"]),
        Index(value = ["itemId"]),
        Index(value = ["warehouseId"]),
        Index(value = ["workOrderId"])
    ]
)
data class InventoryRequestLineEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val requestId: String,
    val workOrderId: String? = null,
    val itemId: String,
    val warehouseId: String,
    val requestedQuantity: Double,
    val approvedQuantity: Double = 0.0,
    val issuedQuantity: Double = 0.0,
    val returnedQuantity: Double = 0.0,
    val unitCostSnapshot: Double = 0.0,
    val notes: String? = null,
    val createdAt: Long,
    val createdBy: String,
    val updatedAt: Long,
    val updatedBy: String,
    val isDeleted: Boolean = false,
    val version: Long = 1,
    val syncVersion: Long = 0
)
