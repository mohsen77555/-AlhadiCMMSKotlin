package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "items",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["companyId", "itemCode"], unique = true),
        Index(value = ["category"]),
        Index(value = ["isCriticalSpare"])
    ]
)
data class ItemEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val itemCode: String,
    val itemName: String,
    val unit: String,
    val category: String? = null,
    val isCriticalSpare: Boolean = false,
    val minStock: Double = 0.0,
    val maxStock: Double? = null,
    val reorderPoint: Double? = null,
    val createdAt: Long,
    val createdBy: String,
    val updatedAt: Long,
    val updatedBy: String,
    val deletedAt: Long? = null,
    val deletedBy: String? = null,
    val isDeleted: Boolean = false,
    val version: Long = 1,
    val syncVersion: Long = 0
)
