package com.alhadi.cmms.core.model

enum class StockTransactionType {
    OPENING,
    RECEIPT,
    ISSUE_TO_WORK_ORDER,
    RETURN_FROM_WORK_ORDER,
    TRANSFER_IN,
    TRANSFER_OUT,
    ADJUSTMENT_PLUS,
    ADJUSTMENT_MINUS,
    RESERVATION,
    RESERVATION_CANCEL
}
