package com.alhadi.cmms.firebase

import com.alhadi.cmms.database.entity.WorkOrderEntity

data class WorkOrderRemoteBatch(
    val orders: List<WorkOrderEntity>,
    val receivedAt: Long = System.currentTimeMillis(),
    val noteAr: String? = null
)
