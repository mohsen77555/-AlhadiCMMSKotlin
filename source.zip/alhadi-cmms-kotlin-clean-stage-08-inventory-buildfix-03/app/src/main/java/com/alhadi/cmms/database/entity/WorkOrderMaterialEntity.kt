package com.alhadi.cmms.database.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "work_order_materials",
    indices = [
        Index(value = ["companyId"]),
        Index(value = ["workOrderId"]),
        Index(value = ["itemId"]),
        Index(value = ["warehouseId"]),
        Index(value = ["inventoryRequestId"])
    ]
)
data class WorkOrderMaterialEntity(
    @PrimaryKey val id: String,
    val companyId: String,
    val workOrderId: String,
    val itemId: String,
    val warehouseId: String? = null,
    val plannedQuantity: Double = 0.0,
    val requestedQuantity: Double = 0.0,
    val reservedQuantity: Double = 0.0,
    val issuedQuantity: Double = 0.0,
    val returnedQuantity: Double = 0.0,
    val unitCostSnapshot: Double = 0.0,
    val inventoryRequestId: String? = null,
    val notes: String? = null,
    val createdAt: Long,
    val createdBy: String,
    val updatedAt: Long,
    val updatedBy: String,
    val isDeleted: Boolean = false,
    val version: Long = 1,
    val syncVersion: Long = 0
)
