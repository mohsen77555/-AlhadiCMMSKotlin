package com.alhadi.cmms.domain.repository

import com.alhadi.cmms.database.entity.AssetEntity
import kotlinx.coroutines.flow.Flow

interface AssetRepository {
    fun observeAssets(companyId: String): Flow<List<AssetEntity>>
    fun observeAsset(assetId: String): Flow<AssetEntity?>
    suspend fun getAsset(assetId: String): AssetEntity?
    suspend fun saveLocal(asset: AssetEntity)
}
