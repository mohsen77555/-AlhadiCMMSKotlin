package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.alhadi.cmms.database.entity.ItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ItemDao {
    @Upsert
    suspend fun upsert(item: ItemEntity)

    @Upsert
    suspend fun upsertAll(items: List<ItemEntity>)

    @Query("SELECT * FROM items WHERE id = :id AND isDeleted = 0 LIMIT 1")
    suspend fun getById(id: String): ItemEntity?

    @Query("SELECT * FROM items WHERE id = :id AND isDeleted = 0 LIMIT 1")
    fun observeById(id: String): Flow<ItemEntity?>

    @Query("SELECT * FROM items WHERE companyId = :companyId AND isDeleted = 0 ORDER BY itemCode ASC")
    fun observeForCompany(companyId: String): Flow<List<ItemEntity>>

    @Query("SELECT * FROM items WHERE companyId = :companyId AND isCriticalSpare = 1 AND isDeleted = 0 ORDER BY itemCode ASC")
    fun observeCriticalSpares(companyId: String): Flow<List<ItemEntity>>

    @Query("UPDATE items SET isDeleted = 1, deletedAt = :deletedAt, deletedBy = :deletedBy, updatedAt = :deletedAt, updatedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)
}
