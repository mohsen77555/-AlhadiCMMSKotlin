package com.alhadi.cmms.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun StageBadge(text: String) {
    AssistChip(
        onClick = { },
        label = { Text(text) },
        modifier = Modifier.padding(vertical = 4.dp)
    )
}
