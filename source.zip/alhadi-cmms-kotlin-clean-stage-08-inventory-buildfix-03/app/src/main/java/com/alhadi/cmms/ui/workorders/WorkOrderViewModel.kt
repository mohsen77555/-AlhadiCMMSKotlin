package com.alhadi.cmms.ui.workorders

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.alhadi.cmms.core.model.WorkOrderStatus
import com.alhadi.cmms.data.repository.WorkOrderRepositoryImpl
import com.alhadi.cmms.database.DatabaseProvider
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.domain.repository.WorkOrderRepository
import com.alhadi.cmms.sync.SyncQueueScheduler
import com.alhadi.cmms.sync.WorkOrderRealtimeSyncState
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class WorkOrderViewModel(
    application: Application,
    private val profile: UserEntity,
    private val repository: WorkOrderRepository = WorkOrderRepositoryImpl(
        database = DatabaseProvider.getDatabase(application),
        appContext = application.applicationContext
    )
) : AndroidViewModel(application) {
    private val database = DatabaseProvider.getDatabase(application)
    private val selectedWorkOrderId = MutableStateFlow<String?>(null)
    private val operationState = MutableStateFlow(OperationState())
    private val realtimeSyncState = MutableStateFlow(WorkOrderRealtimeSyncState.idle())

    init {
        SyncQueueScheduler.schedulePeriodicSync(application)
        SyncQueueScheduler.enqueueOneTimeSync(application)

        viewModelScope.launch {
            repository.startRealtimeSyncForRole(profile).collect { state ->
                realtimeSyncState.value = state
            }
        }
    }

    private val workOrderDetailsFlow = combine(
        repository.observeWorkOrdersForRole(profile),
        selectedWorkOrderId.flatMapLatest { id ->
            if (id.isNullOrBlank()) flowOf(emptyList()) else repository.observeStatusHistory(profile.companyId, id)
        },
        selectedWorkOrderId.flatMapLatest { id ->
            if (id.isNullOrBlank()) flowOf(emptyList()) else repository.observeExecutionLogs(profile.companyId, id)
        },
        selectedWorkOrderId.flatMapLatest { id ->
            if (id.isNullOrBlank()) flowOf(emptyList()) else repository.observeAuditLogs(profile.companyId, id)
        }
    ) { orders, history, executionLogs, auditLogs ->
        WorkOrderDetailsBundle(
            orders = orders,
            history = history,
            executionLogs = executionLogs,
            auditLogs = auditLogs
        )
    }

    private val baseUiState = combine(
        workOrderDetailsFlow,
        database.syncQueueDao().observeForCompany(profile.companyId),
        operationState
    ) { details, queueItems, operation ->
        val selectedOrder = selectedWorkOrderId.value?.let { id -> details.orders.firstOrNull { it.id == id } }
        WorkOrderUiState(
            orders = details.orders,
            selectedOrder = selectedOrder,
            statusHistory = details.history,
            executionLogs = details.executionLogs,
            auditLogs = details.auditLogs,
            syncQueueSummary = SyncQueueUiSummary.from(queueItems),
            isBusy = operation.isBusy,
            messageAr = operation.messageAr,
            errorAr = operation.errorAr
        )
    }

    val uiState: StateFlow<WorkOrderUiState> = combine(
        baseUiState,
        realtimeSyncState
    ) { base, realtime ->
        base.copy(realtimeSyncState = realtime)
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = WorkOrderUiState()
    )

    fun selectWorkOrder(id: String) {
        selectedWorkOrderId.value = id
        operationState.update { it.copy(messageAr = null, errorAr = null) }
    }

    fun createWorkOrder(title: String, description: String?, assetId: String?, assignedTechnicianId: String?, priority: String) {
        runOperation(successMessage = "تم إنشاء أمر العمل محليًا وإضافته إلى طابور المزامنة.") {
            val order = repository.createLocalWorkOrder(
                profile = profile,
                title = title,
                description = description,
                assetId = assetId,
                assignedTechnicianId = assignedTechnicianId,
                priority = priority
            )
            selectedWorkOrderId.value = order.id
        }
    }

    fun startSelectedWorkOrder() {
        val id = selectedWorkOrderId.value ?: return showError("اختر أمر عمل أولًا.")
        runOperation(successMessage = "تم بدء أمر العمل محليًا وإضافة العملية لطابور المزامنة.") {
            repository.startWorkOrder(profile, id)
        }
    }

    fun completeSelectedWorkOrder(laborMinutes: Int, summary: String) {
        val id = selectedWorkOrderId.value ?: return showError("اختر أمر عمل أولًا.")
        runOperation(successMessage = "تم إكمال أمر العمل محليًا وإضافة العملية لطابور المزامنة.") {
            repository.completeWorkOrder(profile, id, laborMinutes, summary)
        }
    }

    fun closeSelectedWorkOrder(reason: String) {
        val id = selectedWorkOrderId.value ?: return showError("اختر أمر عمل أولًا.")
        runOperation(successMessage = "تم إغلاق أمر العمل محليًا وإضافة العملية لطابور المزامنة.") {
            repository.closeWorkOrder(profile, id, reason)
        }
    }

    fun changeSelectedStatus(status: WorkOrderStatus, reason: String) {
        val id = selectedWorkOrderId.value ?: return showError("اختر أمر عمل أولًا.")
        runOperation(successMessage = "تم تغيير حالة أمر العمل محليًا وإضافة العملية لطابور المزامنة.") {
            repository.changeStatus(profile, id, status, reason)
        }
    }

    fun runSyncNow() {
        SyncQueueScheduler.enqueueOneTimeSync(getApplication<Application>())
        operationState.value = OperationState(messageAr = "تم طلب تشغيل طابور المزامنة. سيعمل عند توفر الإنترنت.")
    }

    fun clearMessage() {
        operationState.value = OperationState()
    }

    private fun runOperation(successMessage: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            operationState.value = OperationState(isBusy = true)
            runCatching { block() }
                .onSuccess {
                    SyncQueueScheduler.enqueueOneTimeSync(getApplication<Application>())
                    operationState.value = OperationState(messageAr = successMessage)
                }
                .onFailure { error ->
                    operationState.value = OperationState(errorAr = error.message ?: "حدث خطأ أثناء تنفيذ العملية.")
                }
        }
    }

    private fun showError(message: String) {
        operationState.value = OperationState(errorAr = message)
    }

    private data class OperationState(
        val isBusy: Boolean = false,
        val messageAr: String? = null,
        val errorAr: String? = null
    )

    private data class WorkOrderDetailsBundle(
        val orders: List<com.alhadi.cmms.database.entity.WorkOrderEntity>,
        val history: List<com.alhadi.cmms.database.entity.WorkOrderStatusHistoryEntity>,
        val executionLogs: List<com.alhadi.cmms.database.entity.WorkOrderExecutionLogEntity>,
        val auditLogs: List<com.alhadi.cmms.database.entity.AuditLogEntity>
    )
}

class WorkOrderViewModelFactory(
    private val application: Application,
    private val profile: UserEntity
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(WorkOrderViewModel::class.java)) {
            return WorkOrderViewModel(application, profile) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
