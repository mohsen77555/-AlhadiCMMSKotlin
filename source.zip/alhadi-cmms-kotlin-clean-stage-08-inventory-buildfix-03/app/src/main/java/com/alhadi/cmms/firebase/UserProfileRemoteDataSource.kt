package com.alhadi.cmms.firebase

import com.alhadi.cmms.core.auth.InvalidUserRoleException
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.database.entity.UserEntity
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Source
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject

class UserProfileRemoteDataSource(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    suspend fun fetchUserProfile(
        uid: String,
        fallbackEmail: String?,
        fallbackDisplayName: String?
    ): UserEntity? {
        // Diagnostic strategy:
        // 1) Try Firestore REST first. This bypasses cases where the Android SDK reports
        //    "client is offline" although HTTPS works on the device.
        // 2) If REST fails for a temporary/network reason, try the SDK as a second path.
        // 3) If both fail, show a combined diagnostic message instead of the vague offline text.
        var restFailure: Exception? = null
        try {
            return fetchUserProfileByRestFallback(
                uid = uid,
                fallbackEmail = fallbackEmail,
                fallbackDisplayName = fallbackDisplayName,
                originalError = null
            )
        } catch (error: Exception) {
            restFailure = error
        }

        val document = try {
            firestore.enableNetwork().await()
            firestore
                .collection("users")
                .document(uid)
                .get(Source.SERVER)
                .await()
        } catch (sdkError: Exception) {
            val restMessage = restFailure?.message.orEmpty()
            val sdkMessage = sdkError.message.orEmpty()
            throw IllegalStateException(
                "تعذر تحميل ملف الصلاحيات من Firebase. " +
                    "REST error: $restMessage | SDK error: $sdkMessage | UID: $uid",
                sdkError
            )
        }

        if (!document.exists()) return null
        return document.toUserEntity(uid, fallbackEmail, fallbackDisplayName)
    }

    /**
     * Diagnostic fallback for devices/networks where the Firestore Android SDK reports
     * "client is offline" while normal HTTPS is reachable. The app still keeps Firestore
     * as the primary source; this fallback only loads the login profile so the user can enter.
     */
    private suspend fun fetchUserProfileByRestFallback(
        uid: String,
        fallbackEmail: String?,
        fallbackDisplayName: String?,
        originalError: Exception?
    ): UserEntity? = withContext(Dispatchers.IO) {
        val options = FirebaseApp.getInstance().options
        val projectId = options.projectId
        val apiKey = options.apiKey

        if (projectId.isNullOrBlank() || apiKey.isNullOrBlank()) {
            throw IllegalStateException(
                "Firebase projectId/apiKey are missing. Original error: ${originalError?.message.orEmpty()}",
                originalError
            )
        }

        val encodedUid = URLEncoder.encode(uid, "UTF-8")
        val url = URL(
            "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/users/$encodedUid?key=$apiKey"
        )

        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("Accept", "application/json")

            val token = firebaseAuth.currentUser?.getIdToken(false)?.await()?.token
            if (!token.isNullOrBlank()) {
                setRequestProperty("Authorization", "Bearer $token")
            }
        }

        try {
            val responseCode = connection.responseCode
            if (responseCode == HttpURLConnection.HTTP_NOT_FOUND) return@withContext null

            val stream = if (responseCode in 200..299) {
                connection.inputStream
            } else {
                connection.errorStream
            }

            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()

            if (responseCode !in 200..299) {
                throw IllegalStateException(
                    "Firestore REST profile read failed. HTTP $responseCode. Body: $body. Original SDK error: ${originalError?.message.orEmpty()}",
                    originalError
                )
            }

            JSONObject(body).toUserEntity(uid, fallbackEmail, fallbackDisplayName)
        } finally {
            connection.disconnect()
        }
    }

    private fun DocumentSnapshot.toUserEntity(
        uid: String,
        fallbackEmail: String?,
        fallbackDisplayName: String?
    ): UserEntity {
        val now = System.currentTimeMillis()
        val rawRole = getString("role")
        val role = rawRole.toUserRoleOrThrow()

        return UserEntity(
            id = uid,
            companyId = getString("companyId").orEmpty(),
            email = getString("email") ?: fallbackEmail.orEmpty(),
            displayName = getString("displayName") ?: fallbackDisplayName ?: fallbackEmail.orEmpty(),
            role = role,
            isActive = getBoolean("isActive") ?: true,
            permissionsJson = getString("permissionsJson") ?: "{}",
            createdAt = timestampMillis("createdAt", now),
            createdBy = getString("createdBy") ?: "system",
            updatedAt = timestampMillis("updatedAt", now),
            updatedBy = getString("updatedBy") ?: "system",
            deletedAt = timestampMillisOrNull("deletedAt"),
            deletedBy = getString("deletedBy"),
            isDeleted = getBoolean("isDeleted") ?: false,
            version = getLong("version") ?: 1L,
            syncVersion = getLong("syncVersion") ?: 0L
        )
    }

    private fun JSONObject.toUserEntity(
        uid: String,
        fallbackEmail: String?,
        fallbackDisplayName: String?
    ): UserEntity {
        val fields = getJSONObject("fields")
        val now = System.currentTimeMillis()
        val rawRole = fields.stringField("role")
        val role = rawRole.toUserRoleOrThrow()

        return UserEntity(
            id = uid,
            companyId = fields.stringField("companyId").orEmpty(),
            email = fields.stringField("email") ?: fallbackEmail.orEmpty(),
            displayName = fields.stringField("displayName") ?: fallbackDisplayName ?: fallbackEmail.orEmpty(),
            role = role,
            isActive = fields.booleanField("isActive") ?: true,
            permissionsJson = fields.stringField("permissionsJson") ?: "{}",
            createdAt = fields.timestampOrIntegerField("createdAt") ?: now,
            createdBy = fields.stringField("createdBy") ?: "system",
            updatedAt = fields.timestampOrIntegerField("updatedAt") ?: now,
            updatedBy = fields.stringField("updatedBy") ?: "system",
            deletedAt = fields.timestampOrIntegerField("deletedAt"),
            deletedBy = fields.stringField("deletedBy"),
            isDeleted = fields.booleanField("isDeleted") ?: false,
            version = fields.longField("version") ?: 1L,
            syncVersion = fields.longField("syncVersion") ?: 0L
        )
    }

    private fun String?.toUserRoleOrThrow(): UserRole {
        val normalized = this?.trim()?.uppercase()
        return normalized
            ?.let { value -> UserRole.entries.firstOrNull { it.name == value } }
            ?: throw InvalidUserRoleException(this)
    }

    private fun DocumentSnapshot.timestampMillis(field: String, fallback: Long): Long {
        return when (val value = get(field)) {
            is Timestamp -> value.toDate().time
            is Date -> value.time
            is Number -> value.toLong()
            else -> fallback
        }
    }

    private fun DocumentSnapshot.timestampMillisOrNull(field: String): Long? {
        return when (val value = get(field)) {
            is Timestamp -> value.toDate().time
            is Date -> value.time
            is Number -> value.toLong()
            else -> null
        }
    }

    private fun JSONObject.stringField(name: String): String? =
        optJSONObject(name)?.optString("stringValue")?.takeIf { it.isNotBlank() }

    private fun JSONObject.booleanField(name: String): Boolean? =
        optJSONObject(name)?.let { if (it.has("booleanValue")) it.optBoolean("booleanValue") else null }

    private fun JSONObject.longField(name: String): Long? {
        val field = optJSONObject(name) ?: return null
        return when {
            field.has("integerValue") -> field.optString("integerValue").toLongOrNull()
            field.has("doubleValue") -> field.optDouble("doubleValue").toLong()
            else -> null
        }
    }

    private fun JSONObject.timestampOrIntegerField(name: String): Long? {
        val field = optJSONObject(name) ?: return null
        field.optString("timestampValue").takeIf { it.isNotBlank() }?.let { timestamp ->
            return parseFirestoreTimestamp(timestamp)
        }
        return longField(name)
    }
}


private fun parseFirestoreTimestamp(value: String): Long? {
    val patterns = listOf(
        "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
        "yyyy-MM-dd'T'HH:mm:ss'Z'"
    )
    return patterns.firstNotNullOfOrNull { pattern ->
        try {
            SimpleDateFormat(pattern, Locale.US).apply {
                timeZone = TimeZone.getTimeZone("UTC")
            }.parse(value)?.time
        } catch (_: Exception) {
            null
        }
    }
}
