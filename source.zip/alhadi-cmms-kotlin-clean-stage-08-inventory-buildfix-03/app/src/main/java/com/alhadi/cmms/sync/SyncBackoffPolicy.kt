package com.alhadi.cmms.sync

import kotlin.math.min
import kotlin.math.pow

object SyncBackoffPolicy {
    private const val BASE_DELAY_MS = 60_000L
    private const val MAX_DELAY_MS = 6L * 60L * 60L * 1000L

    fun nextRetryAt(now: Long, retryCount: Int): Long {
        val exponent = retryCount.coerceAtLeast(1).coerceAtMost(8)
        val multiplier = 2.0.pow((exponent - 1).toDouble()).toLong()
        val delay = min(BASE_DELAY_MS * multiplier, MAX_DELAY_MS)
        return now + delay
    }
}
