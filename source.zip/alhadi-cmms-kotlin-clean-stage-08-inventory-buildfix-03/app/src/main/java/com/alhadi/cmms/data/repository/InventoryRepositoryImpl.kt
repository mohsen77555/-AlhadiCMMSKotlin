package com.alhadi.cmms.data.repository

import androidx.room.withTransaction
import com.alhadi.cmms.core.model.AuditAction
import com.alhadi.cmms.core.model.InventoryRequestStatus
import com.alhadi.cmms.core.model.InventoryRequestType
import com.alhadi.cmms.core.model.StockTransactionType
import com.alhadi.cmms.core.model.SyncOperationType
import com.alhadi.cmms.core.model.SyncStatus
import com.alhadi.cmms.core.model.UserRole
import com.alhadi.cmms.database.AlhadiCmmsDatabase
import com.alhadi.cmms.database.entity.AuditLogEntity
import com.alhadi.cmms.database.entity.InventoryRequestEntity
import com.alhadi.cmms.database.entity.InventoryRequestLineEntity
import com.alhadi.cmms.database.entity.ItemEntity
import com.alhadi.cmms.database.entity.StockBalanceEntity
import com.alhadi.cmms.database.entity.StockTransactionEntity
import com.alhadi.cmms.database.entity.SyncQueueEntity
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.database.entity.WarehouseEntity
import com.alhadi.cmms.database.entity.WorkOrderMaterialEntity
import com.alhadi.cmms.domain.repository.InventoryRepository
import com.alhadi.cmms.sync.SyncEntityType
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class InventoryRepositoryImpl(
    private val database: AlhadiCmmsDatabase
) : InventoryRepository {
    private val itemDao = database.itemDao()
    private val warehouseDao = database.warehouseDao()
    private val stockBalanceDao = database.stockBalanceDao()
    private val stockTransactionDao = database.stockTransactionDao()
    private val inventoryRequestDao = database.inventoryRequestDao()
    private val inventoryRequestLineDao = database.inventoryRequestLineDao()
    private val workOrderMaterialDao = database.workOrderMaterialDao()
    private val syncQueueDao = database.syncQueueDao()
    private val auditLogDao = database.auditLogDao()

    override fun observeItems(companyId: String): Flow<List<ItemEntity>> = itemDao.observeForCompany(companyId)
    override fun observeWarehouses(companyId: String): Flow<List<WarehouseEntity>> = warehouseDao.observeForCompany(companyId)
    override fun observeStockBalances(companyId: String): Flow<List<StockBalanceEntity>> = stockBalanceDao.observeForCompany(companyId)
    override fun observeStockTransactions(companyId: String): Flow<List<StockTransactionEntity>> = stockTransactionDao.observeForCompany(companyId)
    override fun observeInventoryRequests(companyId: String): Flow<List<InventoryRequestEntity>> = inventoryRequestDao.observeForCompany(companyId)
    override fun observeInventoryRequestLines(companyId: String): Flow<List<InventoryRequestLineEntity>> = inventoryRequestLineDao.observeForCompany(companyId)
    override fun observeWorkOrderMaterials(companyId: String): Flow<List<WorkOrderMaterialEntity>> = workOrderMaterialDao.observeForCompany(companyId)

    override suspend fun saveItemLocal(item: ItemEntity) = itemDao.upsert(item)

    override suspend fun addStockTransaction(transaction: StockTransactionEntity) = database.withTransaction {
        stockTransactionDao.insert(transaction)
        recalculateBalance(transaction.companyId, transaction.itemId, transaction.warehouseId, transaction.createdBy)
    }

    override suspend fun calculateBalance(companyId: String, itemId: String, warehouseId: String): Double =
        stockTransactionDao.calculateBalance(companyId, itemId, warehouseId)

    override suspend fun createItem(
        profile: UserEntity,
        code: String,
        name: String,
        unit: String,
        category: String?,
        minStock: Double,
        critical: Boolean
    ): ItemEntity {
        require(profile.role.canMaintainItemMaster()) { "لا يملك هذا الدور صلاحية إنشاء صنف." }
        require(code.isNotBlank()) { "كود الصنف مطلوب." }
        require(name.isNotBlank()) { "اسم الصنف مطلوب." }
        require(unit.isNotBlank()) { "وحدة القياس مطلوبة." }
        val now = now()
        val item = ItemEntity(
            id = id("item"),
            companyId = profile.companyId,
            itemCode = code.trim(),
            itemName = name.trim(),
            unit = unit.trim(),
            category = category?.trim()?.takeIf { it.isNotBlank() },
            isCriticalSpare = critical,
            minStock = minStock.coerceAtLeast(0.0),
            createdAt = now,
            createdBy = profile.id,
            updatedAt = now,
            updatedBy = profile.id
        )
        database.withTransaction {
            itemDao.upsert(item)
            enqueue(item.companyId, SyncEntityType.ITEM, item.id, SyncOperationType.CREATE, item.toPayload(), profile.id)
            audit(item.companyId, "ITEM", item.id, AuditAction.CREATE_ASSET, null, item.toPayload(), profile)
        }
        return item
    }

    override suspend fun createWarehouse(profile: UserEntity, code: String, name: String, isMain: Boolean): WarehouseEntity {
        require(profile.role.canMaintainInventory()) { "لا يملك هذا الدور صلاحية إنشاء مخزن." }
        require(code.isNotBlank()) { "كود المخزن مطلوب." }
        require(name.isNotBlank()) { "اسم المخزن مطلوب." }
        val now = now()
        val warehouse = WarehouseEntity(
            id = id("wh"),
            companyId = profile.companyId,
            warehouseCode = code.trim(),
            warehouseName = name.trim(),
            isMain = isMain,
            createdAt = now,
            createdBy = profile.id,
            updatedAt = now,
            updatedBy = profile.id
        )
        database.withTransaction {
            warehouseDao.upsert(warehouse)
            enqueue(warehouse.companyId, SyncEntityType.WAREHOUSE, warehouse.id, SyncOperationType.CREATE, warehouse.toPayload(), profile.id)
            audit(warehouse.companyId, "WAREHOUSE", warehouse.id, AuditAction.ADJUST_STOCK, null, warehouse.toPayload(), profile)
        }
        return warehouse
    }

    override suspend fun addOpeningBalance(
        profile: UserEntity,
        itemId: String,
        warehouseId: String,
        quantity: Double,
        unitCost: Double,
        reason: String
    ): StockTransactionEntity = postStockTransaction(
        profile = profile,
        itemId = itemId,
        warehouseId = warehouseId,
        workOrderId = null,
        type = StockTransactionType.OPENING,
        quantity = quantity,
        unitCost = unitCost,
        reason = reason.ifBlank { "رصيد افتتاحي" },
        requiredRoleMessage = "لا يملك هذا الدور صلاحية إدخال رصيد افتتاحي."
    ) { it.canMaintainInventory() }

    override suspend fun receiveStock(
        profile: UserEntity,
        itemId: String,
        warehouseId: String,
        quantity: Double,
        unitCost: Double,
        reason: String
    ): StockTransactionEntity = postStockTransaction(
        profile = profile,
        itemId = itemId,
        warehouseId = warehouseId,
        workOrderId = null,
        type = StockTransactionType.RECEIPT,
        quantity = quantity,
        unitCost = unitCost,
        reason = reason.ifBlank { "استلام مخزني" },
        requiredRoleMessage = "لا يملك هذا الدور صلاحية استلام المخزون."
    ) { it.canMaintainInventory() }

    override suspend fun requestMaterialForWorkOrder(
        profile: UserEntity,
        workOrderId: String,
        itemId: String,
        warehouseId: String,
        quantity: Double,
        notes: String?
    ): InventoryRequestEntity {
        require(profile.role.canRequestMaterial()) { "الفني يطلب المادة، ولا يعدل الرصيد مباشرة." }
        require(workOrderId.isNotBlank()) { "لا يمكن طلب مادة بدون أمر عمل." }
        require(quantity > 0.0) { "الكمية يجب أن تكون أكبر من صفر." }
        val item = itemDao.getById(itemId) ?: error("لا يمكن طلب مادة بدون Item Master.")
        warehouseDao.getById(warehouseId) ?: error("المخزن غير موجود.")
        val now = now()
        val requestId = id("ir")
        val request = InventoryRequestEntity(
            id = requestId,
            companyId = profile.companyId,
            requestNo = nextNo("MR"),
            type = InventoryRequestType.ISSUE_TO_WORK_ORDER,
            status = InventoryRequestStatus.REQUESTED,
            workOrderId = workOrderId.trim(),
            requestedBy = profile.id,
            requestedByRole = profile.role.name,
            requestedAt = now,
            notes = notes?.trim()?.takeIf { it.isNotBlank() },
            lineCount = 1,
            createdAt = now,
            createdBy = profile.id,
            updatedAt = now,
            updatedBy = profile.id,
            syncStatus = SyncStatus.PENDING
        )
        val line = InventoryRequestLineEntity(
            id = id("irl"),
            companyId = profile.companyId,
            requestId = requestId,
            workOrderId = workOrderId.trim(),
            itemId = item.id,
            warehouseId = warehouseId,
            requestedQuantity = quantity,
            notes = notes?.trim()?.takeIf { it.isNotBlank() },
            createdAt = now,
            createdBy = profile.id,
            updatedAt = now,
            updatedBy = profile.id
        )
        val material = WorkOrderMaterialEntity(
            id = id("wom"),
            companyId = profile.companyId,
            workOrderId = workOrderId.trim(),
            itemId = item.id,
            warehouseId = warehouseId,
            requestedQuantity = quantity,
            inventoryRequestId = requestId,
            notes = notes?.trim()?.takeIf { it.isNotBlank() },
            createdAt = now,
            createdBy = profile.id,
            updatedAt = now,
            updatedBy = profile.id
        )
        database.withTransaction {
            inventoryRequestDao.upsert(request)
            inventoryRequestLineDao.upsert(line)
            workOrderMaterialDao.upsert(material)
            enqueue(request.companyId, SyncEntityType.INVENTORY_REQUEST, request.id, SyncOperationType.CREATE, request.toPayload(), profile.id)
            enqueue(line.companyId, SyncEntityType.INVENTORY_REQUEST_LINE, line.id, SyncOperationType.CREATE, line.toPayload(), profile.id)
            enqueue(material.companyId, SyncEntityType.WORK_ORDER_MATERIAL, material.id, SyncOperationType.CREATE, material.toPayload(), profile.id)
            audit(request.companyId, "INVENTORY_REQUEST", request.id, AuditAction.REQUEST_MATERIAL, null, request.toPayload(), profile)
        }
        return request
    }

    override suspend fun approveAndIssueRequest(profile: UserEntity, requestId: String): List<StockTransactionEntity> {
        require(profile.role.canIssueStock()) { "الفني لا يصرف مباشرة. المخزن أو المدير فقط يعتمد ويصرف." }
        val request = inventoryRequestDao.getById(requestId) ?: error("طلب الصرف غير موجود.")
        require(request.workOrderId != null) { "لا صرف بدون أمر عمل." }
        val lines = inventoryRequestLineDao.getForRequest(request.id).filterNot { it.isDeleted }
        require(lines.isNotEmpty()) { "طلب الصرف لا يحتوي على أسطر." }
        val now = now()
        val transactions = mutableListOf<StockTransactionEntity>()
        database.withTransaction {
            lines.forEach { line ->
                itemDao.getById(line.itemId) ?: error("لا صرف بدون Item Master.")
                val available = stockTransactionDao.calculateBalance(line.companyId, line.itemId, line.warehouseId)
                if (available < line.requestedQuantity) {
                    error("الرصيد غير كاف للصنف ${line.itemId}. المتاح=$available، المطلوب=${line.requestedQuantity}.")
                }
                val trx = StockTransactionEntity(
                    id = id("st"),
                    companyId = request.companyId,
                    transactionNo = nextNo("ISS"),
                    itemId = line.itemId,
                    warehouseId = line.warehouseId,
                    workOrderId = request.workOrderId,
                    type = StockTransactionType.ISSUE_TO_WORK_ORDER,
                    quantity = line.requestedQuantity,
                    reason = "صرف بناءً على طلب ${request.requestNo}",
                    approvedBy = profile.id,
                    approvedAt = now,
                    transactionAt = now,
                    createdAt = now,
                    createdBy = profile.id,
                    updatedAt = now,
                    updatedBy = profile.id
                )
                stockTransactionDao.insert(trx)
                inventoryRequestLineDao.markIssued(line.id, line.requestedQuantity, line.requestedQuantity, now, profile.id)
                recalculateBalance(trx.companyId, trx.itemId, trx.warehouseId, profile.id)
                enqueue(trx.companyId, SyncEntityType.STOCK_TRANSACTION, trx.id, SyncOperationType.STOCK_TRANSACTION, trx.toPayload(), profile.id)
                transactions += trx
            }
            inventoryRequestDao.markIssued(
                id = request.id,
                status = InventoryRequestStatus.ISSUED,
                approvedBy = profile.id,
                approvedAt = now,
                issuedBy = profile.id,
                issuedAt = now,
                updatedAt = now,
                updatedBy = profile.id,
                syncStatus = SyncStatus.PENDING
            )
            enqueue(request.companyId, SyncEntityType.INVENTORY_REQUEST, request.id, SyncOperationType.UPDATE, request.copy(status = InventoryRequestStatus.ISSUED).toPayload(), profile.id)
            audit(request.companyId, "INVENTORY_REQUEST", request.id, AuditAction.APPROVE_MATERIAL_REQUEST, request.toPayload(), request.copy(status = InventoryRequestStatus.ISSUED).toPayload(), profile)
            transactions.forEach { trx -> audit(trx.companyId, "STOCK_TRANSACTION", trx.id, AuditAction.ISSUE_STOCK, null, trx.toPayload(), profile) }
        }
        return transactions
    }

    override suspend fun issueToWorkOrder(
        profile: UserEntity,
        workOrderId: String,
        itemId: String,
        warehouseId: String,
        quantity: Double,
        unitCost: Double,
        reason: String
    ): StockTransactionEntity {
        require(workOrderId.isNotBlank()) { "لا صرف بدون أمر عمل." }
        return postStockTransaction(profile, itemId, warehouseId, workOrderId, StockTransactionType.ISSUE_TO_WORK_ORDER, quantity, unitCost, reason.ifBlank { "صرف مباشر لأمر عمل" }, "الفني لا يصرف مباشرة.") { it.canIssueStock() }
    }

    override suspend fun returnFromWorkOrder(
        profile: UserEntity,
        workOrderId: String,
        itemId: String,
        warehouseId: String,
        quantity: Double,
        unitCost: Double,
        reason: String
    ): StockTransactionEntity {
        require(workOrderId.isNotBlank()) { "لا إرجاع بدون أمر عمل." }
        return postStockTransaction(profile, itemId, warehouseId, workOrderId, StockTransactionType.RETURN_FROM_WORK_ORDER, quantity, unitCost, reason.ifBlank { "إرجاع من أمر عمل" }, "لا يملك هذا الدور صلاحية الإرجاع." ) { it.canIssueStock() }
    }

    override suspend fun adjustStock(
        profile: UserEntity,
        itemId: String,
        warehouseId: String,
        quantity: Double,
        plus: Boolean,
        reason: String
    ): StockTransactionEntity {
        require(profile.role == UserRole.ADMIN) { "تعديل المخزون يتطلب صلاحية مدير." }
        require(reason.isNotBlank()) { "لا تعديل رصيد بدون سبب واعتماد." }
        return postStockTransaction(profile, itemId, warehouseId, null, if (plus) StockTransactionType.ADJUSTMENT_PLUS else StockTransactionType.ADJUSTMENT_MINUS, quantity, 0.0, reason, "تعديل المخزون يتطلب صلاحية مدير." ) { it == UserRole.ADMIN }
    }

    private suspend fun postStockTransaction(
        profile: UserEntity,
        itemId: String,
        warehouseId: String,
        workOrderId: String?,
        type: StockTransactionType,
        quantity: Double,
        unitCost: Double,
        reason: String,
        requiredRoleMessage: String,
        roleAllowed: (UserRole) -> Boolean
    ): StockTransactionEntity {
        require(roleAllowed(profile.role)) { requiredRoleMessage }
        require(quantity > 0.0) { "الكمية يجب أن تكون أكبر من صفر." }
        val item = itemDao.getById(itemId) ?: error("لا يمكن إنشاء حركة بدون Item Master.")
        warehouseDao.getById(warehouseId) ?: error("المخزن غير موجود.")
        if (type == StockTransactionType.ISSUE_TO_WORK_ORDER && workOrderId.isNullOrBlank()) {
            error("لا صرف بدون أمر عمل.")
        }
        if (type.isNegativeMovement()) {
            val available = stockTransactionDao.calculateBalance(profile.companyId, itemId, warehouseId)
            if (available < quantity) {
                error("لا يمكن تنفيذ الحركة لأن الرصيد غير كاف. المتاح=$available، المطلوب=$quantity.")
            }
        }
        val now = now()
        val transaction = StockTransactionEntity(
            id = id("st"),
            companyId = profile.companyId,
            transactionNo = nextNo(type.transactionPrefix()),
            itemId = item.id,
            warehouseId = warehouseId,
            workOrderId = workOrderId?.trim()?.takeIf { it.isNotBlank() },
            type = type,
            quantity = quantity,
            unitCost = unitCost.coerceAtLeast(0.0),
            totalCost = quantity * unitCost.coerceAtLeast(0.0),
            reason = reason.trim().takeIf { it.isNotBlank() },
            approvedBy = profile.id,
            approvedAt = now,
            transactionAt = now,
            createdAt = now,
            createdBy = profile.id,
            updatedAt = now,
            updatedBy = profile.id
        )
        database.withTransaction {
            stockTransactionDao.insert(transaction)
            recalculateBalance(transaction.companyId, transaction.itemId, transaction.warehouseId, profile.id)
            enqueue(transaction.companyId, SyncEntityType.STOCK_TRANSACTION, transaction.id, SyncOperationType.STOCK_TRANSACTION, transaction.toPayload(), profile.id)
            audit(transaction.companyId, "STOCK_TRANSACTION", transaction.id, type.auditAction(), null, transaction.toPayload(), profile)
        }
        return transaction
    }

    private suspend fun recalculateBalance(companyId: String, itemId: String, warehouseId: String, userId: String) {
        val item = itemDao.getById(itemId)
        val onHand = stockTransactionDao.calculateBalance(companyId, itemId, warehouseId)
        val now = now()
        val reserved = stockBalanceDao.getForItemWarehouse(companyId, itemId, warehouseId)?.reservedQuantity ?: 0.0
        val balance = StockBalanceEntity(
            id = balanceId(companyId, itemId, warehouseId),
            companyId = companyId,
            itemId = itemId,
            warehouseId = warehouseId,
            quantityOnHand = onHand,
            reservedQuantity = reserved,
            availableQuantity = onHand - reserved,
            minStockSnapshot = item?.minStock ?: 0.0,
            isBelowMinimum = item != null && onHand <= item.minStock,
            lastCalculatedAt = now,
            updatedAt = now,
            updatedBy = userId
        )
        stockBalanceDao.upsert(balance)
        enqueue(companyId, SyncEntityType.STOCK_BALANCE, balance.id, SyncOperationType.UPDATE, balance.toPayload(), userId, priority = 7)
    }

    private suspend fun enqueue(companyId: String, entityType: String, entityId: String, operation: SyncOperationType, payload: String, createdBy: String, priority: Int = 4) {
        syncQueueDao.enqueue(
            SyncQueueEntity(
                id = id("sync"),
                companyId = companyId,
                entityType = entityType,
                entityId = entityId,
                operationType = operation,
                payloadJson = payload,
                createdAt = now(),
                createdBy = createdBy,
                priority = priority
            )
        )
    }

    private suspend fun audit(companyId: String, entityType: String, entityId: String, action: AuditAction, oldJson: String?, newJson: String?, profile: UserEntity) {
        auditLogDao.insert(
            AuditLogEntity(
                id = id("audit"),
                companyId = companyId,
                entityType = entityType,
                entityId = entityId,
                action = action,
                oldValueJson = oldJson,
                newValueJson = newJson,
                performedBy = profile.id,
                performedByRole = profile.role,
                performedAt = now(),
                deviceId = "android-local",
                source = "ANDROID"
            )
        )
    }

    private fun UserRole.canMaintainItemMaster(): Boolean = this in setOf(UserRole.ADMIN, UserRole.MAINTENANCE_MANAGER, UserRole.WAREHOUSE)
    private fun UserRole.canMaintainInventory(): Boolean = this in setOf(UserRole.ADMIN, UserRole.WAREHOUSE)
    private fun UserRole.canIssueStock(): Boolean = this in setOf(UserRole.ADMIN, UserRole.WAREHOUSE)
    private fun UserRole.canRequestMaterial(): Boolean = this in setOf(UserRole.ADMIN, UserRole.MAINTENANCE_MANAGER, UserRole.SUPERVISOR, UserRole.TECHNICIAN)
    private fun StockTransactionType.isNegativeMovement(): Boolean = this in setOf(StockTransactionType.ISSUE_TO_WORK_ORDER, StockTransactionType.TRANSFER_OUT, StockTransactionType.ADJUSTMENT_MINUS, StockTransactionType.RESERVATION)
    private fun StockTransactionType.transactionPrefix(): String = when (this) {
        StockTransactionType.OPENING -> "OPN"
        StockTransactionType.RECEIPT -> "REC"
        StockTransactionType.ISSUE_TO_WORK_ORDER -> "ISS"
        StockTransactionType.RETURN_FROM_WORK_ORDER -> "RET"
        StockTransactionType.TRANSFER_IN -> "TIN"
        StockTransactionType.TRANSFER_OUT -> "TOU"
        StockTransactionType.ADJUSTMENT_PLUS -> "ADP"
        StockTransactionType.ADJUSTMENT_MINUS -> "ADM"
        StockTransactionType.RESERVATION -> "RSV"
        StockTransactionType.RESERVATION_CANCEL -> "RSC"
    }
    private fun StockTransactionType.auditAction(): AuditAction = when (this) {
        StockTransactionType.ISSUE_TO_WORK_ORDER -> AuditAction.ISSUE_STOCK
        StockTransactionType.RETURN_FROM_WORK_ORDER -> AuditAction.RETURN_STOCK
        StockTransactionType.ADJUSTMENT_PLUS, StockTransactionType.ADJUSTMENT_MINUS -> AuditAction.ADJUST_STOCK
        else -> AuditAction.ADJUST_STOCK
    }

    private fun now(): Long = System.currentTimeMillis()
    private fun id(prefix: String): String = "$prefix-${UUID.randomUUID()}"
    private fun nextNo(prefix: String): String = "$prefix-${now()}"
    private fun balanceId(companyId: String, itemId: String, warehouseId: String): String = "$companyId-$itemId-$warehouseId"

    private fun String.escaped(): String = replace("\\", "\\\\").replace("\"", "\\\"")
    private fun kv(key: String, value: String?): String = "\"$key\":${value?.let { "\"${it.escaped()}\"" } ?: "null"}"
    private fun kv(key: String, value: Number): String = "\"$key\":$value"
    private fun kv(key: String, value: Boolean): String = "\"$key\":$value"

    private fun ItemEntity.toPayload(): String = "{" + listOf(kv("id", id), kv("companyId", companyId), kv("itemCode", itemCode), kv("itemName", itemName), kv("unit", unit), kv("category", category), kv("isCriticalSpare", isCriticalSpare), kv("minStock", minStock), kv("version", version)).joinToString(",") + "}"
    private fun WarehouseEntity.toPayload(): String = "{" + listOf(kv("id", id), kv("companyId", companyId), kv("warehouseCode", warehouseCode), kv("warehouseName", warehouseName), kv("isMain", isMain), kv("version", version)).joinToString(",") + "}"
    private fun StockBalanceEntity.toPayload(): String = "{" + listOf(kv("id", id), kv("companyId", companyId), kv("itemId", itemId), kv("warehouseId", warehouseId), kv("quantityOnHand", quantityOnHand), kv("reservedQuantity", reservedQuantity), kv("availableQuantity", availableQuantity), kv("isBelowMinimum", isBelowMinimum)).joinToString(",") + "}"
    private fun StockTransactionEntity.toPayload(): String = "{" + listOf(kv("id", id), kv("companyId", companyId), kv("transactionNo", transactionNo), kv("itemId", itemId), kv("warehouseId", warehouseId), kv("workOrderId", workOrderId), kv("type", type.name), kv("quantity", quantity), kv("unitCost", unitCost), kv("totalCost", totalCost), kv("reason", reason), kv("transactionAt", transactionAt)).joinToString(",") + "}"
    private fun InventoryRequestEntity.toPayload(): String = "{" + listOf(kv("id", id), kv("companyId", companyId), kv("requestNo", requestNo), kv("type", type.name), kv("status", status.name), kv("workOrderId", workOrderId), kv("requestedBy", requestedBy), kv("lineCount", lineCount), kv("version", version)).joinToString(",") + "}"
    private fun InventoryRequestLineEntity.toPayload(): String = "{" + listOf(kv("id", id), kv("companyId", companyId), kv("requestId", requestId), kv("workOrderId", workOrderId), kv("itemId", itemId), kv("warehouseId", warehouseId), kv("requestedQuantity", requestedQuantity), kv("approvedQuantity", approvedQuantity), kv("issuedQuantity", issuedQuantity)).joinToString(",") + "}"
    private fun WorkOrderMaterialEntity.toPayload(): String = "{" + listOf(kv("id", id), kv("companyId", companyId), kv("workOrderId", workOrderId), kv("itemId", itemId), kv("warehouseId", warehouseId), kv("requestedQuantity", requestedQuantity), kv("issuedQuantity", issuedQuantity), kv("inventoryRequestId", inventoryRequestId)).joinToString(",") + "}"
}
