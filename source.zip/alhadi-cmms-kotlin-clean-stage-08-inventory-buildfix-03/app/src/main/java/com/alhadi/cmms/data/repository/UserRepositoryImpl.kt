package com.alhadi.cmms.data.repository

import com.alhadi.cmms.database.dao.UserDao
import com.alhadi.cmms.database.entity.UserEntity
import com.alhadi.cmms.domain.repository.UserRepository
import kotlinx.coroutines.flow.Flow

class UserRepositoryImpl(
    private val userDao: UserDao
) : UserRepository {
    override fun observeUser(userId: String): Flow<UserEntity?> = userDao.observeById(userId)

    override fun observeCompanyUsers(companyId: String): Flow<List<UserEntity>> = userDao.observeCompanyUsers(companyId)

    override suspend fun getUser(userId: String): UserEntity? = userDao.getById(userId)

    override suspend fun cacheUserProfile(user: UserEntity) = userDao.upsert(user)
}
