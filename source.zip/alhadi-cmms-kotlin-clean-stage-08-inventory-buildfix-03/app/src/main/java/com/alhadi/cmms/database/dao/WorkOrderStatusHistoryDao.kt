package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.alhadi.cmms.database.entity.WorkOrderStatusHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkOrderStatusHistoryDao {
    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insert(history: WorkOrderStatusHistoryEntity)

    @Query("SELECT * FROM work_order_status_history WHERE companyId = :companyId AND workOrderId = :workOrderId AND isDeleted = 0 ORDER BY changedAt DESC")
    fun observeForWorkOrder(companyId: String, workOrderId: String): Flow<List<WorkOrderStatusHistoryEntity>>

    @Query("SELECT * FROM work_order_status_history WHERE companyId = :companyId AND workOrderId = :workOrderId AND isDeleted = 0 ORDER BY changedAt DESC")
    suspend fun listForWorkOrder(companyId: String, workOrderId: String): List<WorkOrderStatusHistoryEntity>

    @Query("SELECT * FROM work_order_status_history WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): WorkOrderStatusHistoryEntity?
}
