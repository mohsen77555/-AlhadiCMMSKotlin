package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.alhadi.cmms.core.model.WorkRequestStatus
import com.alhadi.cmms.database.entity.WorkRequestEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkRequestDao {
    @Upsert
    suspend fun upsert(request: WorkRequestEntity)

    @Upsert
    suspend fun upsertAll(requests: List<WorkRequestEntity>)

    @Query("SELECT * FROM work_requests WHERE id = :id AND isDeleted = 0 LIMIT 1")
    suspend fun getById(id: String): WorkRequestEntity?

    @Query("SELECT * FROM work_requests WHERE id = :id AND isDeleted = 0 LIMIT 1")
    fun observeById(id: String): Flow<WorkRequestEntity?>

    @Query("SELECT * FROM work_requests WHERE companyId = :companyId AND requestedBy = :requestedBy AND isDeleted = 0 ORDER BY createdAt DESC")
    fun observeForRequester(companyId: String, requestedBy: String): Flow<List<WorkRequestEntity>>

    @Query("SELECT * FROM work_requests WHERE companyId = :companyId AND isDeleted = 0 ORDER BY createdAt DESC")
    fun observeForCompany(companyId: String): Flow<List<WorkRequestEntity>>

    @Query("UPDATE work_requests SET status = :status, updatedAt = :updatedAt, updatedBy = :updatedBy, version = version + 1 WHERE id = :id AND isDeleted = 0")
    suspend fun updateStatus(id: String, status: WorkRequestStatus, updatedAt: Long, updatedBy: String)

    @Query("UPDATE work_requests SET isDeleted = 1, deletedAt = :deletedAt, deletedBy = :deletedBy, updatedAt = :deletedAt, updatedBy = :deletedBy WHERE id = :id")
    suspend fun softDelete(id: String, deletedAt: Long, deletedBy: String)
}
