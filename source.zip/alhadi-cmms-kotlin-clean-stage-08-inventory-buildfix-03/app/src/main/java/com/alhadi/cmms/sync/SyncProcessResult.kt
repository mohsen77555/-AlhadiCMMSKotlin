package com.alhadi.cmms.sync

data class SyncProcessResult(
    val scanned: Int = 0,
    val synced: Int = 0,
    val failed: Int = 0,
    val conflicts: Int = 0,
    val skipped: Int = 0
) {
    val hasWork: Boolean get() = scanned > 0
    val hasRetriableFailures: Boolean get() = failed > 0
}
