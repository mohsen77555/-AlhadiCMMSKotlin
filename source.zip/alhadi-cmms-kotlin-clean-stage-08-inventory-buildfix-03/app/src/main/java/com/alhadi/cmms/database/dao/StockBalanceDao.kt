package com.alhadi.cmms.database.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.alhadi.cmms.database.entity.StockBalanceEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StockBalanceDao {
    @Upsert
    suspend fun upsert(balance: StockBalanceEntity)

    @Query("SELECT * FROM stock_balances WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): StockBalanceEntity?

    @Query("SELECT * FROM stock_balances WHERE companyId = :companyId ORDER BY isBelowMinimum DESC, updatedAt DESC")
    fun observeForCompany(companyId: String): Flow<List<StockBalanceEntity>>

    @Query("SELECT * FROM stock_balances WHERE companyId = :companyId AND itemId = :itemId AND warehouseId = :warehouseId LIMIT 1")
    suspend fun getForItemWarehouse(companyId: String, itemId: String, warehouseId: String): StockBalanceEntity?
}
