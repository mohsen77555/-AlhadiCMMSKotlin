@echo off
where gradle >nul 2>nul
if %errorlevel%==0 (
  gradle %*
  exit /b %errorlevel%
)
echo Gradle executable was not found.
echo This project is designed to build in GitHub Actions through gradle/actions/setup-gradle.
echo For local builds, install Gradle 9.4.1 or add a standard Gradle Wrapper jar.
exit /b 1
