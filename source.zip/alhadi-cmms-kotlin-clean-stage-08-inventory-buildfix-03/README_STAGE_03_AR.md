# Alhadi CMMS Kotlin — Stage 03

## الهدف

هذه المرحلة تضيف تسجيل الدخول الحقيقي بواسطة Firebase Auth وقراءة ملف المستخدم الحقيقي من Firestore قبل فتح أي واجهة دور.

## المنفذ في هذه المرحلة

- إضافة Firebase Auth.
- إضافة Cloud Firestore لقراءة ملف المستخدم.
- قراءة ملف الصلاحيات من:
  - `users/{uid}`
- عدم فتح أي واجهة دور قبل تحميل البروفايل الحقيقي.
- منع الرجوع إلى دور افتراضي مثل طالب خدمة عند تأخر تحميل الدور.
- شاشة خطأ واضحة إذا لم يوجد ملف صلاحيات للمستخدم.
- تخزين ملف المستخدم في Room بعد تحميله.
- تحديث Login Screen لتسجيل الدخول الحقيقي.
- تحديث Loading Permissions Screen.
- إضافة شاشة Role Ready مؤقتة فقط لإثبات تحميل الدور، وستستبدل بواجهات الأدوار في Stage 04.
- إضافة `google-services.json.example`.
- تحديث GitHub Actions ليبني APK حتى عند غياب `google-services.json` الحقيقي باستخدام placeholder للبناء فقط.

## ملاحظات مهمة

للتشغيل الحقيقي مع Firebase يجب إضافة الملف الحقيقي:

```text
app/google-services.json
```

إذا لم تضف الملف الحقيقي، سيبني GitHub APK للتأكد من صحة الكود، لكن تسجيل الدخول الحقيقي لن يعمل لأن الإعدادات ستكون placeholder.

## صيغة مستند المستخدم المطلوبة في Firestore

المسار:

```text
users/{uid}
```

الحقول الأساسية:

```json
{
  "companyId": "company-001",
  "email": "tech@example.com",
  "displayName": "اسم الفني",
  "role": "TECHNICIAN",
  "isActive": true,
  "permissionsJson": "{}",
  "createdAt": 0,
  "createdBy": "system",
  "updatedAt": 0,
  "updatedBy": "system",
  "isDeleted": false,
  "version": 1,
  "syncVersion": 0
}
```

الأدوار يجب أن تكون بالإنجليزية فقط:

```text
ADMIN
MAINTENANCE_MANAGER
SUPERVISOR
TECHNICIAN
WAREHOUSE
REQUESTER
VIEWER
```

## غير منفذ الآن حسب الخطة

- واجهات الدور التفصيلية: Stage 04.
- أوامر العمل: Stage 05.
- Snapshot Listeners: Stage 06.
- WorkManager Sync Queue: Stage 07.
- المخزون: Stage 08.
- Security Rules: Stage 13.
