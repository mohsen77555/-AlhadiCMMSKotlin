# Stage 08 Build Fix 02 — إصلاح فشل compileDebugKotlin

هذه النسخة تعالج فشل بناء Stage 08 الذي ظهر في GitHub Actions عند مهمة:

```text
:app:compileDebugKotlin
```

## الهدف

إبقاء Stage 08 للمخزون، لكن بإصلاح طبقة Kotlin/Compose التي كانت تمنع إنتاج APK.

## ما تم

- إعادة ضبط واجهة المخزون لتكون أكثر تحفظًا في Compose.
- ربط شاشة المخزون مع ViewModel وRepository بأسماء دوال متطابقة.
- إضافة/تثبيت كيانات وDAO الخاصة بـ:
  - `work_order_materials`
  - `inventory_requests`
  - `inventory_request_lines`
  - `stock_balances`
  - `stock_transactions`
  - `warehouses`
- الحفاظ على واجهة Stage 07.2 الحديثة.
- الحفاظ على Firebase Auth / Firestore / SyncQueue / WorkManager.
- عدم البدء في Stage 09.

## طريقة الاستخدام

ارفع هذا الملف في GitHub باسم:

```text
source.zip
```

واترك ملف Firebase الصحيح:

```text
google-services.json
```

ثم شغّل GitHub Actions.
