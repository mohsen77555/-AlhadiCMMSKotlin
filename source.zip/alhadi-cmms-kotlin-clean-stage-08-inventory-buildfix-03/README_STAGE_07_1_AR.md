# Alhadi CMMS — Stage 07.1 UI/UX Refresh

هذه مرحلة وسيطة قبل Stage 08 لمعالجة ملاحظات تجربة المستخدم بعد نجاح تسجيل الدخول والصلاحيات.

## الهدف
- إزالة عرض أرقام المراحل من واجهة المستخدم الأساسية.
- جعل بطاقات الشاشات قابلة للضغط وتفتح محتوى منظمًا.
- إضافة Dashboard حديثة حسب الدور.
- إضافة مؤشرات مرئية أولية KPI + Donut + Progress Bars.
- تحسين شكل واجهة المدير والفني والمخزن وباقي الأدوار بدون تغيير قواعد Firebase/Room.

## ما لم يتغير
- لا يزال التطبيق Native Kotlin + Jetpack Compose.
- لا يوجد WebView أو Capacitor.
- لا تزال الشاشة تقرأ من Room/Repository وليس Firebase مباشرة.
- بقي Firebase Auth وقراءة users/{uid} كما في Stage 07 v5.
- بقي WorkManager وSyncQueue كما في Stage 07.

## طريقة البناء
ارفع هذا الملف إلى GitHub باسم `source.zip` مع ملف `google-services.json` الصحيح في جذر المستودع، ثم شغّل GitHub Actions.

## ملاحظة
لا تزال بعض الشاشات Preview منظمة حتى يتم ربطها بالبيانات في مراحلها، لكن الواجهة الآن قابلة للتنقل والضغط بشكل واضح بدل عرض Placeholder جامد.
