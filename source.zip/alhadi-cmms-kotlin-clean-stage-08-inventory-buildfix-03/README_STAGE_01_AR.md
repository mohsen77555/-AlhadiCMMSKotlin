# Alhadi CMMS - Kotlin Native - Stage 01

هذه نسخة بداية نظيفة وفق التعليمات الجديدة، وليست امتدادًا للشاشات التجريبية السابقة.

## هدف المرحلة

تنفيذ المرحلة الأولى فقط:

- مشروع Android Kotlin Native.
- Jetpack Compose.
- Material 3.
- Navigation Compose.
- شاشة Splash.
- شاشة Login.
- شاشة Loading Permissions.
- enum للأدوار `UserRole` بقيم إنجليزية فقط.
- enum للمسارات `AppRoute`.
- هيكل المجلدات الكامل.
- GitHub Actions يبني APK حقيقي.
- ملفي تدقيق.

## ما لم يتم إضافته عمدًا في هذه المرحلة

- Room Database.
- Firebase Auth.
- Firestore.
- Firebase Storage.
- WorkManager.
- واجهات المدير والفني والمخزن وطالب الخدمة.
- أوامر العمل والمخزون والأصول.

هذه العناصر محفوظة في خارطة المراحل ولن تنفذ قبل مرحلة كل عنصر.

## البناء عبر GitHub Actions

المسار المتوقع للـ APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

اسم الـ Artifact:

```text
Alhadi-CMMS-debug.apk
```

## قاعدة مهمة

لا يوجد WebView، ولا Capacitor، ولا HTML داخل APK.
