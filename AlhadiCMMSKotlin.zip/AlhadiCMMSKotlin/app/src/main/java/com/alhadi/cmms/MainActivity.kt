package com.alhadi.cmms

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.core.view.WindowCompat
import com.alhadi.cmms.ui.AlhadiTheme
import com.alhadi.cmms.ui.CmmsApp
import com.alhadi.cmms.viewmodel.CmmsViewModel
import com.alhadi.cmms.viewmodel.CmmsViewModelFactory

class MainActivity : ComponentActivity() {
    private val viewModel: CmmsViewModel by viewModels {
        CmmsViewModelFactory((application as AlhadiApplication).repository)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContent {
            AlhadiTheme {
                CmmsApp(viewModel = viewModel)
            }
        }
    }
}
