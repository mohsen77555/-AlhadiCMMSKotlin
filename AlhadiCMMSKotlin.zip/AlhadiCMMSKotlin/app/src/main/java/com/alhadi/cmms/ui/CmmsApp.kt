package com.alhadi.cmms.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.alhadi.cmms.data.entity.AssetEntity
import com.alhadi.cmms.data.entity.InventoryTransactionEntity
import com.alhadi.cmms.data.entity.PreventiveMaintenanceEntity
import com.alhadi.cmms.data.entity.SparePartEntity
import com.alhadi.cmms.data.entity.UserEntity
import com.alhadi.cmms.data.entity.WorkOrderEntity
import com.alhadi.cmms.util.DateStrings
import com.alhadi.cmms.viewmodel.CmmsViewModel
import com.alhadi.cmms.viewmodel.DashboardStats
import java.util.Locale

private enum class AppSection(
    val arabicTitle: String,
    val englishTitle: String,
    val shortLabel: String
) {
    Dashboard("الرئيسية", "Dashboard", "D"),
    Assets("الأصول", "Assets", "A"),
    WorkOrders("أوامر العمل", "Work Orders", "WO"),
    PreventiveMaintenance("الصيانة الدورية", "Preventive Maintenance", "PM"),
    Inventory("المخزون", "Inventory", "INV"),
    Reports("التقارير", "Reports", "R"),
    Admin("الإدارة", "Admin", "AD")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CmmsApp(viewModel: CmmsViewModel) {
    val stats by viewModel.dashboardStats.collectAsStateWithLifecycle()
    val assets by viewModel.assets.collectAsStateWithLifecycle()
    val workOrders by viewModel.workOrders.collectAsStateWithLifecycle()
    val preventiveMaintenance by viewModel.preventiveMaintenance.collectAsStateWithLifecycle()
    val spareParts by viewModel.spareParts.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val users by viewModel.users.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val message by viewModel.message.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var selectedSection by rememberSaveable { mutableStateOf(AppSection.Dashboard) }

    val visibleSections = remember(currentUser) {
        AppSection.entries.filter { section ->
            section != AppSection.Admin || currentUser?.isAdmin == true
        }
    }

    LaunchedEffect(visibleSections) {
        if (selectedSection !in visibleSections) selectedSection = AppSection.Dashboard
    }

    LaunchedEffect(message) {
        val text = message
        if (!text.isNullOrBlank()) {
            snackbarHostState.showSnackbar(text)
            viewModel.clearMessage()
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(selectedSection.arabicTitle, fontWeight = FontWeight.Bold)
                            Text(
                                text = "Alhadi CMMS • ${currentUser?.role ?: "Loading"}",
                                style = MaterialTheme.typography.labelMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            bottomBar = {
                NavigationBar {
                    visibleSections.forEach { section ->
                        NavigationBarItem(
                            selected = selectedSection == section,
                            onClick = { selectedSection = section },
                            icon = { Text(section.shortLabel, fontWeight = FontWeight.Bold) },
                            label = { Text(section.arabicTitle, maxLines = 1) }
                        )
                    }
                }
            },
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
        ) { innerPadding ->
            val assetMap = assets.associateBy { it.id }
            when (selectedSection) {
                AppSection.Dashboard -> DashboardScreen(
                    innerPadding = innerPadding,
                    stats = stats,
                    assets = assets,
                    workOrders = workOrders,
                    parts = spareParts,
                    pmItems = preventiveMaintenance,
                    onCreateWorkOrder = viewModel::createDemoWorkOrder
                )

                AppSection.Assets -> AssetsScreen(
                    innerPadding = innerPadding,
                    assets = assets
                )

                AppSection.WorkOrders -> WorkOrdersScreen(
                    innerPadding = innerPadding,
                    workOrders = workOrders,
                    assetMap = assetMap,
                    onCreateWorkOrder = viewModel::createDemoWorkOrder,
                    onUpdateStatus = viewModel::updateWorkOrderStatus
                )

                AppSection.PreventiveMaintenance -> PreventiveMaintenanceScreen(
                    innerPadding = innerPadding,
                    pmItems = preventiveMaintenance,
                    assetMap = assetMap,
                    onDone = viewModel::markPreventiveMaintenanceDone
                )

                AppSection.Inventory -> InventoryScreen(
                    innerPadding = innerPadding,
                    parts = spareParts,
                    transactions = transactions,
                    onIssue = viewModel::issuePart,
                    onReceive = viewModel::receivePart
                )

                AppSection.Reports -> ReportsScreen(
                    innerPadding = innerPadding,
                    stats = stats,
                    workOrders = workOrders,
                    parts = spareParts,
                    pmItems = preventiveMaintenance
                )

                AppSection.Admin -> AdminScreen(
                    innerPadding = innerPadding,
                    users = users,
                    currentUser = currentUser,
                    onAddTechnician = viewModel::addTechnician,
                    onResetSampleData = viewModel::resetSampleData
                )
            }
        }
    }
}

@Composable
private fun DashboardScreen(
    innerPadding: PaddingValues,
    stats: DashboardStats,
    assets: List<AssetEntity>,
    workOrders: List<WorkOrderEntity>,
    parts: List<SparePartEntity>,
    pmItems: List<PreventiveMaintenanceEntity>,
    onCreateWorkOrder: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "لوحة تحكم الصيانة",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "تطبيق أوفلاين لإدارة الأصول، أوامر العمل، الصيانة الدورية وقطع الغيار.",
                style = MaterialTheme.typography.bodyMedium
            )
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                item { DashboardMetricCard("الأصول", stats.assets.toString(), "Assets") }
                item { DashboardMetricCard("أوامر مفتوحة", stats.openWorkOrders.toString(), "Open WO") }
                item { DashboardMetricCard("PM مستحقة", stats.duePm.toString(), "Due PM") }
                item { DashboardMetricCard("نقص مخزون", stats.lowStock.toString(), "Low Stock") }
            }
        }

        item {
            ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SectionTitle("إجراءات سريعة")
                    Button(onClick = onCreateWorkOrder, modifier = Modifier.fillMaxWidth()) {
                        Text("إنشاء أمر عمل تجريبي")
                    }
                    Text(
                        text = "يمكنك تعديل هذا الزر لاحقًا لفتح نموذج كامل لإدخال أمر العمل.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        item { SectionTitle("تنبيهات مهمة") }

        val warningAssets = assets.filter { it.status != "Running" }.take(4)
        if (warningAssets.isEmpty() && stats.lowStock == 0 && stats.duePm == 0) {
            item { EmptyState("لا توجد تنبيهات حاليًا") }
        } else {
            items(warningAssets, key = { "asset-${it.id}" }) { asset ->
                AlertCard(
                    title = "${asset.code} • ${asset.name}",
                    body = "الحالة: ${asset.status}، الموقع: ${asset.location}"
                )
            }
            val lowStockParts = parts.filter { it.onHandQty <= it.minQty }.take(4)
            items(lowStockParts, key = { "part-${it.id}" }) { part ->
                AlertCard(
                    title = "${part.partNumber} • ${part.name}",
                    body = "المتوفر ${part.onHandQty} ${part.unit}، الحد الأدنى ${part.minQty}"
                )
            }
            val duePm = pmItems.filter { DateStrings.isDueOrOverdue(it.nextDueAt) }.take(4)
            items(duePm, key = { "pm-${it.id}" }) { pm ->
                AlertCard(
                    title = pm.title,
                    body = "مستحقة بتاريخ ${pm.nextDueAt}"
                )
            }
        }

        item { SectionTitle("آخر أوامر العمل") }
        items(workOrders.take(5), key = { "wo-${it.id}" }) { workOrder ->
            CompactWorkOrderCard(workOrder)
        }
    }
}

@Composable
private fun AssetsScreen(innerPadding: PaddingValues, assets: List<AssetEntity>) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(query, assets) {
        if (query.isBlank()) assets else assets.filter { asset ->
            val q = query.lowercase(Locale.getDefault())
            asset.code.lowercase(Locale.getDefault()).contains(q) ||
                asset.name.lowercase(Locale.getDefault()).contains(q) ||
                asset.groupName.lowercase(Locale.getDefault()).contains(q) ||
                asset.location.lowercase(Locale.getDefault()).contains(q)
        }
    }
    val grouped = filtered.groupBy { it.groupName }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("بحث في الأصول") },
                placeholder = { Text("مثال: RM-01 أو Rollermill") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }

        if (filtered.isEmpty()) {
            item { EmptyState("لا توجد أصول مطابقة للبحث") }
        }

        grouped.forEach { (group, groupAssets) ->
            item { SectionTitle(group) }
            items(groupAssets, key = { it.id }) { asset -> AssetCard(asset) }
        }
    }
}

@Composable
private fun WorkOrdersScreen(
    innerPadding: PaddingValues,
    workOrders: List<WorkOrderEntity>,
    assetMap: Map<Long, AssetEntity>,
    onCreateWorkOrder: () -> Unit,
    onUpdateStatus: (WorkOrderEntity, String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Button(onClick = onCreateWorkOrder, modifier = Modifier.fillMaxWidth()) {
                Text("+ أمر عمل جديد")
            }
        }

        if (workOrders.isEmpty()) {
            item { EmptyState("لا توجد أوامر عمل") }
        }

        items(workOrders, key = { it.id }) { workOrder ->
            WorkOrderCard(
                workOrder = workOrder,
                asset = assetMap[workOrder.assetId],
                onUpdateStatus = onUpdateStatus
            )
        }
    }
}

@Composable
private fun PreventiveMaintenanceScreen(
    innerPadding: PaddingValues,
    pmItems: List<PreventiveMaintenanceEntity>,
    assetMap: Map<Long, AssetEntity>,
    onDone: (PreventiveMaintenanceEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "جدول الصيانة الدورية",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text("المهام مرتبة حسب أقرب تاريخ استحقاق.")
        }

        if (pmItems.isEmpty()) {
            item { EmptyState("لا توجد مهام صيانة دورية") }
        }

        items(pmItems, key = { it.id }) { item ->
            PreventiveMaintenanceCard(
                item = item,
                asset = assetMap[item.assetId],
                onDone = onDone
            )
        }
    }
}

@Composable
private fun InventoryScreen(
    innerPadding: PaddingValues,
    parts: List<SparePartEntity>,
    transactions: List<InventoryTransactionEntity>,
    onIssue: (SparePartEntity) -> Unit,
    onReceive: (SparePartEntity) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    val filtered = remember(query, parts) {
        if (query.isBlank()) parts else parts.filter { part ->
            val q = query.lowercase(Locale.getDefault())
            part.partNumber.lowercase(Locale.getDefault()).contains(q) ||
                part.name.lowercase(Locale.getDefault()).contains(q) ||
                part.equipmentGroup.lowercase(Locale.getDefault()).contains(q)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("بحث في قطع الغيار") },
                placeholder = { Text("مثال: BRG-6205 أو Sensor") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )
        }

        item { SectionTitle("قطع الغيار") }
        if (filtered.isEmpty()) {
            item { EmptyState("لا توجد قطع غيار مطابقة") }
        }
        items(filtered, key = { it.id }) { part ->
            SparePartCard(
                part = part,
                onIssue = onIssue,
                onReceive = onReceive
            )
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            SectionTitle("آخر حركات المخزون")
        }

        if (transactions.isEmpty()) {
            item { EmptyState("لا توجد حركات مخزون") }
        }
        items(transactions, key = { it.id }) { transaction ->
            TransactionCard(transaction = transaction)
        }
    }
}

@Composable
private fun ReportsScreen(
    innerPadding: PaddingValues,
    stats: DashboardStats,
    workOrders: List<WorkOrderEntity>,
    parts: List<SparePartEntity>,
    pmItems: List<PreventiveMaintenanceEntity>
) {
    val openCost = workOrders.filter { it.status != "Closed" }.sumOf { it.estimatedCost }
    val closed = workOrders.count { it.status == "Closed" }
    val lowStock = parts.filter { it.onHandQty <= it.minQty }
    val duePm = pmItems.filter { DateStrings.isDueOrOverdue(it.nextDueAt) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "تقارير مختصرة",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text("هذه شاشة جاهزة للتوسعة لاحقًا لتصدير PDF أو Excel.")
        }
        item {
            ReportCard(
                title = "ملخص الصيانة",
                lines = listOf(
                    "إجمالي الأصول: ${stats.assets}",
                    "أوامر العمل المفتوحة: ${stats.openWorkOrders}",
                    "أوامر العمل المغلقة: $closed",
                    "تكلفة تقديرية مفتوحة: ${"%.2f".format(openCost)}"
                )
            )
        }
        item {
            ReportCard(
                title = "الصيانة الدورية",
                lines = listOf(
                    "مهام PM المستحقة: ${duePm.size}",
                    "أقرب مهمة: ${duePm.firstOrNull()?.title ?: "لا يوجد"}"
                )
            )
        }
        item {
            ReportCard(
                title = "المخزون",
                lines = listOf(
                    "قطع تحت الحد الأدنى: ${lowStock.size}",
                    "أول قطعة ناقصة: ${lowStock.firstOrNull()?.partNumber ?: "لا يوجد"}"
                )
            )
        }
    }
}

@Composable
private fun AdminScreen(
    innerPadding: PaddingValues,
    users: List<UserEntity>,
    currentUser: UserEntity?,
    onAddTechnician: () -> Unit,
    onResetSampleData: () -> Unit
) {
    if (currentUser?.isAdmin != true) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.Center
        ) {
            EmptyState("هذه الصفحة للمدير فقط")
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "إعدادات المدير",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text("صفحة الإدارة تظهر فقط عندما يكون المستخدم الحالي Admin.")
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = onAddTechnician, modifier = Modifier.weight(1f)) {
                    Text("إضافة فني")
                }
                OutlinedButton(onClick = onResetSampleData, modifier = Modifier.weight(1f)) {
                    Text("Reset Demo")
                }
            }
        }
        item { SectionTitle("المستخدمون") }
        items(users, key = { it.id }) { user ->
            UserCard(user)
        }
    }
}

@Composable
private fun DashboardMetricCard(title: String, value: String, subtitle: String) {
    ElevatedCard(
        modifier = Modifier.sizeIn(minWidth = 148.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(
                value,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            LtrText(subtitle, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun AssetCard(asset: AssetEntity) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    LtrText(asset.code, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    LtrText(asset.name, style = MaterialTheme.typography.bodyLarge)
                }
                StatusChip(asset.status)
            }
            HorizontalDivider()
            InfoRow("المجموعة", asset.groupName)
            InfoRow("الموقع", asset.location)
            InfoRow("الشركة/الموديل", "${asset.manufacturer} • ${asset.model}")
            InfoRow("الأهمية", asset.criticality)
            InfoRow("آخر فحص", asset.lastInspectionAt)
        }
    }
}

@Composable
private fun CompactWorkOrderCard(workOrder: WorkOrderEntity) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(workOrder.title, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusChip(workOrder.status)
                PriorityChip(workOrder.priority)
            }
            Text("الاستحقاق: ${workOrder.dueAt}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun WorkOrderCard(
    workOrder: WorkOrderEntity,
    asset: AssetEntity?,
    onUpdateStatus: (WorkOrderEntity, String) -> Unit
) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(workOrder.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    LtrText(asset?.let { "${it.code} • ${it.name}" } ?: "Asset #${workOrder.assetId}")
                }
                StatusChip(workOrder.status)
            }
            Text(workOrder.description)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PriorityChip(workOrder.priority)
                AssistChip(onClick = {}, label = { Text("المسؤول: ${workOrder.assignedTo}") })
            }
            InfoRow("تاريخ الإنشاء", workOrder.createdAt)
            InfoRow("تاريخ الاستحقاق", workOrder.dueAt)
            InfoRow("التكلفة التقديرية", "${"%.2f".format(workOrder.estimatedCost)}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                if (workOrder.status == "Open") {
                    OutlinedButton(
                        onClick = { onUpdateStatus(workOrder, "In Progress") },
                        modifier = Modifier.weight(1f)
                    ) { Text("بدء") }
                }
                if (workOrder.status != "Closed") {
                    Button(
                        onClick = { onUpdateStatus(workOrder, "Closed") },
                        modifier = Modifier.weight(1f)
                    ) { Text("إغلاق") }
                } else {
                    AssistChip(onClick = {}, label = { Text("مغلق") })
                }
            }
        }
    }
}

@Composable
private fun PreventiveMaintenanceCard(
    item: PreventiveMaintenanceEntity,
    asset: AssetEntity?,
    onDone: (PreventiveMaintenanceEntity) -> Unit
) {
    val due = DateStrings.isDueOrOverdue(item.nextDueAt)
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(item.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    LtrText(asset?.let { "${it.code} • ${it.name}" } ?: "Asset #${item.assetId}")
                }
                AssistChip(onClick = {}, label = { Text(if (due) "مستحقة" else "مجدولة") })
            }
            InfoRow("التكرار", "كل ${item.frequencyDays} يوم")
            InfoRow("آخر تنفيذ", item.lastDoneAt)
            InfoRow("التنفيذ القادم", item.nextDueAt)
            InfoRow("المدة المقدرة", "${item.estimatedDurationMinutes} دقيقة")
            Button(onClick = { onDone(item) }, modifier = Modifier.fillMaxWidth()) {
                Text("تم التنفيذ")
            }
        }
    }
}

@Composable
private fun SparePartCard(
    part: SparePartEntity,
    onIssue: (SparePartEntity) -> Unit,
    onReceive: (SparePartEntity) -> Unit
) {
    val lowStock = part.onHandQty <= part.minQty
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f)) {
                    LtrText(part.partNumber, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text(part.name)
                }
                AssistChip(onClick = {}, label = { Text(if (lowStock) "منخفض" else "متوفر") })
            }
            InfoRow("المعدة", part.equipmentGroup)
            InfoRow("الكمية", "${part.onHandQty} ${part.unit}")
            InfoRow("الحد الأدنى", "${part.minQty} ${part.unit}")
            InfoRow("الموقع", part.location)
            InfoRow("آخر سعر", "${"%.2f".format(part.lastPrice)}")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(onClick = { onIssue(part) }, modifier = Modifier.weight(1f)) {
                    Text("صرف -1")
                }
                Button(onClick = { onReceive(part) }, modifier = Modifier.weight(1f)) {
                    Text("استلام +1")
                }
            }
        }
    }
}

@Composable
private fun TransactionCard(transaction: InventoryTransactionEntity) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (transaction.transactionType == "Issue") "صرف" else "استلام",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                LtrText("Part #${transaction.partId}")
            }
            Text("الكمية: ${transaction.quantity}")
            Text("التاريخ: ${transaction.createdAt} • بواسطة: ${transaction.createdBy}")
            Text(transaction.note, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun ReportCard(title: String, lines: List<String>) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SectionTitle(title)
            lines.forEach { line -> Text("• $line") }
        }
    }
}

@Composable
private fun UserCard(user: UserEntity) {
    ElevatedCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(user.name, fontWeight = FontWeight.Bold)
                LtrText("@${user.username}", style = MaterialTheme.typography.bodySmall)
            }
            AssistChip(onClick = {}, label = { Text(user.role) })
        }
    }
}

@Composable
private fun AlertCard(title: String, body: String) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            LtrText(title, fontWeight = FontWeight.Bold)
            Text(body)
        }
    }
}

@Composable
private fun EmptyState(message: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Text(
            text = message,
            modifier = Modifier.padding(18.dp),
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.Bold
    )
}

@Composable
private fun StatusChip(status: String) {
    AssistChip(onClick = {}, label = { Text(status) })
}

@Composable
private fun PriorityChip(priority: String) {
    AssistChip(onClick = {}, label = { Text("Priority: $priority") })
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.width(110.dp)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun LtrText(
    text: String,
    modifier: Modifier = Modifier,
    style: androidx.compose.ui.text.TextStyle = MaterialTheme.typography.bodyMedium,
    fontWeight: FontWeight? = null
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Text(
            text = text,
            modifier = modifier,
            style = style,
            fontWeight = fontWeight,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}
