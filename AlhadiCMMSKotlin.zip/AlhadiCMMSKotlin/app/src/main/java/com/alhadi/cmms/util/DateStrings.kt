package com.alhadi.cmms.util

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateStrings {
    private fun formatter() = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
        isLenient = false
    }

    fun today(): String = formatter().format(Date())

    fun daysFromToday(days: Int): String {
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DATE, days)
        return formatter().format(calendar.time)
    }

    fun addDays(date: String, days: Int): String {
        val calendar = Calendar.getInstance()
        calendar.time = parseOrToday(date)
        calendar.add(Calendar.DATE, days)
        return formatter().format(calendar.time)
    }

    fun isDueOrOverdue(date: String, today: String = today()): Boolean = date <= today

    private fun parseOrToday(value: String): Date {
        return try {
            formatter().parse(value) ?: Date()
        } catch (_: ParseException) {
            Date()
        }
    }
}
