package com.alhadi.cmms.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.alhadi.cmms.data.CmmsRepository
import com.alhadi.cmms.data.entity.AssetEntity
import com.alhadi.cmms.data.entity.InventoryTransactionEntity
import com.alhadi.cmms.data.entity.PreventiveMaintenanceEntity
import com.alhadi.cmms.data.entity.SparePartEntity
import com.alhadi.cmms.data.entity.UserEntity
import com.alhadi.cmms.data.entity.WorkOrderEntity
import com.alhadi.cmms.util.DateStrings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.launch

data class DashboardStats(
    val assets: Int = 0,
    val openWorkOrders: Int = 0,
    val duePm: Int = 0,
    val lowStock: Int = 0
)

class CmmsViewModel(private val repository: CmmsRepository) : ViewModel() {
    private val today = DateStrings.today()

    val dashboardStats: StateFlow<DashboardStats> = combine(
        repository.observeAssetCount(),
        repository.observeOpenWorkOrderCount(),
        repository.observeDuePmCount(today),
        repository.observeLowStockCount()
    ) { assets, openWorkOrders, duePm, lowStock ->
        DashboardStats(
            assets = assets,
            openWorkOrders = openWorkOrders,
            duePm = duePm,
            lowStock = lowStock
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardStats())

    val assets: StateFlow<List<AssetEntity>> = repository.assets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val workOrders: StateFlow<List<WorkOrderEntity>> = repository.workOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val preventiveMaintenance: StateFlow<List<PreventiveMaintenanceEntity>> = repository.preventiveMaintenance
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val spareParts: StateFlow<List<SparePartEntity>> = repository.spareParts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val transactions: StateFlow<List<InventoryTransactionEntity>> = repository.recentTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val users: StateFlow<List<UserEntity>> = repository.users
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val currentUser: StateFlow<UserEntity?> = repository.currentUser
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    fun createDemoWorkOrder() = launchAction("تم إنشاء أمر عمل جديد") {
        repository.createDemoWorkOrder()
    }

    fun updateWorkOrderStatus(workOrder: WorkOrderEntity, status: String) = launchAction("تم تحديث حالة أمر العمل") {
        repository.updateWorkOrderStatus(workOrder.id, status)
    }

    fun markPreventiveMaintenanceDone(item: PreventiveMaintenanceEntity) = launchAction("تم إغلاق مهمة الصيانة الدورية وجدولتها من جديد") {
        repository.markPreventiveMaintenanceDone(item)
    }

    fun issuePart(part: SparePartEntity) = launchAction("تم صرف قطعة من المخزون") {
        repository.issuePart(part)
    }

    fun receivePart(part: SparePartEntity) = launchAction("تم إضافة قطعة إلى المخزون") {
        repository.receivePart(part)
    }

    fun addTechnician() = launchAction("تمت إضافة فني تجريبي") {
        repository.addTechnician()
    }

    fun resetSampleData() = launchAction("تمت إعادة تعبئة البيانات التجريبية") {
        repository.seedSampleData(replace = true)
    }

    fun clearMessage() {
        _message.value = null
    }

    private fun launchAction(successMessage: String, block: suspend () -> Unit) {
        viewModelScope.launch {
            runCatching { block() }
                .onSuccess { _message.value = successMessage }
                .onFailure { _message.value = "حدث خطأ: ${it.message ?: "غير معروف"}" }
        }
    }
}

class CmmsViewModelFactory(private val repository: CmmsRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CmmsViewModel::class.java)) {
            return CmmsViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
