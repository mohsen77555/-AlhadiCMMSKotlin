package com.alhadi.cmms.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AlhadiColorScheme = lightColorScheme(
    primary = Color(0xFF0F766E),
    onPrimary = Color.White,
    secondary = Color(0xFF155E75),
    tertiary = Color(0xFF92400E),
    surface = Color(0xFFFFFBFE),
    surfaceVariant = Color(0xFFE7EEF0),
    background = Color(0xFFF7FAFA)
)

@Composable
fun AlhadiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AlhadiColorScheme,
        typography = Typography(),
        content = content
    )
}
