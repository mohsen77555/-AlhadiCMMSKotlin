# Alhadi CMMS - Kotlin Android App

تطبيق Android Native مبني بـ Kotlin + Jetpack Compose + Room Database.

## ماذا يحتوي المشروع؟

- واجهة عربية RTL.
- أسماء الأصول والأكواد بالإنجليزية.
- تشغيل Offline-first باستخدام Room database.
- شاشة رئيسية Dashboard.
- شاشة Assets.
- شاشة Work Orders.
- شاشة Preventive Maintenance.
- شاشة Inventory / Spare Parts.
- شاشة Reports مبدئية.
- شاشة Admin تظهر فقط إذا كان المستخدم الحالي Admin.
- بيانات تجريبية جاهزة حتى لا يفتح التطبيق فارغًا.
- GitHub Actions workflow لبناء APK تلقائيًا.

## بيانات الدخول التجريبية

لا يوجد تسجيل دخول حاليًا. التطبيق يختار أول مستخدم فعال، وهو:

- Name: Mohsen Alhadi
- Username: mohsen
- Role: Admin

لذلك ستظهر لك صفحة الإدارة مباشرة. لاحقًا يمكنك إضافة شاشة Login وربطها بجدول users.

## فتح المشروع في Android Studio

1. افتح Android Studio.
2. اختر **Open**.
3. اختر مجلد `AlhadiCMMSKotlin`.
4. انتظر Gradle Sync.
5. شغل التطبيق على Emulator أو هاتف Android.

## بناء APK من Android Studio

من القائمة:

`Build > Build Bundle(s) / APK(s) > Build APK(s)`

بعد البناء ستجد APK داخل:

`app/build/outputs/apk/debug/`

## بناء APK من GitHub Actions

ارفع المشروع إلى GitHub، ثم من تبويب **Actions** شغل workflow باسم:

`Build Android APK`

سيتم رفع ملف APK كـ artifact باسم:

`Alhadi-CMMS-debug-apk`

## ملاحظات تقنية

- Package name: `com.alhadi.cmms`
- minSdk: 23
- targetSdk: 36
- compileSdk: 36
- Android Gradle Plugin: 8.13.2
- Kotlin: 2.3.21
- Compose BOM: 2026.05.00
- Room: 2.8.4
